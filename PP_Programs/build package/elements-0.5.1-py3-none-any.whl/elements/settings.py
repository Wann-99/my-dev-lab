import os
import inspect


class RobotSetting:

    def __init__(self,
                 ip: str = "192.167.2.100",
                 telnet_port: int = 23,
                 nanomsg_port: int = 15001,
                 grpc_port: int = 18001,
                 username: str = "root",
                 password: str = "root",
                 root_dir: str = "/root/mnt",
                 force_validate: bool = False):
        self.ip = ip
        self.telnet_port = telnet_port
        self.nanomsg_port = nanomsg_port
        self.grpc_port = grpc_port
        self.username = username
        self.password = password
        self.root_dir = root_dir
        self.base_dir = str(os.path.dirname(os.path.abspath(__file__)))
        self.force_validate = force_validate
        if self.force_validate:
            self.validate()

    def validate(self):
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        for method in methods:
            if method[0].startswith("validate_"):
                func = getattr(self, method[0])
                func()

    def validate_ip(self):
        import subprocess
        # 根据操作系统选择合适的 ping 命令
        if subprocess.run("ver", shell=True, capture_output=True).returncode == 0:
            param = "-n"
        else:
            param = "-c"

        output = subprocess.run(["ping", param, "1", self.ip],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE,
                                text=True,
                                timeout=3)
        assert output.returncode == 0, f"{self.ip} is not reachable"


if __name__ == "__main__":
    robot = RobotSetting(ip="192.167.2.100", telnet_port=23, force_validate=True)
    print()