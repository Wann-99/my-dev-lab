from abc import ABCMeta

from elements.core.enums import TransitConditionEnum
from elements.core.variable_values import VariableValue, VariableValueJPos


class ParameterValue(metaclass=ABCMeta):
    def __init__(self, value: str):
        self._value = value

    @property
    def value(self):
        return str(self._value)


class ParameterValueConstInt(ParameterValue):
    def __init__(self, value: int):
        super(ParameterValueConstInt, self).__init__(str(value))
        self._value = value
        self.m_type = TransitConditionEnum.ParameterType.INT.value
        self.m_category = TransitConditionEnum.ParameterCategory.CONST.value
        self.ml_data = [str(value)]

    @property
    def value(self):
        return str(self._value)


class ParameterValueConstBool(ParameterValue):
    def __init__(self, value: bool):
        super(ParameterValueConstBool, self).__init__(str(int(value)))
        self._value = value
        self.m_type = TransitConditionEnum.ParameterType.BOOL.value
        self.m_category = TransitConditionEnum.ParameterCategory.CONST.value
        if value:
            self.ml_data = ["1"]
        else:
            self.ml_data = ["0"]

    @property
    def value(self):
        return str(self._value)


class ParameterValueConstDouble(ParameterValue):
    def __init__(self, value: float):
        super(ParameterValueConstDouble, self).__init__(str(value))
        self._value = value
        self.m_type = TransitConditionEnum.ParameterType.DOUBLE.value
        self.m_category = TransitConditionEnum.ParameterCategory.CONST.value
        self.ml_data = [str(value)]

    @property
    def value(self):
        return str(self._value)


class ParameterValueConstString(ParameterValue):
    def __init__(self, value: str):
        super(ParameterValueConstString, self).__init__(value)
        self._value = value
        self.m_type = TransitConditionEnum.ParameterType.STRING.value
        self.m_category = TransitConditionEnum.ParameterCategory.CONST.value
        self.ml_data = [value]

    @property
    def value(self):
        return self._value


class ParameterValueConstGripper(ParameterValue):
    def __init__(self, value: str):
        super(ParameterValueConstGripper, self).__init__(value)
        self._value = value
        self.m_type = TransitConditionEnum.ParameterType.TYPE.value
        self.m_category = TransitConditionEnum.ParameterCategory.CONST.value
        self.ml_data = [value]

    @property
    def value(self):
        return self._value


class ParameterValueVariablePlan(ParameterValue):
    def __init__(self, value: VariableValue):
        super(ParameterValueVariablePlan, self).__init__(value._data)
        self.m_type = value.type
        self.m_category = TransitConditionEnum.ParameterCategory.CONST.value
        self.ml_data = [str(item) for item in value._data]

    @property
    def value(self):
        return str(self.ml_data)


class ParameterValueConstJPos(ParameterValue):
    def __init__(self, value: VariableValueJPos):
        super(ParameterValueConstJPos, self).__init__(value._data)
        self.m_type = value.type
        self.m_category = TransitConditionEnum.ParameterCategory.CONST.value
        self.ml_data = [str(item) for item in value._data]

    @property
    def value(self):
        return str(self.ml_data)