from abc import ABCMeta

from elements.core.enums import VariableEnum


class VariableValue(metaclass=ABCMeta):
    def __init__(self):
        self._data = None
        self.type = None

    @property
    def data(self):
        return [str(item) for item in self._data]


class VariableValueInt(VariableValue):
    def __init__(self, d1: int):
        super().__init__()
        self._data = d1
        self.type = VariableEnum.VariableType.INT

    @property
    def data(self):
        return str(self._data)


class VariableValueDouble(VariableValue):
    def __init__(self, d1: float):
        super().__init__()
        self._data = d1
        self.type = VariableEnum.VariableType.DOUBLE

    @property
    def data(self):
        return str(self._data)


class VariableValueString(VariableValue):
    def __init__(self, d1: str):
        super().__init__()
        self._data = d1
        self.type = VariableEnum.VariableType.STRING

    @property
    def data(self):
        return self._data


class VariableValueBool(VariableValue):
    def __init__(self, d1: bool):
        super().__init__()
        self._data = d1
        self.type = VariableEnum.VariableType.BOOL

    @property
    def data(self):
        return "1" if self._data else "0"


class VariableValueVec2D(VariableValue):
    """
    Vec2D variable value
    """

    def __init__(self, d1: float, d2: float):
        super(VariableValueVec2D, self).__init__()
        self.type = VariableEnum.VariableType.VEC_2D
        self.d1 = d1
        self.d2 = d2
        self._data = [self.d1, self.d2]


class VariableValueVec3D(VariableValue):
    """
    Vec3D variable value
    """

    def __init__(self, d1: float, d2: float, d3: float):
        super(VariableValueVec3D, self).__init__()
        self.type = VariableEnum.VariableType.VEC_3D
        self.d1 = d1
        self.d2 = d2
        self.d3 = d3
        self._data = [self.d1, self.d2, self.d3]


class VariableValueVec4D(VariableValue):
    """
    Vec4D variable value
    """

    def __init__(self, d1: float, d2: float, d3: float, d4: float):
        super(VariableValueVec4D, self).__init__()
        self.type = VariableEnum.VariableType.VEC_4D
        self.d1 = d1
        self.d2 = d2
        self.d3 = d3
        self.d4 = d4
        self._data = [self.d1, self.d2, self.d3, self.d4]


class VariableValueVec5D(VariableValue):
    """
    Vec5D variable value
    """

    def __init__(self, d1: float, d2: float, d3: float, d4: float, d5: float):
        super(VariableValueVec5D, self).__init__()
        self.type = VariableEnum.VariableType.VEC_5D
        self.d1 = d1
        self.d2 = d2
        self.d3 = d3
        self.d4 = d4
        self.d5 = d5
        self._data = [self.d1, self.d2, self.d3, self.d4, self.d5]


class VariableValueVec6D(VariableValue):
    """
    Vec6D variable value
    """

    def __init__(self, d1: float, d2: float, d3: float, d4: float, d5: float, d6: float):
        super(VariableValueVec6D, self).__init__()
        self.type = VariableEnum.VariableType.VEC_6D
        self.d1 = d1
        self.d2 = d2
        self.d3 = d3
        self.d4 = d4
        self.d5 = d5
        self.d6 = d6
        self._data = [self.d1, self.d2, self.d3, self.d4, self.d5, self.d6]


class VariableValueVec7D(VariableValue):
    """
    Vec7D variable value
    """

    def __init__(self, d1: float, d2: float, d3: float, d4: float, d5: float, d6: float, d7: float):
        super(VariableValueVec7D, self).__init__()
        self.type = VariableEnum.VariableType.VEC_7D
        self.d1 = d1
        self.d2 = d2
        self.d3 = d3
        self.d4 = d4
        self.d5 = d5
        self.d6 = d6
        self.d7 = d7
        self._data = [self.d1, self.d2, self.d3, self.d4, self.d5, self.d6, self.d7]


class VariableValueVec2I(VariableValue):
    """
    Vec2I variable value
    """

    def __init__(self, i1: int, i2: int):
        super(VariableValueVec2I, self).__init__()
        self.type = VariableEnum.VariableType.VEC_2I
        self.i1 = i1
        self.i2 = i2
        self._data = [self.i1, self.i2]


class VariableValueVec3I(VariableValue):
    """
    Vec2I variable value
    """

    def __init__(self, i1: int, i2: int, i3: int):
        super(VariableValueVec3I, self).__init__()
        self.type = VariableEnum.VariableType.VEC_3I
        self.i1 = i1
        self.i2 = i2
        self.i3 = i3
        self._data = [self.i1, self.i2, self.i3]


class VariableValueVec6I(VariableValue):
    """
    Vec6I variable value
    """

    def __init__(self, i1: int, i2: int, i3: int, i4: int, i5: int, i6: int):
        super(VariableValueVec6I, self).__init__()
        self.type = VariableEnum.VariableType.VEC_6I
        self.i1 = i1
        self.i2 = i2
        self.i3 = i3
        self.i4 = i4
        self.i5 = i5
        self.i6 = i6
        self._data = [self.i1, self.i2, self.i3, self.i4, self.i5, self.i6]


class VariableValueJPos(VariableValue):
    """
    JPos variable value
    """

    def __init__(
        self,
        a1: float = 0.0,
        a2: float = 0.0,
        a3: float = 0.0,
        a4: float = 0.0,
        a5: float = 0.0,
        a6: float = 0.0,
        a7: float = 0.0,
        ext1: float = 0.0,
        ext2: float = 0.0,
        ext3: float = 0.0,
        ext4: float = 0.0,
        ext5: float = 0.0,
        ext6: float = 0.0,
    ):
        super(VariableValueJPos, self).__init__()
        self.type = VariableEnum.VariableType.JPOS
        self.a1 = a1
        self.a2 = a2
        self.a3 = a3
        self.a4 = a4
        self.a5 = a5
        self.a6 = a6
        self.a7 = a7
        self.ext1 = ext1
        self.ext2 = ext2
        self.ext3 = ext3
        self.ext4 = ext4
        self.ext5 = ext5
        self.ext6 = ext6
        self._data = [self.a1, self.a2, self.a3, self.a4, self.a5, self.a6, self.a7,
                      self.ext1, self.ext2, self.ext3, self.ext4, self.ext5, self.ext6]


class VariableValuePose(VariableValue):
    """
    Pose variable value
    """

    def __init__(
        self,
        x: float = 0.0,
        y: float = 0.0,
        z: float = 0.0,
        rx: float = 0.0,
        ry: float = 0.0,
        rz: float = 0.0,
    ):
        super(VariableValuePose, self).__init__()
        self.type = VariableEnum.VariableType.POSE
        self.x = x
        self.y = y
        self.z = z
        self.rx = rx
        self.ry = ry
        self.rz = rz
        self._data = [self.x, self.y, self.z, self.rx, self.ry, self.rz]


class VariableValueCoord(VariableValue):
    """
    Coord variable value
    """

    def __init__(
        self,
        x,
        y,
        z,
        rx,
        ry,
        rz,
        coord_system: str,
        ref_a1: float = 0.0,
        ref_a2: float = -40,
        ref_a3: float = 0,
        ref_a4: float = 90.0,
        ref_a5: float = 0.0,
        ref_a6: float = 40,
        ref_a7: float = 0,
        ext1: float = 0.0,
        ext2: float = 0.0,
        ext3: float = 0.0,
        ext4: float = 0.0,
        ext5: float = 0.0,
        ext6: float = 0.0,
    ):
        super(VariableValueCoord, self).__init__()
        self.type = VariableEnum.VariableType.COORD
        self.x = x
        self.y = y
        self.z = z
        self.rx = rx
        self.ry = ry
        self.rz = rz
        self.coord_system = coord_system.split(",")
        self.ref_a1 = ref_a1
        self.ref_a2 = ref_a2
        self.ref_a3 = ref_a3
        self.ref_a4 = ref_a4
        self.ref_a5 = ref_a5
        self.ref_a6 = ref_a6
        self.ref_a7 = ref_a7
        self.ext1 = ext1
        self.ext2 = ext2
        self.ext3 = ext3
        self.ext4 = ext4
        self.ext5 = ext5
        self.ext6 = ext6
        self._data = [
            self.x,
            self.y,
            self.z,
            self.rx,
            self.ry,
            self.rz,
            *self.coord_system,
            self.ref_a1,
            self.ref_a2,
            self.ref_a3,
            self.ref_a4,
            self.ref_a5,
            self.ref_a6,
            self.ref_a7,
            self.ext1,
            self.ext2,
            self.ext3,
            self.ext4,
            self.ext5,
            self.ext6,
        ]
