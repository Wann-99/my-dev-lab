from typing import Callable
import os

from google.protobuf.json_format import MessageToJson
from google.protobuf.text_format import MessageToString
from loguru import logger

from elements.core.robot import Robot
from elements.settings import RobotSetting
from elements.core import gen_proto_obj
from elements.core.enums import SoftwareVersionEnum
from elements.core.node import Node, PlanNode, RootNode
from elements.core.plan_logger import PlanLogger
from elements.core.variables import PlanVariable
from elements.proto.ProtoPlanParams_pb2 import ProtoPlanParams


class Plan:

    _instance = None
    proto_type = "ProtoPlanParams"
    mapping = {"config": "RootNode", "plan_log": "PlanLogger"}

    # def __new__(cls, *args, **kwargs):
    #     if not cls._instance:
    #         cls._instance = super().__new__(cls)
    #     return cls._instance

    def __init__(self, name:str, setting: RobotSetting = RobotSetting()):
        """
        :param name: plan name
        :param setting: robot setting
        """
        self._robot_ip = setting.ip
        self._robot_dir = setting.root_dir
        self._nanomsg_port = setting.nanomsg_port
        self._grpc_port = setting.grpc_port
        self.m_plan_name = name
        self.cm_config = RootNode()
        self.cm_plan_log = PlanLogger()
        self.m_plan_desc = ""
        self.m_sw_ver = SoftwareVersionEnum.VER_3_08
        self.m_disable_pause_and_resume = False
        self.child_nodes = []
        self.child_subplans = []
        self.plan_variables = []
        self.project_variables = []
        self.parent = None
        self.robot = Robot(
            ip=self._robot_ip,
            grpc_port=self._grpc_port,
            nanomsg_port=self._nanomsg_port,
        )

    @property
    def plan_logger_enabled(self) -> bool:
        return self.cm_plan_log.m_enable_log

    @plan_logger_enabled.setter
    def plan_logger_enabled(self, value: bool):
        self.cm_plan_log.m_enable_log = value

    @property
    def plan_logger_interval(self) -> int:
        return self.cm_plan_log.m_time_interval

    @plan_logger_interval.setter
    def plan_logger_interval(self, value):
        self.cm_plan_log.m_time_interval = value

    @property
    def plan_logger_duration(self) -> int:
        return self.cm_plan_log.m_max_duration

    @plan_logger_duration.setter
    def plan_logger_duration(self, value: int):
        # ToDo plan logger 最大多少秒
        if not self.plan_logger_enabled:
            logger.error("plan logger must be enabled before setting duration")
            return
        assert 0 < value <= 30
        self.cm_plan_log.m_max_duration = value

    @property
    def description(self) -> str:
        return self.m_plan_desc

    @description.setter
    def description(self, value: str):
        self.m_plan_desc = value

    @property
    def sw_ver(self) -> str:
        return self.m_sw_ver.name

    @sw_ver.setter
    def sw_ver(self, value: str):
        self.m_sw_ver = SoftwareVersionEnum[value]

    def to_proto(self) -> ProtoPlanParams:
        """ convert python object to ProtoPlanParams
        :return: ProtoPlanParams
        """
        obj = ProtoPlanParams()
        for k, v in self.__dict__.items():
            if k.startswith("m_"):
                setattr(obj, k[2:], v)
            elif k.startswith("cm_") and v:
                gen_proto_obj(obj, k[3:], v)
        # node and its transit
        child_node_protos = []
        child_transit_protos = []
        for node in self.child_nodes:
            child_node_protos.append(node.to_proto())
            if node.transit is not None:
                child_transit_protos.append(node.transit.to_proto())
        obj.node_list.extend(child_node_protos)
        obj.transit_list.extend(child_transit_protos)

        # plan variables
        var_protos = []
        for var in self.plan_variables:
            var_protos.append(var.to_proto())
        obj.var_list.extend(var_protos)

        # project variables
        proj_var_protos = []
        for p_var in self.project_variables:
            proj_var_protos.append(p_var.to_proto())
        obj.proj_var_list.extend(proj_var_protos)

        # sub plans
        subplan_protos = []
        for subplan in self.child_subplans:
            subplan_protos.append(subplan.to_proto())
        obj.child_plans.extend(subplan_protos)

        return obj

    def to_json(self) -> str:
        obj = self.to_proto()
        return MessageToJson(obj, preserving_proto_field_name=True)

    def to_str(self) -> str:
        obj = self.to_proto()
        plan_str = MessageToString(obj)
        return plan_str

    def to_file(self):
        """ generate a plan file, named by plan name
        :return:
        """
        obj = self.to_proto()
        plan_str = MessageToString(obj)
        with open(self.m_plan_name + ".plan", "w") as f:
            f.write(plan_str)

    def add_node(self, child_node: Node):
        """ add node to current plan
        :param child_node: primitive node
        :return:
        """
        assert child_node is not None, "cannot add a None child node"
        self.child_nodes.append(child_node)

    def delete_node(self, child_node: Node) -> bool:
        """ delete node from current plan
        :param child_node: primitive node
        :return:
        """
        assert child_node != None, "the node to delete cannot be None"
        if child_node in self.child_nodes:
            self.child_nodes.remove(child_node)
            return True
        logger.error(
            f"failed to find child node {child_node.m_node_name} in current plan"
        )
        return False

    def delete_node_by_name(self, child_node_name: str) -> bool:
        """ delete child node by name
        :param child_node_name: node name
        :return: True | False
        """
        assert child_node_name != "", "the child node name to delete cannot be empty"
        for node in self.child_nodes:
            if node.m_node_name == child_node_name:
                self.child_nodes.remove(node)
                return True
        logger.error(f"failed to find node {child_node_name} in current plan")
        return False

    def add_variable(self, var: PlanVariable):
        """ add variable to current plan
        :param var: PlanVariable
        :return:
        """
        assert var is not None, "the variable to add cannot be None"
        self.plan_variables.append(var)

    def add_subplan(self, func: Callable[[str], "Plan"], name: str):
        """add subplan to current plan
        :param func: function to generate sub plan, must be startswith p_
        :param name: name of sub plan
        :return:
        """
        assert func.__name__.startswith("p_"), "sub plan name must start with p_"
        subplan = func(name)
        subplan.parent = self
        subplan.cm_config = RootNode(name)
        self.child_subplans.append(subplan)

    def to_graph(self):
        from transitions.extensions import GraphMachine

        states = [node.m_node_name for node in self.child_nodes]
        transitions = []
        for node in self.child_nodes:
            # 存在父节点时再添加过渡
            if node.parent:
                transitions.append(
                    {
                        "trigger": node.transit.name,
                        "source": node.parent.m_node_name,
                        "dest": node.m_node_name,
                    }
                )
        machine = GraphMachine(
            model=self, states=states, transitions=transitions, initial="startNode"
        )
        graph = machine.get_graph()
        graph.node_attr["fontname"] = "Microsoft Yahei"
        graph.node_attr["fontname"] = "Microsoft Yahei"
        graph.graph_attr["fontname"] = "Microsoft Yahei"
        graph.graph_attr["dpi"] = "300"  # 设置分辨率
        graph.graph_attr.pop("label")  # 删除标题
        graph.draw(f"{self.m_plan_name}.png", prog="dot")

    async def assign(self) -> bool:
        from elements.common.exception import SubPlanAssignmentException
        from elements.core.robot_file_system import RobotFileSystem

        """ assign plan to RCA

        :return:
        """
        if self.parent is not None:
            raise SubPlanAssignmentException("cannot assign sub plan to RCA")
        rfs = RobotFileSystem(ip=self._robot_ip)
        r_project_dir = os.path.join(self._robot_dir, "programs/user_data/projects", self.m_plan_name)
        r_plan_file = os.path.join(r_project_dir, self.m_plan_name + ".plan")
        # RCA根据.project文件判断是否为项目
        r_project_file = os.path.join(r_project_dir, ".project")
        if not rfs.is_dir_exists(r_project_dir):
            rfs.mkdir(r_project_dir)
        rfs.write(r_plan_file, open(self.m_plan_name + ".plan", "r").read())
        rfs.write(r_project_file, "")

        result = await self.robot.assign_plan(self.m_plan_name)
        return result

    def reset_assign(self) -> bool:
        from elements.common.exception import SubPlanReAssignmentException

        if self.parent is not None:
            raise SubPlanReAssignmentException
        result = self.robot.reset_assigned_plan(self.m_plan_name)
        return result

    def run(self):
        """run plan

        :return:
        """
        raise NotImplementedError


if __name__ == "__main__":

    def p_subplan1(name: str) -> Plan:
        plan = Plan(name)
        plan.cm_config = PlanNode(name)
        return plan

    # create plan
    plan = Plan(name="plan_subplan")
    # create sub plan
    plan.add_subplan(p_subplan1, "subplan1")

    # create proto file
    plan.to_file()
