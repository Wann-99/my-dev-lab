from enum import Enum

from elements.core import gen_proto_obj
from elements.core.enums import TransitConditionEnum
from elements.core.node import Node
from elements.core.parameter_values import ParameterValue
from elements.core.parameters import Parameter
from elements.proto.ProtoPlanParams_pb2 import ProtoNodeTransitParams, ProtoTCParams


class TriggerCondition:
    def __init__(
        self,
        condition_type: TransitConditionEnum.ConditionType = TransitConditionEnum.ConditionType.NO_CHECK,
        lhs_param: Parameter = None,
        rhs_param: ParameterValue = None,
    ):
        self.m_condition_type = condition_type
        self.cm_lhs_param = lhs_param
        self.cm_rhs_param = rhs_param
        self.cml_trigger_condition = []

    @property
    def name(self):
        if self.cm_lhs_param:
            return (
                self.cm_lhs_param.m_module_name
                + "::"
                + self.cm_lhs_param.m_name
                + " "
                + getattr(
                    TransitConditionEnum.ConditionValue, self.m_condition_type.value
                ).value
                + " "
                + self.cm_rhs_param.value
            )
        # NO_CHECK
        return ""

    def from_json(self, condition_json):
        """
        # ToDo: no intelligence prompt
        :param condition_json:
        {
            "operator": "or",
            "conditions": [
                {
                    "operator": "equal",
                    "left": {
                        "type": "PT_STATE",
                        "node_name": "",
                        "value": "Terminated"
                    },
                    "right": {
                        "category": "const",
                        "type": "bool",
                        "value":
                    }
                }
            ]
        }
        :return:
        """

    def to_proto(self) -> ProtoTCParams:
        obj = ProtoTCParams()
        for k, v in self.__dict__.items():
            if k.startswith("m_"):
                if isinstance(v, Enum):
                    setattr(obj, k[2:], v.value)
                else:
                    setattr(obj, k[2:], v)
            elif k.startswith("cm_") and v:
                gen_proto_obj(obj, k[3:], v)
            elif k.startswith("cml_") and v:
                sub_v_objs = []
                for item in v:
                    sub_v_objs.append(item.to_proto())
                getattr(obj, k[4:]).extend(sub_v_objs)
        return obj


class Transit:
    # TransitCondition > TransitCondition -> Parameter
    def __init__(self, start: Node = None, end: Node = None):
        # 将后面的结点加到上一个结点的children中
        start.children.append(end)
        self.m_start_node_name = start.m_node_name
        self.m_end_node_name = end.m_node_name
        self.m_transit_period = 0
        self.cm_trigger_condition = TriggerCondition(
            condition_type=TransitConditionEnum.ConditionType.NO_CHECK
        )
        # self.cm_param_assignment = ParameterAssignment()
        # self.cm_param_operation = ParameterOperation()

    @property
    def name(self):
        tc_names = []
        if self.cm_trigger_condition.cml_trigger_condition:
            for tc in self.cm_trigger_condition.cml_trigger_condition:
                tc_names.append(tc.name)
            return f" {getattr(TransitConditionEnum.ConditionValue, self.cm_trigger_condition.m_condition_type.value).value} ".join(
                tc_names
            )
        else:
            return self.cm_trigger_condition.name

    def to_proto(self) -> ProtoNodeTransitParams:
        obj = ProtoNodeTransitParams()
        for k, v in self.__dict__.items():
            if k.startswith("m_"):
                setattr(obj, k[2:], v)
            elif k.startswith("cm_") and v:
                gen_proto_obj(obj, k[3:], v)
            # elif k.startswith("cml_") and v.m_condition_type != PtTransitConditionEnum.ConditionType.NO_CHECK.value:
            #     repeated = getattr(obj, k[4:])
            #     repeated_objs = []
            #     for item in k:
            #         repeated_objs.append(item.to_proto())
            #     repeated.trigger_condition.extend(repeated_objs)
        return obj
