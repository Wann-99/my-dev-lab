from enum import Enum

from elements.core import gen_proto_obj
from elements.core.enums import PtNameEnum, PtTypeEnum
from elements.core.node import Node
from elements.core.plan import Plan
from elements.core.parameters import Parameter, ParameterPtParam
from elements.core.parameter_values import ParameterValue
from elements.proto.ProtoPlanParams_pb2 import ProtoNodeParams


class PrimitiveNode(Node):
            
    def __init__(self, name: str):
        super().__init__(name)
        self.cml_param_assignment = []

    def add_transit(
        self, parent: Node | Plan, condition: "TriggerCondition", period: int = 0
    ):
        from elements.core.transit import Transit

        # End primitive 后面不能连接primitive, subplan
        assert parent is not None and parent.m_pt_type != PtTypeEnum.Workflow.END
        self.parent = parent
        self.transit = Transit(start=parent, end=self)
        self.transit.cm_trigger_condition = condition
        self.transit.period = period

    def add_parameter(self, param: Enum, param_value: ParameterValue):
        from elements.core.parameter_assignment import ParameterAssignment
        self.cml_param_assignment.append(
            ParameterAssignment(lhs_param=ParameterPtParam(pt_name=self.name, parameter=param),
                                rhs_param=param_value))

    @property
    def breakpoint(self):
        return self.m_is_breakpoint

    @breakpoint.setter
    def breakpoint(self, value: bool):
        self.m_is_breakpoint = value

    def to_proto(self) -> ProtoNodeParams:
        obj = ProtoNodeParams()
        for k, v in self.__dict__.items():
            if k.startswith("m_"):
                if isinstance(v, Enum):
                    setattr(obj, k[2:], v.value)
                else:
                    setattr(obj, k[2:], v)
            elif k.startswith("cm_"):
                gen_proto_obj(obj, k[3:], v)
            elif k.startswith("cml_"):
                sub_v_objs = []
                for item in v:
                    sub_v_objs.append(item.to_proto())
                getattr(obj, k[4:]).extend(sub_v_objs)
        return obj


class Motion:

    class MoveC(PrimitiveNode):
        def __init__(self, name):
            super(Motion.MoveC, self).__init__(name)
            self.m_pt_name = PtNameEnum.Motion.MOVEC.value
            self.m_pt_type = PtTypeEnum.Motion.MOVEC.value

    class MoveJ(PrimitiveNode):
        def __init__(self, name):
            super(Motion.MoveJ, self).__init__(name)
            self.m_pt_name = PtNameEnum.Motion.MOVEJ.value
            self.m_pt_type = PtTypeEnum.Motion.MOVEJ.value

    class MoveL(PrimitiveNode):
        def __init__(self, name):
            super(Motion.MoveL, self).__init__(name)
            self.m_pt_name = PtNameEnum.Motion.MOVEL.value
            self.m_pt_type = PtTypeEnum.Motion.MOVEL.value

    class MovePTP(PrimitiveNode):
        def __init__(self, name):
            super(Motion.MovePTP, self).__init__(name)
            self.m_pt_name = PtNameEnum.Motion.MOVEPTP.value
            self.m_pt_type = PtTypeEnum.Motion.MOVEPTP.value


class Workflow:

    class Home(PrimitiveNode):
        def __init__(self, name):
            super(Workflow.Home, self).__init__(name)
            self.m_pt_name = PtNameEnum.Workflow.HOME.value
            self.m_pt_type = PtTypeEnum.Workflow.HOME.value

    class Hold(PrimitiveNode):
        def __init__(self, name):
            super(Workflow.Hold, self).__init__(name)
            self.m_pt_name = PtNameEnum.Workflow.HOLD.value
            self.m_pt_type = PtTypeEnum.Workflow.HOLD.value

    class Fault(PrimitiveNode):
        def __init__(self, name):
            super(Workflow.Fault, self).__init__(name)
            self.m_pt_name = PtNameEnum.Workflow.FAULT.value
            self.m_pt_type = PtTypeEnum.Workflow.FAULT.value

    class Stop(PrimitiveNode):
        def __init__(self, name):
            super(Workflow.Stop, self).__init__(name)
            self.m_pt_name = PtNameEnum.Workflow.STOP.value
            self.m_pt_type = PtTypeEnum.Workflow.STOP.value

    class End(PrimitiveNode):
        def __init__(self, name):
            super(Workflow.End, self).__init__(name)
            self.m_pt_name = PtNameEnum.Workflow.END.value
            self.m_pt_type = PtTypeEnum.Workflow.END.value
            self.children = None


class BasicForceControl:

    class CaliForceSensor(PrimitiveNode):
        def __init__(self, name):
            super(BasicForceControl.CaliForceSensor, self).__init__(name)
            self.m_pt_name = PtNameEnum.BasicForceControl.ZEROFTSENSOR.value
            self.m_pt_type = PtTypeEnum.BasicForceControl.ZEROFTSENSOR.value

    class Contact(PrimitiveNode):
        def __init__(self, name):
            super(BasicForceControl.Contact, self).__init__(name)
            self.m_pt_name = PtNameEnum.BasicForceControl.CONTACT.value
            self.m_pt_type = PtTypeEnum.BasicForceControl.CONTACT.value

    class MoveTraj(PrimitiveNode):
        def __init__(self, name):
            super(BasicForceControl.MoveTraj, self).__init__(name)
            self.m_pt_name = PtNameEnum.BasicForceControl.MOVETRAJ.value
            self.m_pt_type = PtTypeEnum.BasicForceControl.MOVETRAJ.value

    class MoveComp(PrimitiveNode):
        def __init__(self, name):
            super(BasicForceControl.MoveComp, self).__init__(name)
            self.m_pt_name = PtNameEnum.BasicForceControl.MOVECOMP.value
            self.m_pt_type = PtTypeEnum.BasicForceControl.MOVECOMP.value


class AdvancedForceControl:

    class ContactAlign(PrimitiveNode):
        def __init__(self, name):
            super(AdvancedForceControl.ContactAlign, self).__init__(name)
            self.m_pt_name = PtNameEnum.AdvancedForceControl.CONTACTALIGN.value
            self.m_pt_type = PtTypeEnum.AdvancedForceControl.CONTACTALIGN.value

    class ForceHybrid(PrimitiveNode):
        def __init__(self, name):
            super(AdvancedForceControl.ForceHybrid, self).__init__(name)
            self.m_pt_name = PtNameEnum.AdvancedForceControl.FORCEHYBRID.value
            self.m_pt_type = PtTypeEnum.AdvancedForceControl.FORCEHYBRID.value

    class ForceComp(PrimitiveNode):
        def __init__(self, name):
            super(AdvancedForceControl.ForceComp, self).__init__(name)
            self.m_pt_name = PtNameEnum.AdvancedForceControl.FORCECOMP.value
            self.m_pt_type = PtTypeEnum.AdvancedForceControl.FORCECOMP.value


class ZeroGravityFloating:

    class FloatingCartesian(PrimitiveNode):
        def __init__(self, name):
            super(ZeroGravityFloating.FloatingCartesian, self).__init__(name)
            self.m_pt_name = PtNameEnum.ZeroGravityFloating.FLOATINGCARTESIAN.value
            self.m_pt_type = PtTypeEnum.ZeroGravityFloating.FLOATINGCARTESIAN.value

    class FloatingJoint(PrimitiveNode):
        def __init__(self, name):
            super(ZeroGravityFloating.FloatingJoint, self).__init__(name)
            self.m_pt_name = PtNameEnum.ZeroGravityFloating.FLOATINGJOINT.value
            self.m_pt_type = PtTypeEnum.ZeroGravityFloating.FLOATINGJOINT.value
