first_index_string = """
function first_index_string(str, substr)
  local i = string.find(str, substr, 1, true)
  if i == nil then
    return 0
  end
  return i
end
"""

last_index_string = """
function last_index_string(str, substr)
  local i = string.find(string.reverse(str), string.reverse(substr), 1, true)
  if i then
    return #str + 2 - i - #substr
  end
  return 0
end
"""

split_string = """
function split_string(input, delim)
  local t = {}
  local pos = 1
  while true do
    next_delim = string.find(input, delim, pos)
    if next_delim == nil then
      table.insert(t, string.sub(input, pos))
      break
    else
      table.insert(t, string.sub(input, pos, next_delim-1))
      pos = next_delim + #delim
    end
  end
  return t
end
"""

concat_string = """
function concat_string(strA, strB)
  return tostring(strA) .. tostring(strB)
end
"""

join_string = """
function join_string(list, delim)
  local str = table.concat(list, delim)
  return str
end
"""

read_trajectory_file = """
function read_trajectory_file(file_name)
  return content_of_file('trajectory', file_name)
end
"""

write_trajectory_file = """
function write_trajectory_file(content, file_name)
  write_content_to_file(content, 'trajectory', file_name)
end
"""

create_list = """
function create_list(...)
  local list = {}
  for i, value in ipairs({...}) do
        table.insert(list, value)
  end
  return list
end
"""

insert_list = """
function insert_list(list, index, value)
  if type(index) ~= "number" then
    print("index must be a number")
    return nil
  end
  if index < 0 or index > #list then
    print("index out of range")
    return nil
  end
  table.insert(list, index, value)
  return list
end
"""

remove_list = """
function remove_list(list, index)
  if type(index) ~= "number" then
    print("index must be a number")
    return nil
  end
  if index < 0 or index > #list then
    print("index out of range")
    return nil
  end
  return table.remove(list, index)
end
"""

get_list = """
function get_list(list, index)
  if type(index) ~= "number" then
    print("index must be a number")
    return nil
  end
  if index < 0 or index > #list then
    print("index out of range")
    return nil
  end
  return list[index]
end
"""

set_list = """
function set_list(list, index, value)
  if type(index) ~= "number" then
    print("index must be a number")
    return nil
  end
  if index < 0 or index > #list then
    print("index out of range")
    return nil
  end
  list[index] = value
  return list
end
"""

update_object_pool = """
function update_object_pool(obj_name, type, camera_intrinsics, camera_extrinsics, mounting)
  obj_pool_update(obj_name, type, camera_intrinsics, camera_extrinsics, mounting)
end
"""

clear_object_pool = """
function clear_object_pool()
  obj_pool_clear()
end
"""