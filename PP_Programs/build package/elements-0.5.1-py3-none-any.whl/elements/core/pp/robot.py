def clear_fault():
    """ clear robot fault

    """
    pass

def fault(msg: str = "Trigger fault by PP"):
    """ trigger fault by PP
    :param msg:

    """
    pass

def get_system_state(state: str):
    """ get robot system state
    :param state: [CartesianForceX,
                   CartesianForceY,
                   CartesianForceZ,
                   CartesianForce,
                   CartesianPosX,
                   CartesianPosY,
                   CartesianPosZ,
                   jPos,
                   isServoOn,
                   operationMode,
                   isFault,
                   currentToolName,
                   motionbarEnablePressed,
                   motionbarEstopPressed,
                   projectPaused,
                   projectRunning]
    """
    pass

def content_of_file(file_type: str, file_name: str):
    """ get content of file
    :param file_type: [trajectory,]
    :param file_name:
    """
    pass

def write_content_to_file(file_content: str):
    """ write content to file
    :param file_content:
    """
    pass

def set_global_var(name: str, value: object):
    """ set global variable
    :param name: global variable name
    :param value: global variable value, support Variable, COORD, JPOS, String, Double, Integer etc
    """
    pass

def get_global_var(name: str):
    """ get global variable
    :param name: global variable name
    """
    pass

def get_io(type: str, name: str):
    """ get robot io
    :param type: [GPIOSystem,
                  GPIOProfinetSlave,
                  GPIOModbusTCPSlave,
                  GPIOAnybus]
    :param name:
    """
    pass

def set_io(type: str, name: str, value: bool):
    """ set robot io
    :param type: [GPIOSystem,
                  GPIOProfinetSlave,
                  GPIOModbusTCPSlave,
                  GPIOAnybus]
    :param name:
    :param value:
    """
    pass


def wait_io_ms(type: str, name: str, value: bool, timeout: int):
    """ wait for given time until given IO port value
    :param type: [GPIOSystem,
                  GPIOProfinetSlave,
                  GPIOModbusTCPSlave,
                  GPIOAnybus]
    :param name:
    :param value:
    :param timeout:
    """
    pass


def set_io_pulse_ms(type: str, name: str, value: bool, duration: int):
    """ set pulse to DO port in given duration
    :param type: [GPIOSystem,
                  GPIOProfinetSlave,
                  GPIOModbusTCPSlave
                  GPIOAnybus]
    :param name: DO port name
    :param value: [True, False]
    :param duration: unit ms
    """
    pass

def read_trajectory_file(name: str):
    """ read content to trajectory file
    :param name: traj file name
    """
    pass

def write_trajectory_file(content: str, name: str):
    """ write content to trajectory file
    :param content: traj file content
    :param name: traj file name
    """
    pass


def set_workcoord_or_tool(type: str, name: str, value):
    """ set name of type workcoord or tool to value
    :param type: [Work coordinate system, Tool]
    :param name: workcoord or tool name
    :param value:
    """
    pass

def get_workcoord_or_tool(type: str, name: str):
    """ get value of workcoord or tool
    :param type: [Work coordinate system, Tool]
    :param name: workcoord or tool name
    """
    pass

def clear_object_pool():
    """ clear object pool
    """
    pass

def update_object_pool(obj_name: str, type: int, camera_intrinsics: str,
                       camera_extrinsics: str, mounting: str, data: list):
    """ update object pool
    :param obj_name: object name
    :param type: object type, 25 - array_vec_2d, 3 - vec-6d
    :param camera_intrinsics: camera intrinsics
    :param camera_extrinsics: camera extrinsics
    :param mounting: mounting, ["flange", "tcp", "world"]
    :param data:
    """
    pass