import grpc
from loguru import logger

from elements.proto.RobotServiceWorkflow_pb2 import AssignPlanRequest, PlanNameRequest
from elements.proto.RobotServiceWorkflow_pb2_grpc import WorkflowServiceStub
from elements.utils.nanomsg_util import NanomsgClient, NanomsgClientUtil


class Robot:

    def __init__(
        self, ip: str = "192.168.2.10", grpc_port: int = 18001, nanomsg_port: int = 15001
    ):
        self.ip = ip
        self.grpc_port = grpc_port
        self.nano_port = nanomsg_port
        self._conn_str = f"{self.ip}:{self.grpc_port}"
        self.channel = grpc.insecure_channel(self._conn_str)
        self.stub = WorkflowServiceStub(self.channel)
        self.client = NanomsgClient(ip, nanomsg_port)
        self.init_info()

    def init_info(self):
        self.data = NanomsgClientUtil.get_data(self.client)
        self.assigned_plan = NanomsgClientUtil.get_assigned_plan(self.client, self.data)
        self.state = NanomsgClientUtil.get_state(self.client, self.data)
        self.mode = NanomsgClientUtil.get_mode(self.client, self.data)
        self.sero_on = NanomsgClientUtil.is_servo_on(self.client, self.data)
        logger.info(f"robot info: "
                    f"assigned_plan: {self.assigned_plan}, "
                    f"state: {self.state}, "
                    f"mode: {self.mode}, "
                    f"sero_on: {self.sero_on}")

    async def assign_plan(self, name) -> bool:
        # 机器人必须在停止状态下才能下发计划
        assert self.sero_on and self.state == "stopped", "robot must be in stopped mode when assigning plan"
        try:
            result = await self.stub.AssignPlan(
                AssignPlanRequest(plan_name=name, is_internal_plan=False)
            )
            if result.value == 100000:
                return True
        except Exception as e:
            logger.error(f"Exception when assigning plan， message: {e}")
            return False
        logger.error(f"Assign plan {name} failed, msg: {result.info}")
        return False

    def reset_assigned_plan(self, name):
        result = self.stub.ResetAssignPlan(PlanNameRequest(plan_name=name))
        if result.value == 100000:
            return True
        logger.error(f"Reset assigned plan {name} failed, msg: {result.info}")
        return False


if __name__ == "__main__":
    robot = Robot()
    robot.assign_plan("FT03Test")
    robot.init_info()
    assigned_plan = robot.assigned_plan
    print(assigned_plan)
