from enum import Enum

from elements.core.parameters import Parameter
from elements.core.parameter_values import ParameterValue
from elements.proto.ProtoPlanParams_pb2 import ProtoParamsAssignment


class ParameterAssignment:

    def __init__(self, lhs_param: Parameter, rhs_param: ParameterValue):
        self._lhs_param = lhs_param
        self._rhs_param = rhs_param

    def to_proto(self) -> ProtoParamsAssignment:
        obj = ProtoParamsAssignment()
        for k, v in self._lhs_param.__dict__.items():
            if k.startswith("m_"):
                if isinstance(v, Enum):
                    setattr(obj.lhs_param, k[2:], v.value)
                else:
                    setattr(obj.lhs_param, k[2:], v)
        for k, v in self._rhs_param.__dict__.items():
            if k.startswith("m_"):
                if isinstance(v, Enum):
                    setattr(obj.rhs_param, k[2:], v.value)
                else:
                    setattr(obj.rhs_param, k[2:], v)
            elif k.startswith("ml_") and v:
                getattr(obj.rhs_param, k[3:]).extend(v)

        return obj