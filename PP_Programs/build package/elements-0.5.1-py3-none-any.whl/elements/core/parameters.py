from abc import ABCMeta
from enum import Enum

from elements.core.enums import ToolNameEnum, TransitConditionEnum, PtParameterEnum
from elements.core.variables import Variable


class SwitchTcpParam:
    def __init__(
        self,
        switch: bool = True,
        name: str = ToolNameEnum.FLANGE.value,
        index: int = 0,
        var_name: str = "",
    ):
        self.m_switch_tcp = switch
        self.m_tool_name = name
        self.m_tcp_index = index
        self.m_tcp_var_name = var_name


class Parameter(metaclass=ABCMeta):
    def __init__(self, name: str, module_name: str = "", type: str = "", category: str = ""):
        self.m_name = name
        self.m_module_name = module_name
        self.m_category = category
        self.m_robotUnit = "none"
        self.type_mapping = None
        self.m_type = type


class ParameterPlanState(Parameter):
    def __init__(self, parameter: Enum):
        super(ParameterPlanState, self).__init__(parameter.value)
        self.m_module_name = "rootNode"
        self.m_category = TransitConditionEnum.ParameterCategory.PLAN_STATE.value
        self.type_mapping = {
            "loopCounter": "INT",
        }
        self.m_type = self.type_mapping.get(self.m_name)


class ParameterFlexivGN01State(Parameter):
    def __init__(self, parameter: Enum):
        super(ParameterFlexivGN01State, self).__init__(parameter.value)
        self.m_module_name = "Flexiv-GN01"
        self.m_category = TransitConditionEnum.ParameterCategory.DEVICE_STATE.value
        self.type_mapping = {
            "state": "TYPE",
            "moving": "BOOL",
            "width": "DOUBLE",
            "force": "DOUBLE",
            "reachedForce": "BOOL",
            "reachedWidth": "BOOL",
            "reCaliDone": "BOOL",
            "faultWord": "INT"
        }
        self.m_type = self.type_mapping.get(self.m_name)


class ParameterPlanVariable(Parameter):
    def __init__(self, plan_var: Variable):
        super(ParameterPlanVariable, self).__init__(plan_var.m_name)
        self.m_module_name = "rootNode"
        self.m_type = plan_var.m_type
        self.m_category = TransitConditionEnum.ParameterCategory.PLAN_VAR.value


class ParameterPtState(Parameter):
    def __init__(self, pt_name: str, parameter: Enum):
        super(ParameterPtState, self).__init__(parameter.value)
        self.m_module_name = pt_name
        self.m_category = TransitConditionEnum.ParameterCategory.PT_STATE.value
        self.type_mapping = {
            "terminated": "BOOL",
            "reachedTarget": "BOOL",
            "timePeriod": "DOUBLE",
        }
        self.m_type = self.type_mapping.get(self.m_name)


class ParameterPtParam(Parameter):
    def __init__(self, pt_name: str, parameter: Enum):
        super(ParameterPtParam, self).__init__(parameter.value.get("name"))
        self.m_module_name = pt_name
        self.m_category = PtParameterEnum.ParameterCategory.PT_INPUT.value
        self.m_type = parameter.value.get("type")