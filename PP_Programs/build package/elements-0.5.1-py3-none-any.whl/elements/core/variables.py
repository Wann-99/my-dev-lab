from abc import ABCMeta
from enum import Enum

from elements.core import gen_proto_obj
from elements.core.enums import VariableEnum
from elements.core.variable_values import VariableValue
from elements.proto.ProtoPlanParams_pb2 import ProtoParams


class Variable(metaclass=ABCMeta):
    def __init__(self, name: str, type: Enum, value: VariableValue = None):
        self.m_name = name
        self.m_type = type
        self.m_module_name = "rootNode"
        self.m_category = ""
        self.m_robotUnit = "none"
        assert self.m_type in [VariableEnum.VariableType.VEC_2D,
                               VariableEnum.VariableType.VEC_3D,
                               VariableEnum.VariableType.VEC_4D,
                               VariableEnum.VariableType.VEC_6D,
                               VariableEnum.VariableType.VEC_7D,
                               VariableEnum.VariableType.VEC_2I,
                               VariableEnum.VariableType.VEC_3I,
                               VariableEnum.VariableType.VEC_6I,
                               VariableEnum.VariableType.JPOS,
                               VariableEnum.VariableType.COORD,
                               VariableEnum.VariableType.POSE,
                               VariableEnum.VariableType.INT,
                               VariableEnum.VariableType.DOUBLE,
                               VariableEnum.VariableType.STRING,
                               VariableEnum.VariableType.BOOL,], \
            f"{self.m_type} is not a valid plan variable type"
        assert (
            self.m_type == value.type
        ), f"variable type definition {self.m_type} must be the same as value type {value.type}"
        if self.m_type == VariableEnum.VariableType.JPOS:
            assert len(value.data) == 13, "length of JPos should be 13"
        elif self.m_type == VariableEnum.VariableType.POSE:
            assert len(value.data) == 6, "length of Pos should be 6"
        elif self.m_type == VariableEnum.VariableType.VEC_2D:
            assert len(value.data) == 2, "length of Vec2D should be 2"
        elif self.m_type == VariableEnum.VariableType.VEC_3D:
            assert len(value.data) == 3, "length of Vec3D should be 3"
        elif self.m_type == VariableEnum.VariableType.VEC_4D:
            assert len(value.data) == 4, "length of Vec4D should be 4"
        elif self.m_type == VariableEnum.VariableType.VEC_6D:
            assert len(value.data) == 6, "length of Vec6D should be 6"
        elif self.m_type == VariableEnum.VariableType.VEC_7D:
            assert len(value.data) == 7, "length of Vec7D should be 7"
        elif self.m_type == VariableEnum.VariableType.VEC_2I:
            assert len(value.data) == 2, "length of Vec2I should be 2"
        elif self.m_type == VariableEnum.VariableType.VEC_3I:
            assert len(value.data) == 3, "length of Vec3I should be 3"
        elif self.m_type == VariableEnum.VariableType.VEC_6I:
            assert len(value.data) == 6, "length of Vec6I should be 6"
        elif self.m_type == VariableEnum.VariableType.COORD:
            assert len(value.data) == 21, "length of Coordinate should be 21"

        self._value = value
        self.m_type = type
        if value.type in [VariableEnum.VariableType.INT, VariableEnum.VariableType.DOUBLE,
                          VariableEnum.VariableType.STRING, VariableEnum.VariableType.BOOL]:
            self.ml_data = [value.data]
        else:
            self.ml_data = value.data

    @property
    def value(self):
        return self._value

    def to_proto(self) -> ProtoParams:
        obj = ProtoParams()
        for k, v in self.__dict__.items():
            if k.startswith("m_"):
                if isinstance(v, Enum):
                    setattr(obj, k[2:], v.value)
                else:
                    setattr(obj, k[2:], v)
            elif k.startswith("cm_") and v:
                gen_proto_obj(obj, k[3:], v)
            elif k.startswith("ml_") and v:
                getattr(obj, k[3:]).extend(v)
        return obj


class PlanVariable(Variable):
    def __init__(
        self,
        name: str,
        type: VariableEnum.VariableType,
        value: VariableValue = None,
    ):
        super(PlanVariable, self).__init__(name, type, value)
        self.m_module_name = "rootNode"
        self.m_category = VariableEnum.VariableCategory.PLAN_VAR


class ProjectVariable(Variable):
    def __init__(
            self, name: str,
            type: VariableEnum.VariableType,
            value: VariableValue = None):
        super(ProjectVariable, self).__init__(name, type, value)
        self.m_module_name = "rootNode"
        self.m_category = VariableEnum.VariableCategory.PROJECT_VAR


class GlobalVariable(Variable):
    def __init__(self,
                 name: str,
                 type: VariableEnum.VariableType,
                 value: VariableValue = None):
        super(GlobalVariable, self).__init__(name, type, value)
        self.m_category = VariableEnum.VariableCategory.GLOBAL_VAR
