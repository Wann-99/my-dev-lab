import inspect
import os
import json

import grpc
from loguru import logger

from elements.settings import RobotSetting
from elements.proto.RobotServicePP_pb2_grpc import PPServiceStub
from elements.proto.RobotServicePP_pb2 import RemovePPRequest, PPCmdRequest, AddPPRequest, UpdatePPContentRequest, \
    UpdatePPOptionRequest


class ParallelProgram:
    def __init__(self,
                 setting: RobotSetting = RobotSetting(),
                 port: int = 18001,
                 auto_booted: bool = False,
                 auto_looped: bool = False):
        self._robot_ip = setting.ip
        self._robot_port = port
        self._channel = grpc.insecure_channel(f"{self._robot_ip}:{self._robot_port}")
        self._stub = PPServiceStub(self._channel)
        self._auto_booted = auto_booted
        self._auto_looped = auto_looped
        self._base_dir = setting.base_dir
        self._robot_dir = setting.root_dir

    def _get_funcs(self, code_str: str):
        """
        获取代码中所有的函数名
        :param code_str:
        :return:
        """
        import ast
        tree = ast.parse(code_str)
        funcs = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if hasattr(node.func, "id"):
                    funcs.append(node.func.id)
                elif hasattr(node.func, "value"):
                    funcs.append(node.func.value.id)
        return funcs

    def _get_assigns(self, code_str: str):
        """
        获取代码中所有的赋值语句
        :param code_str:
        :return: {左值: 右值, }
        """
        import ast
        tree = ast.parse(code_str)
        assigns = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                assigns[node.targets[0].id] = node.value.value
        return assigns

    def _get_lua_code(self) -> dict:
        from elements.pythonlua.translator import Translator
        translator = Translator()
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        result = {}
        for method in methods:
            if method[0].startswith("pp_"):
                # 转换所有pp_开头的python方法为lua方法
                pp_name = method[0][3:]
                code = inspect.getsource(method[1])
                signature = inspect.signature(method[1])
                # 定义每个pp的配置, 用户可以通过参数指定
                _auto_booted = self._auto_booted
                _auto_looped = self._auto_looped
                for sign in signature.parameters.values():
                    if sign.name == "auto_booted":
                        _auto_booted = sign.default
                    elif sign.name == "auto_looped":
                        _auto_looped = sign.default
                # 去除第一行def
                # 去除每行的缩进8个空格
                code_str = "\n\n".join(line[8:] for line in code.split("\n")[1:])
                lua_code_str = translator.translate(code_str)
                # 获取pp python中调用的函数
                called_funcs = self._get_funcs(code_str)
                # 获取buitins中定义的的lua函数代码
                with open(os.path.join(self._base_dir, "core/pp/builtins.py"), "r") as f:
                    builtins_code_str = f.read()
                builtin_funcs = self._get_assigns(builtins_code_str)
                for func in called_funcs:
                    if func in builtin_funcs:
                        lua_code_str = builtin_funcs[func] + "\n" + lua_code_str
                result[pp_name] = {
                    "name": pp_name,
                    "code": lua_code_str,
                    "config": json.dumps({
                        "auto_booted": _auto_booted,
                        "auto_looped": _auto_looped,
                    }),
                }
        return result

    def to_lua(self):
        data = self._get_lua_code()
        for pp in data:
            if not os.path.exists(pp):
                os.mkdir(pp)
            else:
                if os.path.isfile(pp):
                    raise Exception(f"{pp} already exists as a file")
            pwd = os.getcwd()
            try:
                os.chdir(pp)
                lua_code_str = data[pp]["code"]
                pp_config = data[pp]["config"]
                # 创建 pp.lua
                with open(f"{pp}.lua", "w") as f:
                    f.write(lua_code_str + "\n")
                # 创建 ppConfig.json
                with open("ppConfig.json", "w") as f:
                    f.write(pp_config)
                # 创建 pp.xml，防止从UI编辑pp时，RCA奔溃
                with open(f"{pp}.xml", "w") as f:
                    f.write("")
            except Exception as e:
                logger.error(e)
            finally:
                os.chdir(pwd)

    def assign(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            ret1 = self._stub.AddPP(AddPPRequest(pp_name=pp))
            # 110000 新的pp，310008 pp已存在
            assert ret1.value in [110000, 310008], f"failed to add pp, ret code: {ret1.value}, ret info: {ret1.info}"
            ret2 = self._stub.UpdatePPContent(
                UpdatePPContentRequest(
                    pp_name=pp,
                    script_file_content=data[pp]["code"] + "\n",
                    blocky_file_content="<xml xmlns='https://developers.google.com/blockly/xml'></xml>\n"
                ))
            assert ret2.value in [110000], f"failed to update pp content, ret: {ret2}"
            ret3 = self._stub.UpdatePPOption(
                UpdatePPOptionRequest(
                    pp_name=pp,
                    pp_auto_booted=json.loads(data[pp]["config"])["auto_booted"],
                    pp_auto_looped=json.loads(data[pp]["config"])["auto_looped"],
                )
            )
            assert ret3.value in [110000], f"failed to update pp option, ret: {ret3}"
            result[pp] = True
        return result

    def remove(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.RemovePP(RemovePPRequest(pp_name=pp))
        return result

    def enable(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.EnablePP(PPCmdRequest(pp_name=pp))
        return result

    def disable(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.DisablePP(PPCmdRequest(pp_name=pp))
        return result

    def pause(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.PausePP(PPCmdRequest(pp_name=pp))
        return result

    def resume(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.ResumePP(PPCmdRequest(pp_name=pp))
        return result

    def start(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.StartPP(PPCmdRequest(pp_name=pp))
        return result

    def stop(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.StopPP(PPCmdRequest(pp_name=pp))
        return result

    def clear_fault(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.ClearFaultPP(PPCmdRequest(pp_name=pp))
        return result


if __name__ == "__main__":
    setting = RobotSetting()
    pp = ParallelProgram(setting=setting)
    # pp.to_lua()
    pp.assign()