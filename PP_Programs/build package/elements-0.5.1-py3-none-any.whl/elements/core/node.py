from abc import ABCMeta

# from elements.core.plan import Plan
from elements.core.enums import PtNameEnum, PtTypeEnum
from elements.core.parameters import SwitchTcpParam


class Node(metaclass=ABCMeta):
    def __init__(self, name: str):
        self.m_node_name = name
        self.m_pt_name = ""
        self.m_pt_type = ""
        self.cm_switch_tcp_param = SwitchTcpParam()
        self.m_is_breakpoint = False
        self.m_lock_external_axes = True
        self.parent = None
        self.transit = None
        self.cm_switch_tcp_param = SwitchTcpParam()
        self.children = []

    @property
    def name(self):
        return self.m_node_name

    def to_graph(self):
        from transitions.extensions import GraphMachine

        machine = GraphMachine(
            model=self,
            states=self.children,
            transitions=[
                {
                    "trigger": self.transit.name,
                    "source": (
                        "Start" if self.parent is None else self.parent.m_node_name
                    ),
                    "dest": self.m_node_name,
                }
            ],
            initial="Start" if self.parent is None else self.parent.m_node_name,
        )
        graph = machine.get_graph()
        graph.node_attr["fontname"] = "Microsoft Yahei"
        graph.node_attr["fontname"] = "Microsoft Yahei"
        graph.graph_attr["fontname"] = "Microsoft Yahei"
        graph.graph_attr["dpi"] = "300"  # 设置分辨率
        graph.graph_attr.pop("label")  # 删除标题
        graph.draw(f"{self.m_node_name}.png", prog="dot")


class RootNode(Node):
    def __init__(self, name: str = "rootNode"):
        super(RootNode, self).__init__(name=name)
        self.m_pt_name = PtNameEnum.Plan.PLAN.value
        self.m_pt_type = PtTypeEnum.Plan.PLAN.value


class StartNode(Node):
    def __init__(self, name: str = "startNode"):
        super().__init__(name=name)
        self.m_pt_name = PtNameEnum.Plan.PLAN.value
        self.m_pt_type = PtTypeEnum.Plan.PLAN.value


class PlanNode(Node):
    def __init__(self, name: str):
        super().__init__(name)
        self.m_pt_name = PtNameEnum.Plan.PLAN.value
        self.m_pt_type = PtTypeEnum.Plan.PLAN.value
