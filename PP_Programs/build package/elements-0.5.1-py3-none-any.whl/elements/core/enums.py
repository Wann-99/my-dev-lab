from enum import Enum, IntEnum

from elements.proto.ProtoPlanParams_pb2 import ProtoPlanParams


class PtNameEnum:
    """enumerate primitive names based on category"""

    class Plan(Enum):
        PLAN = "Plan"

    class Motion(Enum):
        # motion primitives
        MOVEC = "MoveC"
        MOVEJ = "MoveJ"
        MOVEL = "MoveL"
        MOVEPTP = "MovePTP"

    class Workflow(Enum):
        # motion primitives
        HOME = "Home"
        HOLD = "Hold"
        FAULT = "Fault"
        STOP = "Stop"
        END = "End"

    class BasicForceControl(Enum):
        ZEROFTSENSOR = "CaliForceSensor"
        CONTACT = "Contact"
        MOVETRAJ = "MoveTraj"
        MOVECOMP = "MoveCompliance"

    class AdvancedForceControl(Enum):
        CONTACTALIGN = "AlignContact"
        FORCEHYBRID = "MoveHybrid"
        FORCECOMP = "ForceCompliance"

    class AdaptiveAssembly(Enum):
        SEARCHHOLE = "SearchHole"
        CHECKPIH = "PihCheckTran"
        INSERTCOMP = "Sleeve"
        MATE = "Mating"
        FASTENSCREW = "ScrewFasten"

    class ZeroGravityFloating(Enum):
        FLOATINGCARTESIAN = "FloatingCartesian"
        FLOATINGJOINT = "FloatingJoint"

    class SurfaceFinishing(Enum):
        POLISH = "Polish"
        GRIND = "Grind"
        POLISHECP = "PolishECP"
        GRINDECP = "GrindECP"

    class FlexibleHandling(Enum):
        LOCATEPIN = "PinLocating"

    class AdaptiveGrasping(Enum):
        GRASPCOMP = "AdaptiveGrip"

    class RehabilitationPhysiotherapy(Enum):
        MASSAGE = "Massage"

    class VisualServoing(Enum):
        TEACHFEATURE = "VisualServoTeach"
        ALIGNPOINT = "PointIBVS"
        ALIGNPATTERN = "MomentIBVS"

    class Showcase(Enum):
        BALANCEBALL = "BallBalance"
        BALANCEGLASSES = "BalanceGlasses"


class PtTypeEnum:
    """
    enumerate primitive types based on category
    """

    class Plan(Enum):
        PLAN = "PLAN"

    class Motion(Enum):
        # motion primitives
        MOVEC = "MOVEC"
        MOVEJ = "MOVEJ"
        MOVEL = "MOVEL"
        MOVEPTP = "MOVEPTP"

    class Workflow(Enum):
        # workflow primitives
        HOME = "HOME"
        HOLD = "HOLD"
        FAULT = "FAULT"
        STOP = "STOP"
        END = "END"

    class BasicForceControl(Enum):
        ZEROFTSENSOR = "CALIFORCESENSOR"
        CONTACT = "CONTACT"
        MOVETRAJ = "MOVE_TRAJ"
        MOVECOMP = "MOVE_COMPLIANCE"

    class AdvancedForceControl(Enum):
        CONTACTALIGN = "ALIGNCONTACT"
        FORCEHYBRID = "MOVEHYBRID"
        FORCECOMP = "MOVE_COMPLIANCE"

    class AdaptiveAssembly(Enum):
        SEARCHHOLE = "SEARCH_HOLE"
        CHECKPIH = "PIH_CHECK_TRAN"
        INSERTCOMP = "SLEEVE"
        MATE = "MATING"
        FASTENSCREW = "SCREWFASTEN"

    class ZeroGravityFloating(Enum):
        FLOATINGCARTESIAN = "CARTIMPEDANCEFLOATING"
        FLOATINGJOINT = "JNTIMPEDANCEFLOATING"

    class SurfaceFinishing(Enum):
        POLISH = "POLISH"
        GRIND = "GRIND"
        POLISHECP = "POLISHECP"
        GRINDECP = "GRINDECP"

    class FlexibleHandling(Enum):
        LOCATEPIN = "PLAN"

    class AdaptiveGrasping(Enum):
        GRASPCOMP = "ADAPTIVEGRIP"

    class RehabilitationPhysiotherapy(Enum):
        MASSAGE = "MOVEHYBRID"

    class VisualServoing(Enum):
        TEACHFEATURE = "VISUALSERVOTEACH"
        ALIGNPOINT = "POINTIBVS"
        ALIGNPATTERN = "MOMENTIBVS"

    class Showcase(Enum):
        BALANCEBALL = "MPCBALLBALANCING"
        BALANCEGLASSES = "BALANCEGLASSES"


class PtStateEnum:
    """enumerate primitive states"""

    class Home(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"

    class Hold(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"

    class Fault(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"

    class Stop(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"

    class End(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"

    class MoveL(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class MoveJ(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class MovePTP(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class MoveC(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class ZeroFTSensor(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"

    class Contact(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        CurContactForce = "curContactForce"
        ForwardDis = "insertDis"

    class MoveTraj(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class MoveComp(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class ContactAlign(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        AlignContacted = "alignContacted"
        ForwardDis = "insertDis"

    class ForceHybrid(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class ForceComp(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class SearchHole(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        SearchResisForce = "searchResistanceForce"
        PushDis = "pushDistance"
        ForceDrop = "forceDrop"
        LostContact = "lostContact"

    class CheckPiH(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        CheckComplete = "checkComplete"
        PegIsInHole = "pegIsInHole"

    class InsertComp(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        IsMoving = "isMoving"
        InsertDis = "insertDis"

    class Mate(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        MatingFinish = "matingFinished"

    class FastenScrew(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        InsertDis = "insertDis"
        InsertVel = "insertVel"
        FastenState = "fastenState"
        ReachedHole = "reachedScrewHole"

    class Polish(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class Grind(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class PolishECP(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class GrindECP(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class LocatePin(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"

    class GraspComp(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        CurGripWidth = "curWidth"
        ReachGripForce = "reachedForce"
        ReachGripWidth = "reachedWidth"
        IsGripMoving = "isMoving"
        GripComplete = "graspComplete"

    class FloatingCartesian(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        IdleTime = "idleTime"

    class FloatingJoint(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        IdleTime = "idleTime"

    class Massage(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"

    class TeachFeature(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"

    class AlignPoint(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        FeatureAligned = "reachedTarget"

    class AlignPattern(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        FeatureAligned = "reachedTarget"

    class BalanceBall(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"

    class BalanceGlasses(Enum):
        Terminated = "terminated"
        TimePeriod = "timePeriod"
        ReachedTarget = "reachedTarget"
        WaypointIndex = "waypointIndex"


class PtParameterEnum:

    class ParameterCategory(Enum):
        PT_INPUT = "PT_INPUT"

    class AdvancedForceControl:
        class ContactAlign:
            class Basic(Enum):
                ContactAxis = {"name": "contactDir", "type": "VEC_3d"}
                ContactVel = {"name": "freeSpaceVel", "type": "DOUBLE"}
                ContactForce = {"name": "targetForce", "type": "DOUBLE"}
                AlignAxis = {"name": "alignmentDir", "type": "VEC_6i"}
                AlignVelScale = {"name": "alignVelScale", "type": "DOUBLE"}

            class Advanced(Enum):
                DeadbandScale = {"name": "deadbandScale", "type": "DOUBLE"}

        class ForceHybrid:
            class Basic(Enum):
                Target = {"name": "target", "type": "COORD"}
                Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                Wrench = {"name": "wrench", "type": "ARRAY_VEC_6d"}
                Vel = {"name": "maxVel", "type": "DOUBLE"}
                ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                ForceCoord = {"name": "forceCoord", "type": "COORD"}
                ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}
                TargetWrench = {"name": "goalWrench", "type": "VEC_6d"}
                StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}

            class Advanced(Enum):
                Acc = {"name": "maxAcc", "type": "DOUBLE"}
                AngVel = {"name": "maxW", "type": "DOUBLE"}
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                ConfigOptObj = {"name": "nullspaceGradientScaling", "type": "VEC_3d"}
                EnableMaxWrench = {"name": "enableMaxContactWrench", "type": "VEC_6i"}
                MaxContactWrench = {"name": "maxContactWrench", "type": "VEC_6d"}
                MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}

        class ForceComp(Enum):
            class Basic(Enum):
                Target = {"name": "target", "type": "COORD"}
                Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                Vel = {"name": "maxVel", "type": "DOUBLE"}
                ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                CompCoord = {"name": "compCoord", "type": "COORD"}
                StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}

            class Advanced(Enum):
                EnableMaxWrench = {"name": "enableMaxContactWrench", "type": "VEC_6i"}
                MaxContactWrench = {"name": "maxContactWrench", "type": "VEC_6d"}
                Acc = {"name": "maxAcc", "type": "DOUBLE"}
                AngVel = {"name": "maxW", "type": "DOUBLE"}
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                ConfigOptObj = {"name": "nullspaceGradientScaling", "type": "VEC_3d"}

    class BasicForceControl:

        class ZeroFTSensor:
            class Basic(Enum):
                DataCollectTime = {"name": "dataCollectionTime", "type": "DOUBLE"}
                EnableStaticCheck = {"name": "enableStaticCheck", "type": "BOOL"}

            class Advanced(Enum):
                CalibExtraPayload = {"name": "calibrateExtraLoad", "type": "BOOL"}

        class Contact(Enum):
            class Basic(Enum):
                ContactCoord = {"name": "coord", "type": "TYPE"}
                ContactDir = {"name": "movingDir", "type": "VEC_3d"}
                ContactVel = {"name": "contactVel", "type": "DOUBLE"}
                MaxContactForce = {"name": "maxContactForce", "type": "DOUBLE"}
                EnableFineContact = {"name": "fineContactMode", "type": "BOOL"}

            class Advanced(Enum):
                Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                Vel = {"name": "maxVel", "type": "ARRAY_DOUBLE"}
                Acc = {"name": "maxAcc", "type": "ARRAY_DOUBLE"}
                ZoneRadius = {"name": "zoneRadius", "type": "ARRAY_TYPE"}
                Jerk = {"name": "maxJerk", "type": "DOUBLE"}

        class MoveComp(Enum):
            class Basic(Enum):
                Target = {"name": "target", "type": "COORD"}
                Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                Vel = {"name": "maxVel", "type": "DOUBLE"}
                ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                CompCoord = {"name": "compCoord", "type": "COORD"}
                CompAxis = {"name": "compAxis", "type": "VEC_6i"}

            class Advanced(Enum):
                Acc = {"name": "maxAcc", "type": "DOUBLE"}
                AngVel = {"name": "maxW", "type": "DOUBLE"}
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                ConfigOptObj = {"name": "nullspaceGradientScaling", "type": "VEC_3d"}

        class MoveTraj:
            class Basic(Enum):
                TrajFileName = {"name": "fileName", "type": "FILE"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                ForceCoord = {"name": "forceCoord", "type": "COORD"}
                ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}

            class Advanced(Enum):
                ConfigOptObj = {"name": "nullspaceGradientScaling", "type": "VEC_3d"}
                MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}
                AngVel = {"name": "maxW", "type": "DOUBLE"}
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                Jerk = {"name": "maxJerk", "type": "DOUBLE"}

    class AdaptiveAssembly:
        class SearchHole:
            class Basic(Enum):
                ContactAxis = {"name": "contactAxis", "type": "VEC_3d"}
                ContactForce = {"name": "contactForce", "type": "DOUBLE"}
                SearchAxis = {"name": "searchAxis", "type": "VEC_3d"}
                SearchPattern = {"name": "patternType", "type": "TYPE"}
                SpiralRadius = {"name": "radius", "type": "DOUBLE"}
                ZigZagLength = {"name": "length", "type": "DOUBLE"}
                ZigZagWidth = {"name": "height", "type": "DOUBLE"}
                StartDensity = {"name": "startDensity", "type": "INT"}
                TimeFactor = {"name": "timeFactor", "type": "INT"}
                WiggleRange = {"name": "wiggleRange", "type": "DOUBLE"}
                WigglePeriod = {"name": "wigglePeriod", "type": "DOUBLE"}

            class Advanced(Enum):
                SearchImmed = {"name": "startSearchImmediately", "type": "BOOL"}
                SerchStiffRatio = {"name": "searchStiffnessRatio", "type": "DOUBLE"}
                MaxVelForceDir = {"name": "forceCtrlVelLimit", "type": "DOUBLE"}

        class CheckPiH:
            class Basic(Enum):
                ContactAxis = {"name": "contactAxis", "type": "VEC_3d"}
                SearchAxis = {"name": "searchAxis", "type": "VEC_3d"}
                SearchRange = {"name": "searchRange", "type": "DOUBLE"}
                SearchForce = {"name": "searchForce", "type": "DOUBLE"}
                SearchVel = {"name": "searchVelocity", "type": "DOUBLE"}
                LinearSearchOnly = {"name": "lineSearchOnly", "type": "BOOL"}

        class InsertComp:
            class Basic(Enum):
                InsertAxis = {"name": "insertDir", "type": "TYPE"}
                CompAxis = {"name": "alignmentDir", "type": "VEC_6i"}
                MaxContactForce = {"name": "maxContactForce", "type": "DOUBLE"}
                InsertVel = {"name": "insertVel", "type": "DOUBLE"}

            class Advanced(Enum):
                DeadbandScale = {"name": "deadbandScale", "type": "DOUBLE"}
                CompVelScale = {"name": "adjustVelScale", "type": "DOUBLE"}

        class Mate:
            class Basic(Enum):
                ContactAxis = {"name": "forceDir", "type": "VEC_3i"}
                ContactForce = {"name": "matingForce", "type": "DOUBLE"}
                MatingAxis = {"name": "matingDir", "type": "VEC_6i"}
                SlideMatingRange = {"name": "linearMatingRange", "type": "DOUBLE"}
                SlideMatingVel = {"name": "maxLinearMatingVel", "type": "DOUBLE"}
                SlideMatingAcc = {"name": "maxLinearMatingAcc", "type": "DOUBLE"}
                RotateMatingRange = {"name": "angularMatingRange", "type": "DOUBLE"}
                RotateMatingVel = {"name": "maxAngularMatingVel", "type": "DOUBLE"}
                RotateMatingAcc = {"name": "maxAngularMatingAcc", "type": "DOUBLE"}
                MatingTimes = {"name": "totalMatingTimes", "type": "INT"}
                MaxContactDis = {"name": "maxMotionDisInForceDir", "type": "DOUBLE"}
                SafetyForce = {"name": "safetyForce", "type": "DOUBLE"}

            class Advanced(Enum):
                AddMatingAxis = {"name": "rasterDir", "type": "VEC_6i"}
                AddSlideMatingRange = {"name": "linearRasterRange", "type": "DOUBLE"}
                AddSlideMatingVel = {"name": "maxLinearRasterVel", "type": "DOUBLE"}
                AddSlideMatingAcc = {"name": "maxLinearRasterAcc", "type": "DOUBLE"}
                AddRotateMatingRange = {"name": "angularRasterRange", "type": "DOUBLE"}
                AddRotateMatingVel = {"name": "maxAngularRasterVel", "type": "DOUBLE"}
                AddRotateMatingAcc = {"name": "maxAngularRasterAcc", "type": "DOUBLE"}
                MaxVelForceDir = {"name": "maxVelInForceDir", "type": "DOUBLE"}

        class FastenScrew:
            class Basic(Enum):
                InsertDir = {"name": "insertDir", "type": "TYPE"}
                MaxInsertVel = {"name": "insertVel", "type": "DOUBLE"}
                InsertForce = {"name": "maxContactForce", "type": "DOUBLE"}
                StiffScale = {"name": "stiffnessScale", "type": "DOUBLE"}

            class Advanced(Enum):
                DiScrewInHole = {"name": "ioScrewInHole", "type": "TYPE"}
                DiFastenFinish = {"name": "ioFinish", "type": "TYPE"}
                DiScrewJam = {"name": "ioScrewJam", "type": "TYPE"}

    class Motion:
        class MoveC:
            class Basic(Enum):
                Target = {"name": "target", "type": "COORD"}
                MiddlePose = {"name": "middlePose", "type": "COORD"}
                Vel = {"name": "maxVel", "type": "DOUBLE"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}

            class Advanced(Enum):
                Acc = {"name": "maxAcc", "type": "DOUBLE"}
                AngVel = {"name": "maxW", "type": "DOUBLE"}
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                ConfigOptObj = {"name": "nullspaceGradientScaling", "type": "VEC_3d"}

        class MoveJ:
            class Basic(Enum):
                Target = {"name": "target", "type": "JPOS"}
                Waypoints = {"name": "waypoints", "type": "ARRAY_JPOS"}
                JntVelScale = {"name": "jntVelScale", "type": "INT"}
                ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}

            class Advanced(Enum):
                EnableRelativeMove = {"name": "relativeToStart", "type": "BOOL"}
                JntAccMultiplier = {"name": "jntAccMultiplier", "type": "DOUBLE"}

        class MoveL:
            class Basic(Enum):
                Target = {"name": "target", "type": "COORD"}
                Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                Vel = {"name": "maxVel", "type": "DOUBLE"}
                ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}

            class Advanced(Enum):
                Acc = {"name": "maxAcc", "type": "DOUBLE"}
                AngVel = {"name": "maxW", "type": "DOUBLE"}
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                ConfigOptObj = {"name": "nullspaceGradientScaling", "type": "VEC_3d"}

        class MovePTP:
            class Basic(Enum):
                Target = {"name": "target", "type": "COORD"}
                Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                JntVelScale = {"name": "jntVelScale", "type": "INT"}
                ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}

            class Advanced(Enum):
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                JntAccMultiplier = {"name": "jntAccMultiplier", "type": "DOUBLE"}

    class Workflow:

        class Home:
            class Basic(Enum):
                Target = {"name": "target", "type": "JPOS"}
                JntVelScale = {"name": "jntVelScale", "type": "INT"}

            class Advanced(Enum):
                JntAccMultiplier = {"name": "jntAccMultiplier", "type": "DOUBLE"}

        class Hold:
            pass

        class End:
            pass

        class Stop:
            pass

        class Fault:
            class Basic(Enum):
                ErrorMessage = {"name": "errorMessage", "type": "MSG"}

    class ZeroGravityFloating:

        class FloatingCartesian:
            class Basic(Enum):
                FloatingAxis = {"name": "cartFloatingAxis", "type": "VEC_6i"}
                EnableElbowMotion = {"name": "enableJointFloating", "type": "BOOL"}
                FloatingCoord = {"name": "floatingCoord", "type": "COORD"}
                DampingLevel = {"name": "resistanceLevel", "type": "VEC_6d"}

            class Advanced(Enum):
                DiEnableFloating = {"name": "diEnableFloating", "type": "TYPE"}
                ResponseTorque = {"name": "jointTorqueDeadBand", "type": "VEC_7d"}

        class FloatingJoint:
            class Basic(Enum):
                FloatingJoint = {"name": "jntFloatingAxis", "type": "VEC_7d"}
                DampingLevel = {"name": "resistanceLevel", "type": "VEC_7d"}

            class Advanced(Enum):
                ResponseTorque = {"name": "jointTorqueDeadBand", "type": "VEC_7d"}
                DiEnableFloating = {"name": "diEnableFloating", "type": "TYPE"}

    class SurfaceFinishing:
        class Polish:
            class Basic(Enum):
                TrajFileName = {"name": "fileName", "type": "FILE"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                ForceCoord = {"name": "forceCoord", "type": "COORD"}
                ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}
                ILCEnableType = {"name": "ILCEnableType", "type": "TYPE"}
                ILCFileName = {"name": "ILCFileName", "type": "STRING"}

            class Advanced(Enum):
                AngVel = {"name": "maxW", "type": "DOUBLE"}
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                ConfigOptObj = {"name": "nullspaceGradientScaling", "type": "VEC_3d"}
                EnableForceAutoRot = {"name": "enableForceAutoRotation", "type": "BOOL"}
                ForceRotAxis = {"name": "ForceRotationAxis", "type": "VEC_3d"}
                EnableContactAngle = {"name": "enableContactAngle", "type": "BOOL"}
                ContactAngle = {"name": "contactAngle", "type": "DOUBLE"}
                ContactRotAxis = {"name": "rotAxis", "type": "VEC_3d"}
                ContactRotRadius = {"name": "rotRadius", "type": "DOUBLE"}
                EnableTrajOverlay = {"name": "enableTrajOverlay", "type": "BOOL"}
                OverlaidTrajType = {"name": "overlaidTrajType", "type": "INT"}
                Amplitude = {"name": "amplitude", "type": "DOUBLE"}
                Pitch = {"name": "pitch", "type": "DOUBLE"}
                LineSpace = {"name": "lineSpace", "type": "DOUBLE"}
                MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}
                EnableTransLimit = {"name": "enableTransLimit", "type": "BOOL"}
                MaxTransDisp = {"name": "maxTransDisp", "type": "DOUBLE"}
                MinTransDisp = {"name": "minTransDisp", "type": "DOUBLE"}
                EnableOrientLimit = {"name": "enableOrientLimit", "type": "BOOL"}
                ToolRadius = {"name": "toolRadius", "type": "DOUBLE"}
                MaxOrientAngle = {"name": "maxOrientAngle", "type": "DOUBLE"}

        class Grind:
            class Basic(Enum):
                TrajFileName = {"name": "fileName", "type": "FILE"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                ForceCoord = {"name": "forceCoord", "type": "COORD"}
                ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}
                ILCEnableType = {"name": "ILCEnableType", "type": "TYPE"}
                ILCFileName = {"name": "ILCFileName", "type": "STRING"}

            class Advanced(Enum):
                AngVel = {"name": "maxW", "type": "DOUBLE"}
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                ConfigOptObj = {"name": "nullspaceGradientScaling", "type": "VEC_3d"}
                EnableForceAutoRot = {"name": "enableForceAutoRotation", "type": "BOOL"}
                ForceRotAxis = {"name": "ForceRotationAxis", "type": "VEC_3d"}
                EnableContactAngle = {"name": "enableContactAngle", "type": "BOOL"}
                ContactAngle = {"name": "contactAngle", "type": "DOUBLE"}
                ContactRotAxis = {"name": "rotAxis", "type": "VEC_3d"}
                ContactRotRadius = {"name": "rotRadius", "type": "DOUBLE"}
                EnableTrajOverlay = {"name": "enableTrajOverlay", "type": "BOOL"}
                OverlaidTrajType = {"name": "overlaidTrajType", "type": "INT"}
                Amplitude = {"name": "amplitude", "type": "DOUBLE"}
                Pitch = {"name": "pitch", "type": "DOUBLE"}
                LineSpace = {"name": "lineSpace", "type": "DOUBLE"}
                MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}
                EnableTransLimit = {"name": "enableTransLimit", "type": "BOOL"}
                MaxTransDisp = {"name": "maxTransDisp", "type": "DOUBLE"}
                MinTransDisp = {"name": "minTransDisp", "type": "DOUBLE"}
                EnableOrientLimit = {"name": "enableOrientLimit", "type": "BOOL"}
                ToolRadius = {"name": "toolRadius", "type": "DOUBLE"}
                MaxOrientAngle = {"name": "maxOrientAngle", "type": "DOUBLE"}

        class PolishECP:
            class Basic(Enum):
                TrajFileName = {"name": "fileName", "type": "FILE"}
                ECPCoord = {"name": "ECPCoord", "type": "COORD"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}
                ILCEnableType = {"name": "ILCEnableType", "type": "TYPE"}
                ILCFileName = {"name": "ILCFileName", "type": "STRING"}

            class Advanced(Enum):
                AngVel = {"name": "maxW", "type": "DOUBLE"}
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                ConfigOptObj = {"name": "nullspaceGradientScaling", "type": "VEC_3d"}
                EnableTrajOverlay = {"name": "enableTrajOverlay", "type": "BOOL"}
                OverlaidTrajType = {"name": "overlaidTrajType", "type": "INT"}
                Amplitude = {"name": "amplitude", "type": "DOUBLE"}
                Pitch = {"name": "pitch", "type": "DOUBLE"}
                LineSpace = {"name": "lineSpace", "type": "DOUBLE"}
                MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}

        class GrindECP:
            class Basic(Enum):
                TrajFileName = {"name": "fileName", "type": "FILE"}
                ECPCoord = {"name": "ECPCoord", "type": "COORD"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}
                ILCEnableType = {"name": "ILCEnableType", "type": "TYPE"}
                ILCFileName = {"name": "ILCFileName", "type": "STRING"}

            class Advanced(Enum):
                AngVel = {"name": "maxW", "type": "DOUBLE"}
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                ConfigOptObj = {"name": "nullspaceGradientScaling", "type": "VEC_3d"}
                EnableTrajOverlay = {"name": "enableTrajOverlay", "type": "BOOL"}
                OverlaidTrajType = {"name": "overlaidTrajType", "type": "INT"}
                Amplitude = {"name": "amplitude", "type": "DOUBLE"}
                Pitch = {"name": "pitch", "type": "DOUBLE"}
                LineSpace = {"name": "lineSpace", "type": "DOUBLE"}
                MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}

    class FlexibleHandling:
        class LocatePin:
            class Basic(Enum):
                InsertDir = {"name": "insertDir", "type": "TYPE"}
                RotationRange = {"name": "rotationRange", "type": "DOUBLE"}
                ApproachVel = {"name": "approachVel", "type": "DOUBLE"}
                RetractVel = {"name": "retractVel", "type": "DOUBLE"}

            class Advanced(Enum):
                InsertForce = {"name": "insertForce", "type": "DOUBLE"}
                RotationVelScale = {"name": "rotationVelScale", "type": "DOUBLE"}
                TargetContactTorque = {"name": "targetContactTorque", "type": "DOUBLE"}
                SearchCycles = {"name": "searchCycles", "type": "INT"}
                InslotWaitTime = {"name": "inSlotWaitTime", "type": "DOUBLE"}
                DeadbandScale = {"name": "deadbandScale", "type": "DOUBLE"}
                AlignVelScale = {"name": "alignVelScale", "type": "DOUBLE"}
                SafetyForce = {"name": "safetyForce", "type": "DOUBLE"}

    class AdaptiveGrasping:
        class GraspComp:
            class Basic(Enum):
                GripperType = {"name": "gripperType", "type": "TYPE"}
                GripVel = {"name": "gripSpeed", "type": "DOUBLE"}
                GripWidth = {"name": "gripWidth", "type": "DOUBLE"}
                GripForce = {"name": "maxGripForce", "type": "DOUBLE"}
                ContactAxis = {"name": "contactDir", "type": "VEC_3i"}
                ContactForce = {"name": "contactForce", "type": "VEC_3d"}
                CompAxis = {"name": "compliantDir", "type": "VEC_3i"}
                CompForce = {"name": "compliantForce", "type": "VEC_3d"}

            class Advanced(Enum):
                MaxVelForceDir = {"name": "maxVelInForceDir", "type": "DOUBLE"}

    class RehabilitationPhysiotherapy:
        class Massage:
            class Basic(Enum):
                Target = {"name": "target", "type": "COORD"}
                TargetWrench = {"name": "goalWrench", "type": "VEC_6d"}
                Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                Wrench = {"name": "wrench", "type": "ARRAY_VEC_6d"}
                Vel = {"name": "maxVel", "type": "DOUBLE"}
                ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                ForceCoord = {"name": "forceCoord", "type": "COORD"}
                ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}
                StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}
                EnableMaxWrench = {"name": "enableMaxContactWrench", "type": "VEC_6i"}
                MaxContactWrench = {"name": "maxContactWrench", "type": "VEC_6d"}
                EnableEntryPoint = {"name": "enableEntry", "type": "BOOL"}
                MaxWrenchPause = {"name": "pauseAtMaxWrench", "type": "BOOL"}
                MotionForceDecouple = {"name": "decoupleActuation", "type": "BOOL"}
                WrenchFilterCutoff = {"name": "wrenchFilterCutoff", "type": "DOUBLE"}

            class Advanced(Enum):
                Acc = {"name": "maxAcc", "type": "DOUBLE"}
                Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                AngVel = {"name": "maxW", "type": "DOUBLE"}
                EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                ConfigOptObj = {"name": "nullspaceGradientScaling", "type": "VEC_3d"}
                MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}
                LineSpace = {"name": "lineSpace", "type": "DOUBLE"}
                Amplitude = {"name": "amplitude", "type": "DOUBLE"}
                Pitch = {"name": "pitch", "type": "DOUBLE"}

    class VisualServoing:
        class TeachFeature:
            class Basic(Enum):
                ObjName = {"name": "objName", "type": "OBJNAME"}
                ObjIndex = {"name": "objIdx", "type": "INT"}
                CollectTimes = {"name": "sampleNum", "type": "INT"}

        class AlignPoint:
            class Basic(Enum):
                TargetFeaturePoint = {
                    "name": "targetFeaturePoints",
                    "type": "ARRAY_VEC_2d",
                }
                TargetDepth = {"name": "targetDepth", "type": "ARRAY_DOUBLE"}
                MotionAxis = {"name": "motionAxis", "type": "VEC_6i"}
                MaxVel = {"name": "maxVel", "type": "DOUBLE"}
                MaxAngVel = {"name": "maxRotVel", "type": "DOUBLE"}
                VelScale = {"name": "velScale", "type": "DOUBLE"}
                ImageConvToler = {"name": "imgConvTol", "type": "DOUBLE"}
                ObjName = {"name": "objName", "type": "OBJNAME"}
                ObjIndex = {"name": "objIdx", "type": "INT"}

            class Advanced(Enum):
                EnableObjAlign = {"name": "enableObjAlign", "type": "BOOL"}
                AlignObjPoint = {"name": "targetMatchObjPts", "type": "ARRAY_VEC_2d"}
                OptVelScale = {"name": "optVelScale", "type": "VEC_2d"}
                VisualDtectNoise = {"name": "AIDetectNoise", "type": "ARRAY_VEC_2d"}

        class AlignPattern:
            class Basic(Enum):
                TargetFeaturePattern = {
                    "name": "targetFeaturePoints",
                    "type": "ARRAY_VEC_2d",
                }
                TargetDepth = {"name": "targetDepth", "type": "ARRAY_DOUBLE"}
                MotionAxis = {"name": "motionAxis", "type": "VEC_6i"}
                MaxVel = {"name": "maxVel", "type": "DOUBLE"}
                MaxAngVel = {"name": "maxRotVel", "type": "DOUBLE"}
                RectangleFeature = {"name": "rectangleObject", "type": "BOOL"}
                VelScale = {"name": "vsKp", "type": "VEC_6d"}
                ImageConvToler = {"name": "imgConvTol", "type": "DOUBLE"}
                ObjName = {"name": "objName", "type": "OBJNAME"}
                ObjIndex = {"name": "objIdx", "type": "INT"}

    class Showcase:
        class BalanceBall:
            class Basic(Enum):
                BallWeight = {"name": "ballWeight", "type": "DOUBLE"}
                BallFricCoeff = {"name": "ballFrictionCoeff", "type": "DOUBLE"}
                PattenType = {"name": "trajType", "type": "TYPE"}
                COPOffsetX = {"name": "COPOffsetX", "type": "DOUBLE"}
                COPOffsetY = {"name": "COPOffsetY", "type": "DOUBLE"}

            class Advanced(Enum):
                PattenSizeScale = {"name": "pathScale", "type": "DOUBLE"}
                FreScale = {"name": "freScale", "type": "DOUBLE"}

        class BalanceGlasses:
            class Basic(Enum):
                Target = {"name": "target", "type": "COORD"}
                Duration = {"name": "duration", "type": "DOUBLE"}
                Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}


class TransitConditionEnum:
    """define all enums in transit conditions"""

    class ConditionType(Enum):
        NO_CHECK = "NO_CHECK"
        OR = "OR"
        AND = "AND"
        EQUAL = "EQUAL"
        GREATER = "GREATER"
        LESS = "LESS"
        GREATER_EQUAL = "GREATER_EQUAL"
        LESS_EQUAL = "LESS_EQUAL"

    class ConditionValue(Enum):
        NO_CHECK = "NO_CHECK"
        OR = "||"
        AND = "&&"
        EQUAL = "=="
        GREATER = ">"
        LESS = ">"
        GREATER_EQUAL = ">="
        LESS_EQUAL = "<="

    class InputParameterName:

        class Home(Enum):
            Target = "target"
            JntVelScale = "jntVelScale"

        class Hold(Enum):
            pass

        class SubPlan(Enum):
            RepeatTimes = "repeatTimes"
            EnableForceLimit = "enableForceLimit"
            ForceLimit = "forceLimit"
            EnableExtJntTrqLimit = "enableExtJntTrqLimit"
            ExtJntTrqLimit = "extJntTrqLimit"

        class Stop(Enum):
            pass

        class End(Enum):
            pass

        class Fault(Enum):
            ErrorMessage = "errorMessage"

        class MoveL(Enum):
            Target = "target"
            Waypoints = "waypoints"
            Vel = "vel"
            ZoneRadius = "zoneRadius"
            TargetTolerLevel = "targetTolerLevel"
            Acc = "acc"
            AngVel = "angVel"
            Jerk = "jerk"
            ConfigOptObj = "configOptObj"

        class MoveJ(Enum):
            Target = "target"
            Waypoints = "waypoints"
            JntVelScale = "jntVelScale"
            ZoneRadius = "zoneRadius"
            TargetTolerLevel = "targetTolerLevel"
            EnableRelativeMove = "enableRelativeMove"

        class MovePTP(Enum):
            Target = "target"
            Waypoints = "waypoints"
            JntVelScale = "jntVelScale"
            ZoneRadius = "zoneRadius"
            TargetTolerLevel = "targetTolerLevel"

        class MoveC(Enum):
            Target = "target"
            MiddlePose = "middlePose"
            Vel = "vel"
            TargetTolerLevel = "targetTolerLevel"
            Acc = "acc"
            AngVel = "angVel"
            Jerk = "jerk"
            ConfigOptObj = "configOptObj"

        class ZeroFTSensor(Enum):
            DataCollectTime = "dataCollectTime"
            EnableStaticCheck = "enableStaticCheck"
            CalibExtraPayload = "calibExtraPayload"

        class Plan(Enum):
            LoopCounter = "loopCounter"

        class FlexivGN01(Enum):
            State = "state"
            Width = "width"
            Force = "force"
            ReachedForce = "reachedForce"
            ReachedWidth = "reachedWidth"
            Moving = "moving"
            ReCalliDone = "reCalliDone"
            FaultWord = "faultWord"

    class ParameterType(Enum):
        BOOL = "BOOL"
        INT = "INT"
        TYPE = "TYPE"
        DOUBLE = "DOUBLE"
        STRING = "STRING"

    class ParameterCategory(Enum):
        PT_STATE = "PT_STATE"
        PLAN_STATE = "PLAN_STATE"
        DEVICE_STATE = "DEVICE_STATE"
        PLAN_VAR = "PLAN_VAR"
        CONST = "CONST"

    class ParameterGripperData(Enum):
        UNKNOWN = "GRIPPER_UNKNOWN"
        OK = "GRIPPER_OK"
        ERROR = "GRIPPER_ERROR"


class ToolNameEnum(Enum):
    FLANGE = "Flange"


class SoftwareVersionEnum(IntEnum):
    VER_3_08 = ProtoPlanParams.VER_3_08
    VER_3_09 = ProtoPlanParams.VER_3_09


class VariableEnum:

    class VariableCategory(Enum):
        PLAN_VAR = "PLAN_VAR"
        PROJECT_VAR = "PROJ_VAR"
        GLOBAL_VAR = "GLOBAL_VAR"

    class VariableType(Enum):
        INT = "INT"
        DOUBLE = "DOUBLE"
        STRING = "STRING"
        BOOL = "BOOL"

        COORD = "COORD"
        JPOS = "JPOS"
        POSE = "POSE"

        VEC_2D = "VEC_2d"
        VEC_3D = "VEC_3d"
        VEC_4D = "VEC_4d"
        VEC_6D = "VEC_6d"
        VEC_7D = "VEC_7d"
        VEC_2I = "VEC_2i"
        VEC_3I = "VEC_3i"
        VEC_6I = "VEC_6i"

        ARRAY_INT = "ARRAY_INT"
        ARRAY_DOUBLE = "ARRAY_DOUBLE"
        ARRAY_STRING = "ARRAY_STRING"
        ARRAY_COORD = "ARRAY_COORD"
        ARRAY_JPOS = "ARRAY_JPOS"
        ARRAY_POSE = "ARRAY_POSE"
        ARRAY_BOOL = "ARRAY_BOOL"
        ARRAY_VEC_2D = "ARRAY_VEC_2d"
        ARRAY_VEC_3D = "ARRAY_VEC_3d"
        ARRAY_VEC_4D = "ARRAY_VEC_4d"
        ARRAY_VEC_6D = "ARRAY_VEC_6d"
        ARRAY_VEC_7D = "ARRAY_VEC_7d"
        ARRAY_VEC_2I = "ARRAY_VEC_2i"
        ARRAY_VEC_3I = "ARRAY_VEC_3i"
        ARRAY_VEC_6I = "ARRAY_VEC_6i"


class RobotUnit(Enum):
    DEGREE = "m-deg"
