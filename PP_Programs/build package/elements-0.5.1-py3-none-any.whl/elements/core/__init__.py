from enum import Enum


# m_ 简单变量 simple member
# ml_ 简单变量列表 simple member list
# cm_ 复合变量 complex member
# cml_ 复合变量列表 complex member list
def gen_proto_obj(obj, sub_obj_name, sub_obj_value):
    sub_obj = getattr(obj, sub_obj_name)
    for sub_k, sub_v in sub_obj_value.__dict__.items():
        if sub_k.startswith("m_"):
            if isinstance(sub_v, Enum):
                setattr(sub_obj, sub_k[2:], sub_v.value)
            else:
                setattr(sub_obj, sub_k[2:], sub_v)
        elif sub_k.startswith("cm_") and sub_v:
            gen_proto_obj(sub_obj, sub_k[3:], sub_v)
        elif sub_k.startswith("ml_") and sub_v:
            getattr(sub_obj, sub_k[3:]).extend(sub_v)
        elif sub_k.startswith("cml_") and sub_v:
            sub_v_objs = []
            for item in sub_v:
                sub_v_objs.append(item.to_proto())
            getattr(sub_obj, sub_k[4:]).extend(sub_v_objs)
