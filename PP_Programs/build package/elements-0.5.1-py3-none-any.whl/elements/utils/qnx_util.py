import pexpect
from loguru import logger

from elements.settings import RobotSetting
from elements.common.exception import RobotConnectionException


class QnxUtil:

    @staticmethod
    def run_cmd(command: str, setting: RobotSetting = RobotSetting()) -> str:
        try:
            child = pexpect.spawn(f"telnet {setting.ip} {setting.telnet_port}", timeout=3)
            child.expect("login:")
            child.sendline(setting.username)
            child.expect(
                f"{setting.username}\r\nPassword for {setting.username}@localhost:"
            )
            child.sendline(setting.password)
            child.expect("#")
            child.sendline(command)
            child.expect("#")
            content = child.before.decode("utf-8").strip("\r\n")
            child.close()
            return content
        except pexpect.exceptions.TIMEOUT:
            logger.error(f"failed to connect to QNX server {setting.ip}")
            raise RobotConnectionException(f"{setting.ip}:{setting.telnet_port}")

    @staticmethod
    def get_datetime_info():
        content = QnxUtil.run_cmd(command="date '+%Y-%m-%d %H:%M:%S'")
        return content

    @staticmethod
    def get_cpu_info():
        content = QnxUtil.run_cmd(command="top -i 1")
        return content

    @staticmethod
    def get_cpu_runtime_info():
        content = QnxUtil.run_cmd(command="top -i 1")
        return content

    @staticmethod
    def get_memory_info():
        content = QnxUtil.run_cmd(command="top -i 1")
        return content

    @staticmethod
    def get_disk_info():
        content = QnxUtil.run_cmd(command="df -hP")
        return content


class QnxClientUtil:

    @staticmethod
    def get_cpu_info() -> str:
        content = QnxUtil.get_cpu_info()
        content = content.split("\r\n")
        for item in content:
            # CPU states: 7.5% user, 0.0% kernel
            if item.startswith("CPU states:"):
                return item[len("CPU states: ") :]
        return ""

    @staticmethod
    def get_memory_info() -> str:
        content = QnxUtil.get_memory_info()
        content = content.split("\r\n")
        for item in content:
            if item.startswith("Memory:"):
                # Memory: 16277M total, 13167M avail, page size 4K
                total = round(
                    int(
                        item[len("Memory: ") :].split(",")[0].strip().split(" ")[0][:-1]
                    )
                    / 1024,
                    2,
                )
                avail = round(
                    int(
                        item[len("Memory: ") :].split(",")[1].strip().split(" ")[0][:-1]
                    )
                    / 1024,
                    2,
                )
                used = str(round((total - avail) / total, 2) * 100) + "%"
                return f"Total: {total}G, Available: {avail}G, Used PCT: {used}"
        return ""

    @staticmethod
    def get_disk_info() -> str:
        content = QnxUtil.get_disk_info()
        content = content.split("\r\n")
        for item in content:
            if "/root/mnt/" in item:
                # /dev/hd0t179                119G       13G      106G      11%  /root/mnt/
                total = item.split()[1]
                avail = item.split()[3]
                used = item.split()[4]
                return f"Total: {total}, Available: {avail}, Used PCT: {used}"
        return ""

    @staticmethod
    def get_cpu_runtime_info() -> str:
        content = QnxUtil.get_cpu_runtime_info()
        content = content.split("\r\n")
        for index, item in enumerate(content):
            if item.startswith("      PID"):
                return "\r\n".join(content[index : 10 + index])
        return ""
