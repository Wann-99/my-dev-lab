import numpy as np

from elements.robot.Robot import Robot
from elements.settings import BASE_DIR


class Rizon4(Robot):

    def __init__(self):

        links, name, urdf_string, urdf_filepath = Robot.URDF_read(
            file_path="data/flexiv_description/urdf/A02L-M4.urdf",
            tld=BASE_DIR,
        )

        super().__init__(
            links,
            name=name,
            manufacturer="Flexiv",
            gripper_links=None,
            urdf_string=urdf_string,
            urdf_filepath=urdf_filepath,
        )

        self.qdlim = np.array(
            [2.0944, 2.0944, 2.4435, 2.4435, 4.8869, 4.8869, 4.8869]
        )

        self.qr = np.array([0, -np.pi/180*40, 0, np.pi/180*90, 0, np.pi/180*115, np.pi/180*40])
        self.qz = np.zeros(7)

        self.addconfiguration("qr", self.qr)
        self.addconfiguration("qz", self.qz)