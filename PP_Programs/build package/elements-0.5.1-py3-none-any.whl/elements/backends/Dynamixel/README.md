# Dynamixel backend

Still under development

## Key files

- `dynamixel_io.py` talk to a chain of Dynamixel servos, using the Robotis API
- `dyndata.py.py` scrape the Robotis website and build a datastructure of parameters of all Dynamixels
- `dynamixel.json` datastructure in JSON format