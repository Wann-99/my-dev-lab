from pp.core.basic import (
    concat_string,
    create_list,
    first_index_string,
    float_to_registers,
    get_list,
    insert_list,
    int32_to_registers,
    join_string,
    last_index_string,
    registers_to_float,
    registers_to_int32,
    remove_list,
    set_list,
    split_string,
    sub_string,
    to_number,
    to_string,
    wait_ms,
)
from pp.enums import NumberFormatEnum
from pp.parallel_program import ParallelProgram


class ExampleBasicSignal(ParallelProgram):

    def pp_wait_ms(self):
        """Block parallel program tasks and wait for 1000 ms"""
        wait_ms(1000)


class ExampleBasicLoops(ParallelProgram):

    def pp_repeat_specific_times(self):
        """Repeat 3 times"""
        for i in range(3):
            print("Hi, Flexiv!")

    def pp_repeat_while(self):
        """Repeat the loop bodies while the condition is true"""
        i = 0
        while i < 3:
            print(i)
            i = i + 1

    def pp_traverse_items_in_list(self):
        """Traverse each item in the list and perform a specified operation on each item in the list"""
        for item in [1, 2, 3]:
            print(item)

    def pp_loop_termination_blocks(self):
        """Break out or continue the loop"""
        for num in range(10):
            if num == 7:
                break
            if num % 2 == 0:
                continue
            print(num)


class ExampleBasicLogic(ParallelProgram):

    def pp_if_elif_else(self):
        """If the condition is met, run the statements"""
        nums = [-5, 2, 0]
        for num in nums:
            if num > 0:
                print("Positive")
            elif num < 0:
                print("Negative")
            else:
                print("Zero")

    def pp_comparison_operators(self):
        """Comparison operator takes two inputs and returns True or False based on the comparison between the inputs"""
        print(1 == 0)
        print(1 != 0)
        print(1 < 0)
        print(1 <= 0)
        print(1 > 0)
        print(1 >= 0)

    def pp_logical_operators(self):
        """Returns True or False based on the logical operation"""
        print(False and (False or True))
        print(not True)


class ExampleBasicMath(ParallelProgram):

    def pp_math_operators(self):
        """Returns the result based on mathematical operation"""
        print(1 + 1)
        print(1 - 1)
        print(2 * 3)
        print(3 / 2)
        print(3**2)

    def pp_convert_bwt_reg_int32(self):
        """Convert between int32 and registers"""
        print(int32_to_registers(12))
        print(registers_to_int32(0, 12))

    def pp_convert_bwt_reg_float(self):
        """Convert between float and registers"""
        print(float_to_registers(-12.25))
        print(registers_to_float(49476, 0))


class ExampleBasicText(ParallelProgram):

    def pp_concatenate_text(self):
        """Concatenate strings"""
        print(concat_string("Hi", "_", "Flexiv"))

    def pp_length_of_text(self):
        """Returns the length of string"""
        print(len("Flexiv"))
        greeting = "Hi, Flexiv!"
        print(len(greeting))

    def pp_find_text(self):
        """Find the first/last occurrence of a substring in the main text string"""
        greeting = "Hi, Flexiv!"
        print(first_index_string(greeting, "i"))
        print(last_index_string(greeting, "i"))

    def pp_extract_text(self):
        """Extract a substring of a text string according to the specified start index and end index"""
        print(sub_string("Hi, Flexiv!", 4, -2))

    def pp_convert_btw_num_and_text(self):
        """Convert a number/text to a text/number based on the specified numeral system(2, 8, 10, 16)"""
        print(to_string(1, NumberFormatEnum.DEC))
        print(to_number("A", NumberFormatEnum.HEX))


class ExampleBasicList(ParallelProgram):

    def pp_create_list(self):
        """Create a new list and assign values"""
        empty_list1 = []
        empty_list2 = create_list()
        test_list1 = [1, 2, 3]
        test_list2 = create_list(1, 2, 3)
        print(empty_list1)
        print(empty_list2)
        print(test_list1)
        print(test_list2)

    def pp_length_of_list(self):
        """Returns the length of list"""
        print(len([1, 2]))
        test_list = [1, 2, 3]
        print(len(test_list))

    def pp_manage_list_item(self):
        """Get/Set/Remove/Insert item in a list"""
        test_list = [1, 2, 3, 4]
        # Get item
        print(get_list(test_list, 1))
        # Set item
        set_list(test_list, 1, 6)
        print(test_list)
        # Get and remove item
        print(remove_list(test_list, 1))
        print(test_list)
        # Insert item
        insert_list(test_list, 2, 7)
        print(test_list)

    def pp_convert_btw_list_and_str(self):
        """Split/join string/list to list/string using a delimiter"""
        print(split_string("1.2,3,4", ","))
        print(join_string(["Hi", "Flexiv"], "_"))


class ExampleBasicFunction(ParallelProgram):

    def func_no_input_no_return(self):
        print("no_input_no_return")

    def pp_func_no_input_no_return(self):
        """Define and call a function without input parameter and return value"""
        wait_ms(1000)
        self.func_no_input_no_return()

    def func_with_input_and_return(self, a, b):
        return a < b

    def pp_func_with_input_and_return(self):
        """Define and call a function with input parameters and return a value"""
        print(self.func_with_input_and_return(1, 2))

    def func_with_if_return(self, text, first_letter, last_letter):
        first_index = first_index_string(text, first_letter)
        last_index = last_index_string(text, last_letter)
        if self.func_with_input_and_return(last_index, first_index):
            return "error"
        else:
            return sub_string(text, first_index, last_index)

    def pp_func_with_if_return(self):
        """Define and call a function with if_return"""
        text = "abcedfgh"
        print(self.func_with_if_return(text, "a", "f"))
        print(self.func_with_if_return(text, "h", "a"))
