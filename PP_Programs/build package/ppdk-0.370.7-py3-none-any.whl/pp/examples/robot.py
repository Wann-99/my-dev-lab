from pp.core.robot import (
    clear_fault,
    fault,
    get_global_var,
    get_io,
    get_system_state,
    set_global_var,
    set_io,
    set_io_pulse_ms,
    update_global_var_coord,
    update_global_var_jpos,
    update_global_var_pose,
    wait_io_ms,
)
from pp.enums import (
    AnyBusSlaveInputEnum,
    AnyBusSlaveOutputEnum,
    GPIOEnum,
    GPIOInPortEnum,
    GPIOOutPortEnum,
    MetricSystemEnum,
    ModbusTCPInputEnum,
    ModbusTCPOutputEnum,
    ProfinetSlaveInputEnum,
    ProfinetSlaveOutputEnum,
    SystemStateEnum,
)
from pp.parallel_program import ParallelProgram


class ExampleRobotSignal(ParallelProgram):
    def pp_wait_io_status(self):
        """Monitor whether the value of the specified I/O system port changes to the expected value
        within the set time (When set to 0, keep waiting)"""
        # GPIOSystem [I/O port: "gpioIn0" - "gpioIn17"]
        wait_io_ms(GPIOEnum.SYSTEM, GPIOInPortEnum.GPIO_IN_0, True, 0)

        # Profinet [I/O port: "pfBitIn0" - "pfBitIn255", "pfIntIn0" - "pfIntIn7", "pfFloatIn0" - "pfFloatIn7"]
        wait_io_ms(
            GPIOEnum.PROFINET_SLAVE, ProfinetSlaveInputEnum.PF_BIT_IN_0, True, 1000
        )
        wait_io_ms(
            GPIOEnum.PROFINET_SLAVE, ProfinetSlaveInputEnum.PF_INT_IN_0, True, 1000
        )
        wait_io_ms(
            GPIOEnum.PROFINET_SLAVE, ProfinetSlaveInputEnum.PF_FLOAT_IN_0, True, 1000
        )

        # Modbus TCP [I/O port: "mTBitIn0" - "mTBitIn255", "mTIntIn0" - "mTIntIn63", "mTFloatIn0" - "mTFloatIn63"]
        wait_io_ms(GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPInputEnum.MT_BIT_IN_0, True, 1000)
        wait_io_ms(GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPInputEnum.MT_INT_IN_0, True, 1000)
        wait_io_ms(
            GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPInputEnum.MT_FLOAT_IN_0, True, 1000
        )

        # Anybus [I/O port: "aBBitIn0" - "aBBitIn255", "aBIntIn0" - "aBIntIn31", "aBFloatIn0" - "aBFloatIn31"]
        wait_io_ms(GPIOEnum.ANYBUS, AnyBusSlaveInputEnum.AB_BIT_IN_0, True, 1000)
        wait_io_ms(GPIOEnum.ANYBUS, AnyBusSlaveInputEnum.AB_INT_IN_0, True, 1000)
        wait_io_ms(GPIOEnum.ANYBUS, AnyBusSlaveInputEnum.AB_FLOAT_IN_0, True, 1000)

    def pp_set_the_value_of_io(self):
        """Set the value of the specified I/O system port"""
        # GPIOSystem [I/O port: "gpioOut0" - "gpioOut17"]
        set_io(GPIOEnum.SYSTEM, GPIOOutPortEnum.GPIO_OUT_0, True)

        # Profinet [I/O port: "pfBitOut0" - "pfBitOut255", "pfIntOut0" - "pfIntOut7", "pfFloatOut0" - "pfFloatOut7"]
        set_io(GPIOEnum.PROFINET_SLAVE, ProfinetSlaveOutputEnum.PF_BIT_OUT_0, True)
        set_io(GPIOEnum.PROFINET_SLAVE, ProfinetSlaveOutputEnum.PF_INT_OUT_0, 1)
        set_io(GPIOEnum.PROFINET_SLAVE, ProfinetSlaveOutputEnum.PF_FLOAT_OUT_0, 1.2)

        # Modbus TCP [I/O port: "mTBitOut0" - "mTBitOut255", "mTIntOut0" - "mTIntOut63", "mTFloatOut0" - "mTFloatOut63"]
        set_io(GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPOutputEnum.MT_BIT_OUT_0, True)
        set_io(GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPOutputEnum.MT_INT_OUT_0, 1)
        set_io(GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPOutputEnum.MT_FLOAT_OUT_0, 1.2)

        # Anybus [I/O port: "aBBitOut0" - "aBBitOut255", "aBIntOut0" - "aBIntOut31", "aBFloatOut0" - "aBFloatOut31"]
        set_io(GPIOEnum.ANYBUS, AnyBusSlaveOutputEnum.AB_BIT_OUT_0, True)
        set_io(GPIOEnum.ANYBUS, AnyBusSlaveOutputEnum.AB_INT_OUT_0, 1)
        set_io(GPIOEnum.ANYBUS, AnyBusSlaveOutputEnum.AB_FLOAT_OUT_0, 1.2)

    def pp_send_pulse_on_io(self):
        """Send a pulse signal to the specified I/O system port"""
        # GPIOSystem [I/O port: "gpioOut0" - "gpioOut17"]
        set_io_pulse_ms(GPIOEnum.SYSTEM, GPIOOutPortEnum.GPIO_OUT_0, True, 1000)

        # Profinet [I/O port: "pfBitOut0" - "pfBitOut255", "pfIntOut0" - "pfIntOut7", "pfFloatOut0" - "pfFloatOut7"]
        set_io_pulse_ms(
            GPIOEnum.PROFINET_SLAVE, ProfinetSlaveOutputEnum.PF_BIT_OUT_0, True, 1000
        )
        set_io_pulse_ms(
            GPIOEnum.PROFINET_SLAVE, ProfinetSlaveOutputEnum.PF_INT_OUT_0, True, 1000
        )
        set_io_pulse_ms(
            GPIOEnum.PROFINET_SLAVE, ProfinetSlaveOutputEnum.PF_FLOAT_OUT_0, True, 1000
        )

        # Modbus TCP [I/O port: "mTBitOut0" - "mTBitOut255", "mTIntOut0" - "mTIntOut63", "mTFloatOut0" - "mTFloatOut63"]
        set_io_pulse_ms(
            GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPOutputEnum.MT_BIT_OUT_0, True, 1000
        )
        set_io_pulse_ms(
            GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPOutputEnum.MT_INT_OUT_0, True, 1000
        )
        set_io_pulse_ms(
            GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPOutputEnum.MT_FLOAT_OUT_0, True, 1000
        )

        # Anybus [I/O port: "aBBitOut0" - "aBBitOut255", "aBIntOut0" - "aBIntOut31", "aBFloatOut0" - "aBFloatOut31"]
        set_io_pulse_ms(GPIOEnum.ANYBUS, AnyBusSlaveOutputEnum.AB_BIT_OUT_0, True, 1000)
        set_io_pulse_ms(GPIOEnum.ANYBUS, AnyBusSlaveOutputEnum.AB_INT_OUT_0, True, 1000)
        set_io_pulse_ms(
            GPIOEnum.ANYBUS, AnyBusSlaveOutputEnum.AB_FLOAT_OUT_0, True, 1000
        )

    def pp_get_io_value(self):
        """Gets the value of the specified I/O system port"""
        # GPIOSystem [I/O port: "gpioIn0" - "gpioIn17"]
        print(get_io(GPIOEnum.SYSTEM, GPIOInPortEnum.GPIO_IN_0))

        # Profinet [I/O port: "pfBitIn0" - "pfBitIn255", "pfIntIn0" - "pfIntIn7", "pfFloatIn0" - "pfFloatIn7"]
        print(get_io(GPIOEnum.PROFINET_SLAVE, ProfinetSlaveInputEnum.PF_BIT_IN_0))
        print(get_io(GPIOEnum.PROFINET_SLAVE, ProfinetSlaveInputEnum.PF_INT_IN_0))
        print(get_io(GPIOEnum.PROFINET_SLAVE, ProfinetSlaveInputEnum.PF_FLOAT_IN_0))

        # Modbus TCP [I/O port: "mTBitIn0" - "mTBitIn255", "mTIntIn0" - "mTIntIn63", "mTFloatIn0" - "mTFloatIn63"]
        print(get_io(GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPInputEnum.MT_BIT_IN_0))
        print(get_io(GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPInputEnum.MT_INT_IN_0))
        print(get_io(GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPInputEnum.MT_FLOAT_IN_0))

        # Anybus [I/O port: "aBBitIn0" - "aBBitIn255", "aBIntIn0" - "aBIntIn31", "aBFloatIn0" - "aBFloatIn31"]
        print(get_io(GPIOEnum.ANYBUS, AnyBusSlaveInputEnum.AB_BIT_IN_0))
        print(get_io(GPIOEnum.ANYBUS, AnyBusSlaveInputEnum.AB_INT_IN_0))
        print(get_io(GPIOEnum.ANYBUS, AnyBusSlaveInputEnum.AB_FLOAT_IN_0))


class ExampleRobot(ParallelProgram):
    def pp_prompt_fault(self):
        """Trigger a software fault with fault_message"""
        fault("test_fault")

    def pp_clear_fault(self):
        """Clear software fault"""
        clear_fault()

    def pp_set_global_var(self):
        """Set the value of a global variable"""
        set_global_var("test_int", 7)

    def pp_get_global_var(self):
        """Returns the value of a global variable"""
        print(get_global_var("test_int"))

    def pp_get_system_state(self):
        """Returns the value of a system variable"""
        print(get_system_state(SystemStateEnum.TCP_POSE))

    def pp_update_global_variables(self):
        """Update partial or complete values of position type(JPos, Pose or Coord) type"""
        # Update all/partial JPos for Rizon
        update_global_var_jpos("GV_JPos", [1, 2, 3, 4, 5, 6, 7])
        update_global_var_jpos("GV_JPos", [-1, "", "", "", "", "", 100])
        # Update all/partial JPos for Moonlight
        update_global_var_jpos("GV_JPos", [7, 6, 5])
        update_global_var_jpos("GV_JPos", ["", "", -1])
        # Update all/partial Pose in mm/m (x,y,z)
        update_global_var_pose(
            "GV_Pose", [0.1, 0.2, 0.3, 4, 5, 6], MetricSystemEnum.METER
        )
        update_global_var_pose(
            "GV_Pose", [-100, -200, -300, -4, -5, -6], MetricSystemEnum.MILLIMETER
        )
        update_global_var_pose(
            "GV_Pose", [-0.6, "", "", 180, 0, 180], MetricSystemEnum.METER
        )
        # Update all/partial Coord in mm/m(enter "" fot partial update, None for no update)
        update_global_var_coord(
            "GV_Coord",
            [0.1, 0.2, 0.3, 40, 50, 60],
            ["WORLD", "WORLD_ORIGIN"],
            [0, -40, 0, 90, 0, 40, 0],
            [1, 2, 3, 4, 5, 6],
            MetricSystemEnum.METER,
        )
        update_global_var_coord(
            "GV_Coord",
            [-100, -200, "", "", "", 180],
            ["WORK", "WorkCoord0"],
            None,
            None,
            MetricSystemEnum.MILLIMETER,
        )
