"""Node visitor"""

import ast

from ..enums import *
from .binopdesc import BinaryOperationDesc
from .boolopdesc import BooleanOperationDesc
from .cmpopdesc import CompareOperationDesc
from .context import Context
from .loopcounter import LoopCounter
from .nameconstdesc import NameConstantDesc
from .tokenendmode import TokenEndMode
from .unaryopdesc import UnaryOperationDesc


class NodeVisitor(ast.NodeVisitor):
    LUACODE = "[[luacode]]"

    """Node visitor"""

    def __init__(self, context=None, config=None):
        self.context = context if context is not None else Context()
        self.config = config
        self.last_end_mode = TokenEndMode.LINE_FEED
        self.output = []

    def visit_Assert(self, node):
        """visit Assert"""
        test = self.visit_all(node.test, inline=True)
        message = self.visit_all(node.msg, inline=True) if node.msg else ""
        self.emit("assert({test}, {message})".format(test=test, message=message))

    def visit_Assign(self, node):
        """Visit assign"""
        target = self.visit_all(node.targets[0], inline=True)
        value = self.visit_all(node.value, inline=True)

        local_keyword = ""

        last_ctx = self.context.last()

        if last_ctx["class_name"]:
            target = ".".join([last_ctx["class_name"], target])

        # 判断变量是否已经在当前作用域中定义
        # 字典赋值需判断字典名称是否存在
        if (
            "." not in target
            and not last_ctx["locals"].exists(target)
            and not last_ctx["locals"].exists(target.split("[")[0])
        ):
            local_keyword = "local "
            last_ctx["locals"].add_symbol(target)

            self.emit(
                "{local}{target} = {value}".format(
                    local=local_keyword, target=target, value=value
                )
            )
        else:
            self.emit("{target} = {value}".format(target=target, value=value))

    def visit_AugAssign(self, node):
        """Visit augassign"""
        operation = BinaryOperationDesc.OPERATION[node.op.__class__]

        target = self.visit_all(node.target, inline=True)

        values = {
            "left": target,
            "right": self.visit_all(node.value, inline=True),
            "operation": operation["value"],
        }

        line = "({})".format(operation["format"])
        line = line.format(**values)

        self.emit("{target} = {line}".format(target=target, line=line))

    def visit_Attribute(self, node):
        """Visit attribute"""
        line = "{object}.{attr}"
        values = {
            "object": self.visit_all(node.value, True),
            "attr": node.attr,
        }
        self.emit(line.format(**values))

    def visit_BinOp(self, node):
        """Visit binary operation"""
        operation = BinaryOperationDesc.OPERATION[node.op.__class__]
        line = "({})".format(operation["format"])
        values = {
            "left": self.visit_all(node.left, True),
            "right": self.visit_all(node.right, True),
            "operation": operation["value"],
        }

        self.emit(line.format(**values))

    def visit_BoolOp(self, node):
        """Visit boolean operation"""
        operation = BooleanOperationDesc.OPERATION[node.op.__class__]
        values = []
        for item in node.values:
            if isinstance(item, ast.BoolOp):
                values.append("({})".format(self.visit_all(item, True)))
            else:
                values.append(self.visit_all(item, True))
        line = f" {operation['value']} ".join(values)
        self.emit(line)

    def visit_Break(self, node):
        """Visit break"""
        self.emit("break")

    def visit_Call(self, node):
        """Visit function call"""

        def get_full_attribute(node):
            """递归解析 MyEnum.A.value 结构"""
            if isinstance(node, ast.Attribute):
                return get_full_attribute(node.value) + "." + node.attr
            elif isinstance(node, ast.Name):
                return node.id
            return ""

        name = self.visit_all(node.func, inline=True)
        line = "{name}({arguments})"
        arguments = []
        for arg in node.args:
            # 处理枚举变量 EnumClass.EnumMember
            # 目前只支持一层，不支持嵌套
            if isinstance(arg, ast.Attribute):
                arg = get_full_attribute(arg)
                enum_class_name, member_name = arg.split(".")
                enum_class = globals().get(enum_class_name)
                if enum_class and hasattr(enum_class, member_name):
                    enum_member = getattr(
                        enum_class, member_name
                    )  # 获取枚举成员 `MyEnum.A`
                    real_value = getattr(enum_member, "value", None)
                    if isinstance(real_value, str):
                        arguments.append('"' + real_value + '"')
                    else:
                        arguments.append(str(real_value))
                else:
                    arguments.append(self.visit_all(arg, inline=True))
            else:
                arguments.append(self.visit_all(arg, inline=True))
        if name == "print":
            name = "info"
            if isinstance(node.args[0], ast.BinOp) or isinstance(
                node.args[0], ast.Compare
            ):
                line = "{name}{arguments}"
            line = line.format(name=name, arguments=", ".join(arguments))
        elif name == "len":
            name = "#"
            if (
                isinstance(node.args[0], ast.List)
                or isinstance(node.args[0], ast.Constant)
                or isinstance(node.args[0], ast.Name)
            ):
                line = "{name}{arguments}"
                line = line.format(name=name, arguments=", ".join(arguments))
            elif isinstance(node.args[0], ast.Tuple):
                line = "{name}{{{arguments}}}"
                line = line.format(name=name, arguments=", ".join(arguments))
            else:
                line = "{name}({arguments})"
                line = line.format(name=name, arguments=", ".join(arguments))
        elif name == "struct.unpack" or name == "unpack":
            name = "convert_bytes_to_float"
            bytes_arg = ast.literal_eval(arguments[1])
            arguments = list(bytes_arg)
            assert len(arguments) == 4, "only 4 bytes can be converted to float"
            arguments = [str(arg) for arg in arguments]
            line = line.format(name=name, arguments=", ".join(arguments))
        elif name == "struct.pack" or name == "pack":
            name = "convert_float_to_bytes"
            arguments = arguments[1]
            line = line.format(name=name, arguments=arguments)
        elif name == "sub_string":
            line = f"string.sub({arguments[0]}, {arguments[1]}, {arguments[2]})"
        elif name in [
            "modbus_rtu_close",
            "modbus_tcp_close",
            "modbus_tcp_connected",
            "modbus_tcp_open",
            "serial_port_close",
            "socket_close",
            "socket_connected",
            "socket_open",
            "socket_recv",
            "socket_send",
            "serial_port_send",
            "serial_port_recv",
        ]:
            if isinstance(node.args[0], ast.Constant):
                assert (
                    1 <= int(arguments[0]) <= 5
                ), "client_id/master_id must be in the range of 1 to 5"
            line = line.format(name=name, arguments=", ".join(arguments))
        elif name in [
            "modbus_rtu_read",
            "modbus_rtu_write",
            "modbus_tcp_read",
            "modbus_tcp_write",
        ]:
            if isinstance(arguments[0], ast.Constant):
                assert (
                    1 <= int(arguments[0]) <= 5
                ), "master_id must be in the range of 1 to 5"
            if isinstance(arguments[1], ast.Constant):
                assert (
                    0 <= int(arguments[1]) <= 255
                ), "slave_id must be in the range of 0 to 255"
            if isinstance(arguments[2], ast.Constant):
                assert int(arguments[2]) > 0, "quantity must be greater than 0"
            line = line.format(name=name, arguments=", ".join(arguments))
        elif name.startswith("self.func_"):
            name = name[10:]
            line = line.format(name=name, arguments=", ".join(arguments))
        elif name == "update_object_pool":
            name = "obj_pool_update"
            line = line.format(name=name, arguments=", ".join(arguments))
        elif name == "clear_object_pool":
            name = "obj_pool_clear"
            line = line.format(name=name, arguments=", ".join(arguments))
        elif name == "write_trajectory_file":
            name = "write_content_to_file"
            line = line.format(
                name=name,
                arguments=", ".join([arguments[0], '"trajectory"', arguments[1]]),
            )
        elif name == "read_trajectory_file":
            name = "content_of_file"
            line = line.format(
                name=name, arguments=", ".join(['"trajectory"', arguments[0]])
            )
        else:
            line = line.format(name=name, arguments=", ".join(arguments))
        self.emit(line)

    def visit_ClassDef(self, node):
        """Visit class definition"""
        bases = [self.visit_all(base, inline=True) for base in node.bases]

        local_keyword = ""
        last_ctx = self.context.last()
        if not last_ctx["class_name"] and not last_ctx["locals"].exists(node.name):
            local_keyword = "local "
            last_ctx["locals"].add_symbol(node.name)

        name = node.name
        if last_ctx["class_name"]:
            name = ".".join([last_ctx["class_name"], name])

        values = {
            "local": local_keyword,
            "name": name,
            "node_name": node.name,
        }

        self.emit("{local}{name} = class(function({node_name})".format(**values))

        self.context.push({"class_name": node.name})
        self.visit_all(node.body)
        self.context.pop()

        self.output[-1].append("return {node_name}".format(**values))

        self.emit("end, {{{}}})".format(", ".join(bases)))

        # Return class object only in the top-level classes.
        # Not in the nested classes.
        if self.config["class"]["return_at_the_end"] and not last_ctx["class_name"]:
            self.emit("return {}".format(name))

    def visit_Compare(self, node):
        """Visit compare"""

        line = ""

        left = self.visit_all(node.left, inline=True)
        for i in range(len(node.ops)):
            operation = node.ops[i]
            operation = CompareOperationDesc.OPERATION[operation.__class__]

            right = self.visit_all(node.comparators[i], inline=True)

            values = {
                "left": left,
                "right": right,
            }

            if isinstance(operation, str):
                values["op"] = operation
                line += "{left} {op} {right}".format(**values)
            elif isinstance(operation, dict):
                line += operation["format"].format(**values)

            if i < len(node.ops) - 1:
                left = right
                line += " and "

        self.emit("({})".format(line))

    def visit_Continue(self, node):
        """Visit continue"""
        last_ctx = self.context.last()
        line = "goto {}".format(last_ctx["loop_label_name"])
        self.emit(line)

    def visit_Delete(self, node):
        """Visit delete"""
        targets = [self.visit_all(target, inline=True) for target in node.targets]
        nils = ["nil" for _ in targets]
        line = "{targets} = {nils}".format(
            targets=", ".join(targets), nils=", ".join(nils)
        )
        self.emit(line)

    def visit_Dict(self, node):
        """Visit dictionary"""
        keys = []

        for key in node.keys:
            value = self.visit_all(key, inline=True)
            if isinstance(key, ast.Str):
                value = "[{}]".format(value)
            keys.append(value)

        values = [self.visit_all(item, inline=True) for item in node.values]

        elements = ["{} = {}".format(keys[i], values[i]) for i in range(len(keys))]
        elements = ", ".join(elements)
        self.emit("dict {{{}}}".format(elements))

    def visit_DictComp(self, node):
        """Visit dictionary comprehension"""
        self.emit("(function()")
        self.emit("local result = dict {}")

        ends_count = 0

        for comp in node.generators:
            line = "for {target} in {iterator} do"
            values = {
                "target": self.visit_all(comp.target, inline=True),
                "iterator": self.visit_all(comp.iter, inline=True),
            }
            line = line.format(**values)
            self.emit(line)
            ends_count += 1

            for if_ in comp.ifs:
                line = "if {} then".format(self.visit_all(if_, inline=True))
                self.emit(line)
                ends_count += 1

        line = "result[{key}] = {value}"
        values = {
            "key": self.visit_all(node.key, inline=True),
            "value": self.visit_all(node.value, inline=True),
        }
        self.emit(line.format(**values))

        self.emit(" ".join(["end"] * ends_count))

        self.emit("return result")
        self.emit("end)()")

    def visit_Ellipsis(self, node):
        """Visit ellipsis"""
        self.emit("...")

    def visit_Expr(self, node):
        """Visit expr"""
        expr_is_docstring = False
        if isinstance(node.value, ast.Str):
            expr_is_docstring = True

        self.context.push({"docstring": expr_is_docstring})
        output = self.visit_all(node.value)
        self.context.pop()

        self.output.append(output)

    def visit_FunctionDef(self, node):
        """Visit function definition"""
        line = "{local}function {name}({arguments})"

        last_ctx = self.context.last()

        name = node.name
        if last_ctx["class_name"]:
            name = ".".join([last_ctx["class_name"], name])

        arguments = [arg.arg for arg in node.args.args]

        if node.args.vararg is not None:
            arguments.append("...")

        local_keyword = ""

        if "." not in name and not last_ctx["locals"].exists(name):
            local_keyword = "local "
            last_ctx["locals"].add_symbol(name)

        function_def = line.format(
            local=local_keyword, name=name, arguments=", ".join(arguments)
        )

        self.emit(function_def)

        self.context.push({"class_name": ""})
        self.visit_all(node.body)
        self.context.pop()

        body = self.output[-1]

        if node.args.vararg is not None:
            line = "local {name} = list {{...}}".format(name=node.args.vararg.arg)
            body.insert(0, line)

        arg_index = -1
        for i in reversed(node.args.defaults):
            line = "{name} = {name} or {value}"

            arg = node.args.args[arg_index]
            values = {
                "name": arg.arg,
                "value": self.visit_all(i, inline=True),
            }
            body.insert(0, line.format(**values))

            arg_index -= 1

        self.emit("end")

        for decorator in reversed(node.decorator_list):
            decorator_name = self.visit_all(decorator, inline=True)
            values = {
                "name": name,
                "decorator": decorator_name,
            }
            line = "{name} = {decorator}({name})".format(**values)
            self.emit(line)

    def visit_For(self, node):
        """Visit for loop"""
        line = "for {target} in {iter} do"

        # for i in range(1, 10)
        if (
            isinstance(node.iter, ast.Call)
            and isinstance(node.iter.func, ast.Name)
            and node.iter.func.id == "range"
        ):
            line = "for {target}={start},{end},{step} do"
            target = self.visit_all(node.target, inline=True)
            if len(node.iter.args) == 1:
                start = 1
                end = self.visit_all(node.iter.args[0], inline=True)
                step = 1
            elif len(node.iter.args) == 2:
                start = self.visit_all(node.iter.args[0], inline=True)
                end = self.visit_all(node.iter.args[1], inline=True)
                if int(end) < int(start):
                    raise Exception("range end must greater than start")
                if int(end) != int(start):
                    end = int(end) - 1
                step = 1
            elif len(node.iter.args) == 3:
                start = self.visit_all(node.iter.args[0], inline=True)
                end = self.visit_all(node.iter.args[1], inline=True)
                step = self.visit_all(node.iter.args[2], inline=True)
                if int(end) < int(start):
                    raise Exception("range end must greater than start")
                if int(end) != int(start):
                    end = int(end) - 1
            else:
                raise Exception("Invalid range function call")
            self.emit(
                line.format(
                    **{"target": target, "start": start, "end": end, "step": step}
                )
            )
        # for i in [1, 2, 3], for i in list_var
        elif isinstance(node.iter, ast.Name) or isinstance(node.iter, ast.List):
            line = "for _, {target} in ipairs({iter}) do"
            values = {
                "target": self.visit_all(node.target, inline=True),
                "iter": self.visit_all(node.iter, inline=True),
            }
            self.emit(line.format(**values))
        else:
            raise Exception("Unknown for loop type")

        continue_label = LoopCounter.get_next()
        self.context.push(
            {
                "loop_label_name": continue_label,
            }
        )
        self.visit_all(node.body)
        self.context.pop()

        self.output[-1].append("::{}::".format(continue_label))

        self.emit("end")

    def visit_Global(self, node):
        """Visit globals"""
        last_ctx = self.context.last()
        for name in node.names:
            last_ctx["globals"].add_symbol(name)

    def visit_If(self, node):
        """Visit if"""
        test = self.visit_all(node.test, inline=True)

        line = "if {} then".format(test)

        self.emit(line)
        self.visit_all(node.body)

        if node.orelse:
            if isinstance(node.orelse[0], ast.If):
                elseif = node.orelse[0]
                elseif_test = self.visit_all(elseif.test, inline=True)

                line = "elseif {} then".format(elseif_test)
                self.emit(line)

                output_length = len(self.output)
                self.visit_If(node.orelse[0])

                del self.output[output_length]
                del self.output[-1]
            else:
                self.emit("else")
                self.visit_all(node.orelse)

        self.emit("end")

    def visit_IfExp(self, node):
        """Visit if expression"""
        line = "{cond} and {true_cond} or {false_cond}"
        values = {
            "cond": self.visit_all(node.test, inline=True),
            "true_cond": self.visit_all(node.body, inline=True),
            "false_cond": self.visit_all(node.orelse, inline=True),
        }

        self.emit(line.format(**values))

    def visit_Import(self, node):
        """Visit import"""
        line = 'local {asname} = require "{name}"'
        values = {"asname": "", "name": ""}

        if node.names[0].asname is None:
            values["name"] = node.names[0].name
            values["asname"] = values["name"]
            values["asname"] = values["asname"].split(".")[-1]
        else:
            values["asname"] = node.names[0].asname
            values["name"] = node.names[0].name

        self.emit(line.format(**values))

    def visit_Index(self, node):
        """Visit index"""
        self.emit(self.visit_all(node.value, inline=True))

    def visit_Lambda(self, node):
        """Visit lambda"""
        line = "function({arguments}) return"

        arguments = [arg.arg for arg in node.args.args]

        function_def = line.format(arguments=", ".join(arguments))

        output = []
        output.append(function_def)
        output.append(self.visit_all(node.body, inline=True))
        output.append("end")

        self.emit(" ".join(output))

    def visit_List(self, node):
        """Visit list"""
        elements = [self.visit_all(item, inline=True) for item in node.elts]
        line = "{{{}}}".format(", ".join(elements))
        self.emit(line)

    def visit_ListComp(self, node):
        """Visit list comprehension"""
        self.emit("(function()")
        self.emit("local result = list {}")

        ends_count = 0

        for comp in node.generators:
            line = "for {target} in {iterator} do"
            values = {
                "target": self.visit_all(comp.target, inline=True),
                "iterator": self.visit_all(comp.iter, inline=True),
            }
            line = line.format(**values)
            self.emit(line)
            ends_count += 1

            for if_ in comp.ifs:
                line = "if {} then".format(self.visit_all(if_, inline=True))
                self.emit(line)
                ends_count += 1

        line = "result.append({})"
        line = line.format(self.visit_all(node.elt, inline=True))
        self.emit(line)

        self.emit(" ".join(["end"] * ends_count))

        self.emit("return result")
        self.emit("end)()")

    def visit_Module(self, node):
        """Visit module"""
        self.visit_all(node.body)
        self.output = self.output[0]

    def visit_Name(self, node):
        """Visit name"""
        self.emit(node.id)

    def visit_NameConstant(self, node):
        """Visit name constant"""
        self.emit(NameConstantDesc.NAME[node.value])

    def visit_Num(self, node):
        """Visit number"""
        self.emit(str(node.n))

    def visit_Bytes(self, node):
        """Visit bytes"""
        self.emit(str(node.s))

    def visit_Pass(self, node):
        """Visit pass"""
        pass

    def visit_Return(self, node):
        """Visit return"""
        line = "return "
        line += self.visit_all(node.value, inline=True)
        self.emit(line)

    def visit_Starred(self, node):
        """Visit starred object"""
        value = self.visit_all(node.value, inline=True)
        line = "unpack({})".format(value)
        self.emit(line)

    def visit_Str(self, node):
        """Visit str"""
        value = node.s
        if value.startswith(NodeVisitor.LUACODE):
            value = value[len(NodeVisitor.LUACODE) :]
            self.emit(value)
        elif self.context.last()["docstring"]:
            self.emit("--[[ {} ]]".format(node.s))
        else:
            self.emit('"{}"'.format(node.s))

    def visit_Subscript(self, node):
        """Visit subscript"""
        line = "{name}[{index}]"
        values = {
            "name": self.visit_all(node.value, inline=True),
            "index": self.visit_all(node.slice, inline=True),
        }
        # convert_bytes_to_float不需要再去sub script
        if values["name"].startswith("convert_bytes_to_float"):
            line = "{name}"
            self.emit(line.format(**values))
        else:
            self.emit(line.format(**values))

    def visit_Tuple(self, node):
        """Visit tuple"""
        elements = [self.visit_all(item, inline=True) for item in node.elts]
        self.emit(", ".join(elements))

    def visit_UnaryOp(self, node):
        """Visit unary operator"""
        operation = UnaryOperationDesc.OPERATION[node.op.__class__]
        value = self.visit_all(node.operand, inline=True)

        line = operation["format"]
        values = {
            "value": value,
            "operation": operation["value"],
        }

        self.emit(line.format(**values))

    def visit_While(self, node):
        """Visit while"""
        test = self.visit_all(node.test, inline=True)

        self.emit("while {} do".format(test))

        continue_label = LoopCounter.get_next()
        self.context.push(
            {
                "loop_label_name": continue_label,
            }
        )
        self.visit_all(node.body)
        self.context.pop()

        self.output[-1].append("::{}::".format(continue_label))

        self.emit("end")

    def visit_With(self, node):
        """Visit with"""
        self.emit("do")

        self.visit_all(node.body)

        body = self.output[-1]
        lines = []
        for i in node.items:
            line = ""
            if i.optional_vars is not None:
                line = "local {} = "
                line = line.format(self.visit_all(i.optional_vars, inline=True))
            line += self.visit_all(i.context_expr, inline=True)
            lines.append(line)

        for line in lines:
            body.insert(0, line)

        self.emit("end")

    def generic_visit(self, node):
        """Unknown nodes handler"""
        raise RuntimeError("Unknown node: {}".format(node))

    def visit_all(self, nodes, inline=False):
        """Visit all nodes in the given list"""

        if not inline:
            last_ctx = self.context.last()
            last_ctx["locals"].push()

        visitor = NodeVisitor(context=self.context, config=self.config)

        if isinstance(nodes, list):
            for node in nodes:
                visitor.visit(node)
            if not inline:
                self.output.append(visitor.output)
        else:
            visitor.visit(nodes)
            if not inline:
                self.output.extend(visitor.output)

        if not inline:
            last_ctx = self.context.last()
            last_ctx["locals"].pop()

        if inline:
            return " ".join(visitor.output)

    def emit(self, value):
        """Add translated value to the output"""
        self.output.append(value)
