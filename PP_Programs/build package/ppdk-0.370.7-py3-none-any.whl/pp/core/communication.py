from typing import List

from pp.enums import *


def modbus_tcp_open(master_id: int, ip: str, port: int):
    """ open modbus tcp as master
    :param master_id: [1, 2, 3, 4, 5]
    :param ip: ip address
    :param port: port number
    :return:
    """
    pass


def modbus_tcp_close(master_id: int):
    """ close modbus tcp
    :param master_id: [1, 2, 3, 4, 5]
    :return:
    """
    pass


def modbus_tcp_read(master_id: int, slave_id: int, quantity: int,
                    type: ModbusReadTypeEnum, address: int):
    """ read data via modbus tcp
    :param master_id: [1, 2, 3, 4, 5]
    :param slave_id: [0 - 255]
    :param quantity:
    :param type: [0-coils, 1-holding registers, 2-discrete inputs, 3-input registers]
    :param address: [0, 65535]
    :return:
    """
    pass


def modbus_tcp_write(master_id: int, slave_id: int, quantity: int,
                     type: ModbusWriteTypeEnum, address: int, value: list):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param slave_id: [0 - 255]
    :param quantity:
    :param type: [0-coils, 1-registers]
    :param address: [0, 65535]
    :param value:
    """
    pass


def socket_open(client_id: int, ip: str, port: int):
    """ open socket as tcp client
    :param client_id: [1, 2, 3, 4, 5]
    :param ip: ip address
    :param port: port number
    """
    pass


def socket_close(client_id: int):
    """ close socket
    :param client_id: [1, 2, 3, 4, 5]
    """
    pass


def socket_send(client_id: int, data: str):
    """ send data vid socket
    :param client_id: [1, 2, 3, 4, 5]
    :param data:
    """
    pass


def socket_recv(client_id: int):
    """ receive data vid socket
    :param client_id: [1, 2, 3, 4, 5]
    :return:
    """
    pass


def modbus_rtu_open(master_id: int, port: str, baud_rate: BaudRateEnum,
                    parity: PartityEnum, data_bits: DataBitsEnum = DataBitsEnum.BIT_8,
                    stop_bits: StopBitsEnum = StopBitsEnum.BIT_1):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param port: port string [/dev/ttyS0 - /dev/ttyS31]
    :param baud_rate: baud rate [4800, 9600, 19200, 38400, 57600, 115200]
    :param parity: parity [0-None, 1-Odd, 2-Even]
    :param data_bits: [5, 6, 7, 8]
    :param stop_bits: [1, 2]
    :return:
    """
    pass


def modbus_rtu_close(master_id: int):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :return:
    """
    pass


def modbus_rtu_write(master_id: int, slave_id: int, quantity: int,
                     type: ModbusWriteTypeEnum, address: int, value: list[int]):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param slave_id: [0, 255]
    :param quantity:
    :param type: [0-coils, 1-registers]
    :param address:
    :param value:
    :return:
    """
    pass


def modbus_rtu_read(master_id: int, slave_id: int, quantity: int,
                    type: ModbusReadTypeEnum, address: int):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param slave_id: [0 - 255]
    :param quantity:
    :param type: [0-coils, 1-registers, 2-discrete inputs, 3-input registers]
    :param address:
    """
    pass


def serial_port_open(master_id: int, port: str, baud_rate: BaudRateEnum, parity: PartityEnum,
                     data_bits: DataBitsEnum = DataBitsEnum.BIT_8, stop_bits: StopBitsEnum = StopBitsEnum.BIT_1):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param port: port string [/dev/ttyS0 - /dev/ttyS31]
    :param baud_rate: baud rate [4800, 9600, 19200, 38400, 57600, 115200]
    :param parity: parity [0-None, 1-Odd, 2-Even]
    :param data_bits: [5, 6, 7, 8]
    :param stop_bits: [1, 2]
    :return:
    """
    pass


def serial_port_close(master_id: int):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :return:
    """
    pass


def serial_port_send(master_id: int, data: list[int]):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param data:
    :return:
    """
    pass


def serial_port_recv(master_id: int, length: int):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param length:
    :return:
    """
    pass


def read_flx_modbus_tcp_bit(master_id: int, slave_id: int, offset: int, length: int):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param slave_id:
    :param offset:
    :param length:
    :return:
    """
    pass


def read_flx_modbus_tcp_int(master_id: int, slave_id: int, offset: int, length: int):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param slave_id:
    :param offset:
    :param length:
    :return:
    """
    pass


def read_flx_modbus_tcp_float(master_id: int, slave_id: int, offset: int, length: int):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param slave_id:
    :param offset:
    :param length:
    :return:
    """
    pass


def write_flx_modbus_tcp_bit(master_id: int, slave_id: int, offset: int, data: List[bool]):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param slave_id:
    :param offset:
    :param data:
    :return:
    """
    pass


def write_flx_modbus_tcp_int(master_id: int, slave_id: int, offset: int, data: List[int]):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param slave_id:
    :param offset:
    :param data:
    :return:
    """
    pass


def write_flx_modbus_tcp_float(master_id: int, slave_id: int, offset: int, data: List[float]):
    """
    :param master_id: [1, 2, 3, 4, 5]
    :param slave_id:
    :param offset:
    :param data:
    :return:
    """
    pass
