from typing import Union

from pp.enums import *


def clear_fault():
    """ clear robot fault

    """
    pass


def fault(msg: str = "Trigger fault by PP"):
    """ trigger fault by PP
    :param msg:

    """
    pass


def get_system_state(state: SystemStateEnum):
    """ get robot system state
    :param state:  [tcpPose
                    tcpTransVelX
                    tcpTransVelY
                    tcpTransVelZ
                    tcpAngVelX
                    tcpAngVelY
                    tcpAngVelZ
                    tcpTransVelNorm
                    tcpAngVelNorm
                    CartesianPosX
                    CartesianPosY
                    CartesianPosZ
                    EulerAngleRx
                    EulerAngleRy
                    EulerAngleRz
                    CartesianForceX
                    CartesianForceY
                    CartesianForceZ
                    CartesianMomentX
                    CartesianMomentY
                    CartesianMomentZ
                    CartesianForce
                    CartesianMoment
                    totalExtJointTorque
                    collisionFlag
                    jPos
                    axisPos1
                    axisPos2
                    axisPos3
                    axisPos4
                    axisPos5
                    axisPos6
                    axisPos7
                    axisVel1
                    axisVel2
                    axisVel3
                    axisVel4
                    axisVel5
                    axisVel6
                    axisVel7
                    axisTorque1
                    axisTorque2
                    axisTorque3
                    axisTorque4
                    axisTorque5
                    axisTorque6
                    axisTorque7
                    extAxisPos1
                    extAxisPos2
                    extAxisPos3
                    extAxisPos4
                    extAxisPos5
                    extAxisPos6
                    extAxisPos7
                    extAxisVel1
                    extAxisVel2
                    extAxisVel3
                    extAxisVel4
                    extAxisVel5
                    extAxisVel6
                    extAxisVel7
                    jointPos
                    motionbarEnablePressed
                    motionbarEstopPressed
                    isConfirmed
                    isServoOn
                    operationMode
                    isFault
                    remoteActive
                    uiAppConnected
                    robotModelMajorVersion
                    robotModelMinorVersion
                    tcpWrenchLpfFcType
                    currentToolName
                    projectRunning
                    projectPaused]
    """
    pass


def set_global_var(name: str, value: object):
    """ set global variable
    :param name: global variable name
    :param value: global variable value, support Variable, COORD, JPOS, String, Double, Integer etc
    """
    pass


def get_global_var(name: str):
    """ get global variable
    :param name: global variable name
    """
    pass


def update_global_var_jpos(var_name: str, new_jpos: list):
    """
    update global var of jpos type
    :param var_name:
    :param new_jpos: (a1, a2, a3, a4, a5, a6, a7), set some to "" if partial update
    :return:
    """
    pass


def update_global_var_pose(var_name: str,
                           new_tcp_pos: list,
                           unit: MetricSystemEnum):
    """
    update global var of pose type
    :param var_name: global variable name
    :param new_tcp_pos: (x, y, z, rx, ry, rz), set some to "" if partial update
    :param unit: unit of x, y, z
    :return:
    """
    pass


def update_global_var_coord(
    var_name: str,
    new_tcp_pos: Union[list, None],
    new_coordinate: Union[list, None],
    new_ref_joint_positions: Union[list, None],
    new_ext_axis: Union[list, None],
    unit: MetricSystemEnum
):
    """
    update global var of coordinate type
    :param var_name: global variable name
    :param new_tcp_pos: (x, y, z, rx, ry, rz), set some to "" if partial update, or set new_tcp_pos None if not update
    :param new_coordinate: tuple with 2 items, set some to "" if partial update, or set new_coordinate None if not update
    :param new_ref_joint_positions: tuple with 7 items, set some to "" if partial update, or set new_ref_joint_positions None if not update
    :param new_ext_axis: tuple with 6 items, set some to "" if partial update, or set new_ext_axis None if not update
    :param unit:  unit of x, y, z in new_tcp_pos
    :return:
    """
    pass


def get_io(type: GPIOEnum,
           name: Union[
               GPIOInPortEnum,
               ProfinetSlaveInputEnum,
               ModbusTCPInputEnum,
               AnyBusSlaveInputEnum]):
    """ get robot io
    :param type: [SYSTEM-GPIOSystem,
                  PROFINET_SLAVE-GPIOProfinetSlave,
                  MODBUSTCP_SLAVE-GPIOModbusTCPSlave,
                  ANYBUS-GPIOAnybus]
    :param name:
    """
    pass


def set_io(type: GPIOEnum,
           name: Union[
               GPIOOutPortEnum,
               ProfinetSlaveOutputEnum,
               ModbusTCPOutputEnum,
               AnyBusSlaveOutputEnum],
           value: Union[bool, int, float]):
    """ set robot io
    :param type: [SYSTEM-GPIOSystem,
                  PROFINET_SLAVE-GPIOProfinetSlave,
                  MODBUSTCP_SLAVE-GPIOModbusTCPSlave,
                  ANYBUS-GPIOAnybus]
    :param name:
    :param value:
    """
    pass


def wait_io_ms(type: GPIOEnum,
               name: Union[
                   GPIOInPortEnum,
                   ProfinetSlaveInputEnum,
                   ModbusTCPInputEnum,
                   AnyBusSlaveInputEnum],
               value: bool,
               timeout: int):
    """ wait for given time until given IO port value
    :param type: [SYSTEM-GPIOSystem,
                  PROFINET_SLAVE-GPIOProfinetSlave,
                  MODBUSTCP_SLAVE-GPIOModbusTCPSlave,
                  ANYBUS-GPIOAnybus]
    :param name:
    :param value:
    :param timeout:
    """
    pass


def set_io_pulse_ms(type: GPIOEnum,
                    name: Union[
                        GPIOOutPortEnum,
                        ProfinetSlaveOutputEnum,
                        ModbusTCPOutputEnum,
                        AnyBusSlaveOutputEnum],
                    value: bool,
                    duration: int):
    """ set pulse to DO port in given duration
    :param type: [GPIOSystem,
                  GPIOProfinetSlave,
                  GPIOModbusTCPSlave
                  GPIOAnybus]
    :param name: DO port name
    :param value: [True, False]
    :param duration: unit ms
    """
    pass
