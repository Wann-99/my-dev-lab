from pp.enums import *


def wait_ms(duration: int):
    """ wait for given time (unit: microsecond)
    :param duration:
    :return:
    """
    pass


def create_list(*args):
    """ create a list
    :return: return the created list
    """
    pass


def insert_list(list: list, index: int, value) -> list:
    """ insert value to list at index
    :param list:
    :param index:
    :param value:
    :return: return the inserted list
    """
    pass


def remove_list(list: list, index: int) -> object:
    """ remove value from list at index
    :param list:
    :param index:
    :return: return the removed value at index
    """
    pass


def get_list(list: list, index: int) -> object:
    """ get value from list at index
    :param list:
    :param index:
    :return: return the value at index
    """
    pass


def set_list(list: list, index: int, value) -> list:
    """ set value to list at index
    :param list:
    :param index:
    :param value:
    :return: return the updated list
    """
    pass


def first_index_string(string: str, substring: str):
    """ get first occurrence of substring in string
    :param string:
    :param substring:
    :return:
    """
    pass


def last_index_string(string: str, substring: str):
    """ get last occurrence of substring in string
    :param string:
    :param substring:
    :return:
    """
    pass


def split_string(string: str, delim: str):
    """ split string by delimiter
    :param string:
    :param delim:
    :return:
    """
    pass


def concat_string(*args):
    """ concat strings
    :param args:
    :return:
    """
    pass


def join_list(list: list, delim: str):
    """ join list of strings
    :param list:
    :param delim:
    :return:
    """
    pass


def sub_string(string: str, start: int, end: int):
    """
    :param string:
    :param start:
    :param end:
    :return:
    """
    pass


def to_string(number: int | float, base: NumberFormatEnum):
    """
    :param number:
    :param base:
    :return:
    """
    pass


def to_number(string: str, base: NumberFormatEnum):
    """
    :param string:
    :param base:
    :return:
    """
    pass


def int32_to_registers(value: int):
    """
    :param value:
    :return:
    """
    pass


def float_to_registers(value: float):
    """
    :param value:
    :return:
    """
    pass


def registers_to_int32(high, low):
    """
    :param high:
    :param low:
    :return:
    """
    pass


def registers_to_float(high, low):
    """
    :param high:
    :param low:
    :return:
    """
    pass


def sub_list(list: list, start: int, end: int):
    """
    :param list:
    :param start:
    :param end:
    :return:
    """
    pass


def append_list(list: list, value: object):
    """
    :param list:
    :param value:
    :return:
    """
    pass


def remove_sub_list(list: list, start: int, end: int):
    """
    :param list:
    :param start:
    :param end:
    :return:
    """
    pass


def remove_sub_string(string: str, start: int, end: int):
    """
    :param string:
    :param start:
    :param end:
    :return:
    """
    pass
