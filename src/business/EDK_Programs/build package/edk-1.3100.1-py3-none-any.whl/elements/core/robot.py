from typing import List

import grpc
from google.protobuf.empty_pb2 import Empty
from loguru import logger

from elements.proto.RobotServiceToolDevice_pb2_grpc import ToolDeviceServiceStub
from elements.proto.RobotServiceWorkflow_pb2 import AssignPlanRequest, PlanNameRequest
from elements.proto.RobotServiceWorkflow_pb2_grpc import WorkflowServiceStub
from elements.utils.nanomsg_util import NanomsgClient, NanomsgClientUtil


class Robot:

    def __init__(
        self,
        ip: str = "192.168.2.10",
        grpc_port: int = 18001,
        nanomsg_port: int = 15001,
    ):
        self.ip = ip
        self.grpc_port = grpc_port
        self.nano_port = nanomsg_port
        self._conn_str = f"{self.ip}:{self.grpc_port}"
        self.channel = grpc.insecure_channel(self._conn_str)
        self.workflow_stub = WorkflowServiceStub(self.channel)
        self.client = NanomsgClient(ip, nanomsg_port)
        self.init_info()

    def init_info(self):
        data = NanomsgClientUtil.get_data(self.client)
        if data is not None:
            self.assigned_plan = NanomsgClientUtil.get_assigned_plan(self.client, data)
            self.state = NanomsgClientUtil.get_state(self.client, data)
            self.mode = NanomsgClientUtil.get_mode(self.client, data)
            self.servo_on = NanomsgClientUtil.is_servo_on(self.client, data)
            logger.info(
                f"robot info: "
                f"assigned_plan: {self.assigned_plan}, "
                f"state: {self.state}, "
                f"mode: {self.mode}, "
                f"servo_on: {self.servo_on}"
            )

    async def assign_plan(self, name) -> bool:
        # 机器人必须在停止状态下才能下发计划
        assert (
            self.state == "stopped"
        ), "robot must be in stopped mode when assigning plan"
        try:
            result = self.workflow_stub.AssignPlan(
                AssignPlanRequest(plan_name=name, is_internal_plan=False)
            )
            if result.value == 100000:
                return True
        except Exception as e:
            logger.error(f"Exception when assigning plan， message: {e}")
            return False
        logger.error(f"Assign plan {name} failed, msg: {result.info}")
        return False

    def reset_assigned_plan(self, name):
        result = self.workflow_stub.ResetAssignPlan(PlanNameRequest(plan_name=name))
        if result.value == 100000:
            return True
        logger.error(f"Reset assigned plan {name} failed, msg: {result.info}")
        return False

    def get_tools(self) -> List:
        self.tool_stub = ToolDeviceServiceStub(self.channel)
        result = self.tool_stub.GetToolList(Empty())
        if result.ret.value != 100000:
            logger.error(f"Get tool list failed, msg: {result.info}")
            return []
        tools = []
        for tool in result.tool_info:
            tools.append(tool.tool_name)
        return tools


if __name__ == "__main__":
    robot = Robot(ip="0.0.0.0", grpc_port=18001)
    robot.get_tools()
    # robot.assign_plan("FT03Test")
    assigned_plan = robot.assigned_plan
    print(assigned_plan)
