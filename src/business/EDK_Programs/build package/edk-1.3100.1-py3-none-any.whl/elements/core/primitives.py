from enum import Enum

from elements.common.enums import PrimitiveEnum
from elements.core.contrib.node import Node
from elements.core.contrib.parameter_values import (
    ParameterValue,
    ParameterValueGlobalVariable,
)
from elements.core.contrib.parameters import Parameter, ParameterPtInput
from elements.core.transit import Transit


class PrimitiveNode(Node):

    def __init__(self, name: str):
        super().__init__(name)
        self.cml_param_assignment = []
        # added primitive params
        self.params = []
        # must-add primitive params
        self.required_params = []
        # each parameter should check type
        self.type_mapping = self._get_type_mapping()

    def _get_type_mapping(self):
        type_mapping = {}
        parent_name = self.__class__.__qualname__
        primitive_enum = getattr(
            getattr(PrimitiveEnum, parent_name.split(".")[0]), parent_name.split(".")[1]
        )
        if hasattr(primitive_enum, "InputParams"):
            params = primitive_enum.InputParams
            for param_type in ["Basic", "Advanced"]:
                if hasattr(params, param_type):
                    type_mapping.update(
                        {
                            param: param.value["type"]
                            for param in getattr(params, param_type)
                        }
                    )
        return type_mapping

    def set_tool(self, tool_name: str):
        self.cm_switch_tcp_param.m_tool_name = tool_name

    def get_tool(self):
        return self.cm_switch_tcp_param.m_tool_name

    def add_transit(self, transit: Transit):
        assert transit is not None, "transit cannot be None"
        assert hasattr(transit, "_type"), "transit must be defined in function"
        assert transit._type == "Transit", "the transit type must be Transit"
        assert isinstance(transit, Transit), "the transit must be a Transit object"

        self.next_primitives.append(transit.end_node)
        self.transits.append(transit)

    def add_parameter(self, param: Enum, param_value: ParameterValue | Parameter):
        from elements.core.transit import Assignment

        # newer parameter will override old one
        if param in self.params:
            self.params.remove(param)
            # remove old assignment
            self.cml_param_assignment = [
                assignment
                for assignment in self.cml_param_assignment
                if assignment.cm_lhs_param.m_name != param.value["name"]
            ]

        # check parameter type
        if not isinstance(param_value, ParameterValueGlobalVariable):
            if param in self.type_mapping:
                if isinstance(param_value.m_type, Enum):
                    param_type = param_value.m_type.value
                else:
                    param_type = param_value.m_type
                assert (
                    self.type_mapping[param] == param_type
                ), f"{param}'s type must be {self.type_mapping[param]}, but real type is {param_value.m_type.value}"
            else:
                raise KeyError(f"Invalid params:{param}")

        self.cml_param_assignment.append(
            Assignment(
                lhs_param=ParameterPtInput(pt=self, pt_param=param),
                rhs_param=param_value,
            )
        )
        self.params.append(param)

    @property
    def breakpoint(self):
        return self.m_is_breakpoint

    @breakpoint.setter
    def breakpoint(self, value: bool):
        self.m_is_breakpoint = value


class Motion:
    class MoveC(PrimitiveNode):
        pt_name = PrimitiveEnum.Motion.MoveC.pt_name

        def __init__(self, name: str):
            super(Motion.MoveC, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Motion.MoveC.pt_type
            self.pt_state: PrimitiveEnum.Motion.MoveC.State = (
                PrimitiveEnum.Motion.MoveC.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.Motion.MoveC.InputParams.Basic.Target,
                PrimitiveEnum.Motion.MoveC.InputParams.Basic.MiddlePose,
            ]

    class MoveJ(PrimitiveNode):
        pt_name = PrimitiveEnum.Motion.MoveJ.pt_name

        def __init__(self, name):
            super(Motion.MoveJ, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Motion.MoveJ.pt_type
            self.pt_state: PrimitiveEnum.Motion.MoveJ.State = (
                PrimitiveEnum.Motion.MoveJ.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.Motion.MoveJ.InputParams.Basic.Target,
            ]

    class MoveL(PrimitiveNode):
        pt_name = PrimitiveEnum.Motion.MoveL.pt_name

        def __init__(self, name):
            super(Motion.MoveL, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Motion.MoveL.pt_type
            self.pt_state: PrimitiveEnum.Motion.MoveL.State = (
                PrimitiveEnum.Motion.MoveL.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.Motion.MoveL.InputParams.Basic.Target,
            ]

    class MovePTP(PrimitiveNode):
        pt_name = PrimitiveEnum.Motion.MovePTP.pt_name

        def __init__(self, name):
            super(Motion.MovePTP, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Motion.MovePTP.pt_type
            self.pt_state: PrimitiveEnum.Motion.MovePTP.State = (
                PrimitiveEnum.Motion.MovePTP.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.Motion.MovePTP.InputParams.Basic.Target,
            ]

    class MoveJTraj(PrimitiveNode):
        pt_name = PrimitiveEnum.Motion.MoveJTraj.pt_name

        def __init__(self, name):
            super(Motion.MoveJTraj, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Motion.MoveJTraj.pt_type
            self.pt_state: PrimitiveEnum.Motion.MoveJTraj.State = (
                PrimitiveEnum.Motion.MoveJTraj.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.Motion.MoveJTraj.InputParams.Basic.TrajFileName,
            ]


class Workflow:
    class Home(PrimitiveNode):
        pt_name = PrimitiveEnum.Workflow.Home.pt_name

        def __init__(self, name):
            super(Workflow.Home, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Workflow.Home.pt_type
            self.pt_state: PrimitiveEnum.Workflow.Home.State = (
                PrimitiveEnum.Workflow.Home.State.ReachedTarget
            )

    class Hold(PrimitiveNode):
        pt_name = PrimitiveEnum.Workflow.Hold.pt_name

        def __init__(self, name):
            super(Workflow.Hold, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Workflow.Hold.pt_type
            self.pt_state: PrimitiveEnum.Workflow.Hold.State = (
                PrimitiveEnum.Workflow.Hold.State.TimePeriod
            )

    class Fault(PrimitiveNode):
        pt_name = PrimitiveEnum.Workflow.Fault.pt_name

        def __init__(self, name):
            super(Workflow.Fault, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Workflow.Fault.pt_type

    class Stop(PrimitiveNode):
        pt_name = PrimitiveEnum.Workflow.Stop.pt_name

        def __init__(self, name):
            super(Workflow.Stop, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Workflow.Stop.pt_type
            self.pt_state: PrimitiveEnum.Workflow.Stop.State = (
                PrimitiveEnum.Workflow.Stop.State.Terminated
            )

    class End(PrimitiveNode):
        pt_name = PrimitiveEnum.Workflow.End.pt_name

        def __init__(self, name):
            super(Workflow.End, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Workflow.End.pt_type
            self.children = None


class BasicForceControl:
    class ZeroFTSensor(PrimitiveNode):
        pt_name = PrimitiveEnum.BasicForceControl.ZeroFTSensor.pt_name

        def __init__(self, name):
            super(BasicForceControl.ZeroFTSensor, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.BasicForceControl.ZeroFTSensor.pt_type
            self.pt_state: PrimitiveEnum.BasicForceControl.ZeroFTSensor.State = (
                PrimitiveEnum.BasicForceControl.ZeroFTSensor.State.Terminated
            )

    class Contact(PrimitiveNode):
        pt_name = PrimitiveEnum.BasicForceControl.Contact.pt_name

        def __init__(self, name):
            super(BasicForceControl.Contact, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.BasicForceControl.Contact.pt_type
            self.pt_state: PrimitiveEnum.BasicForceControl.Contact.State = (
                PrimitiveEnum.BasicForceControl.Contact.State.Terminated
            )

    class ForceHybridLite(PrimitiveNode):
        pt_name = PrimitiveEnum.BasicForceControl.ForceHybridLite.pt_name

        def __init__(self, name):
            super(BasicForceControl.ForceHybridLite, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.BasicForceControl.ForceHybridLite.pt_type
            self.pt_state: PrimitiveEnum.BasicForceControl.ForceHybridLite.State = (
                PrimitiveEnum.BasicForceControl.ForceHybridLite.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.BasicForceControl.ForceHybridLite.InputParams.Basic.Target,
                PrimitiveEnum.BasicForceControl.ForceHybridLite.InputParams.Basic.ForceAxis,
                PrimitiveEnum.BasicForceControl.ForceHybridLite.InputParams.Basic.TargetWrench,
            ]

    class ForceCompLite(PrimitiveNode):
        pt_name = PrimitiveEnum.BasicForceControl.ForceCompLite.pt_name

        def __init__(self, name):
            super(BasicForceControl.ForceCompLite, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.BasicForceControl.ForceCompLite.pt_type
            self.pt_state: PrimitiveEnum.BasicForceControl.ForceCompLite.State = (
                PrimitiveEnum.BasicForceControl.ForceCompLite.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.BasicForceControl.ForceCompLite.InputParams.Basic.Target,
            ]


class AdvancedForceControl:
    class ContactAlign(PrimitiveNode):
        pt_name = PrimitiveEnum.AdvancedForceControl.ContactAlign.pt_name

        def __init__(self, name):
            super(AdvancedForceControl.ContactAlign, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.AdvancedForceControl.ContactAlign.pt_type
            self.pt_state: PrimitiveEnum.AdvancedForceControl.ContactAlign.State = (
                PrimitiveEnum.AdvancedForceControl.ContactAlign.State.AlignContacted
            )

    class ForceTraj(PrimitiveNode):
        pt_name = PrimitiveEnum.AdvancedForceControl.ForceTraj.pt_name

        def __init__(self, name):
            super(AdvancedForceControl.ForceTraj, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.AdvancedForceControl.ForceTraj.pt_type
            self.pt_state: PrimitiveEnum.AdvancedForceControl.ForceTraj.State = (
                PrimitiveEnum.AdvancedForceControl.ForceTraj.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.AdvancedForceControl.ForceTraj.InputParams.Basic.TrajFileName,
            ]

    class ForceHybrid(PrimitiveNode):
        pt_name = PrimitiveEnum.AdvancedForceControl.ForceHybrid.pt_name

        def __init__(self, name):
            super(AdvancedForceControl.ForceHybrid, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.AdvancedForceControl.ForceHybrid.pt_type
            self.pt_state: PrimitiveEnum.AdvancedForceControl.ForceHybrid.State = (
                PrimitiveEnum.AdvancedForceControl.ForceHybrid.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.AdvancedForceControl.ForceHybrid.InputParams.Basic.Target,
                PrimitiveEnum.AdvancedForceControl.ForceHybrid.InputParams.Basic.ForceAxis,
                PrimitiveEnum.AdvancedForceControl.ForceHybrid.InputParams.Basic.TargetWrench,
            ]

    class ForceComp(PrimitiveNode):
        pt_name = PrimitiveEnum.AdvancedForceControl.ForceComp.pt_name

        def __init__(self, name):
            super(AdvancedForceControl.ForceComp, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.AdvancedForceControl.ForceComp.pt_type
            self.pt_state: PrimitiveEnum.AdvancedForceControl.ForceComp.State = (
                PrimitiveEnum.AdvancedForceControl.ForceComp.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.AdvancedForceControl.ForceComp.InputParams.Basic.Target,
            ]


class AdaptiveAssembly:
    class SearchHole(PrimitiveNode):
        pt_name = PrimitiveEnum.AdaptiveAssembly.SearchHole.pt_name

        def __init__(self, name):
            super(AdaptiveAssembly.SearchHole, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.AdaptiveAssembly.SearchHole.pt_type
            self.pt_state: PrimitiveEnum.AdaptiveAssembly.SearchHole.State = (
                PrimitiveEnum.AdaptiveAssembly.SearchHole.State.PushDis
            )

    class CheckPiH(PrimitiveNode):
        pt_name = PrimitiveEnum.AdaptiveAssembly.CheckPiH.pt_name

        def __init__(self, name):
            super(AdaptiveAssembly.CheckPiH, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.AdaptiveAssembly.CheckPiH.pt_type
            self.pt_state: PrimitiveEnum.AdaptiveAssembly.CheckPiH.State = (
                PrimitiveEnum.AdaptiveAssembly.CheckPiH.State.CheckComplete
            )

    class InsertComp(PrimitiveNode):
        pt_name = PrimitiveEnum.AdaptiveAssembly.InsertComp.pt_name

        def __init__(self, name):
            super(AdaptiveAssembly.InsertComp, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.AdaptiveAssembly.InsertComp.pt_type
            self.pt_state: PrimitiveEnum.AdaptiveAssembly.InsertComp.State = (
                PrimitiveEnum.AdaptiveAssembly.InsertComp.State.IsMoving
            )
            self.required_params = [
                PrimitiveEnum.AdaptiveAssembly.InsertComp.InputParams.Basic.InsertAxis,
            ]

    class Mate(PrimitiveNode):
        pt_name = PrimitiveEnum.AdaptiveAssembly.Mate.pt_name

        def __init__(self, name):
            super(AdaptiveAssembly.Mate, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.AdaptiveAssembly.Mate.pt_type
            self.pt_state: PrimitiveEnum.AdaptiveAssembly.Mate.State = (
                PrimitiveEnum.AdaptiveAssembly.Mate.State.MatingFinish
            )

    class FastenScrew(PrimitiveNode):
        pt_name = PrimitiveEnum.AdaptiveAssembly.FastenScrew.pt_name

        def __init__(self, name):
            super(AdaptiveAssembly.FastenScrew, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.AdaptiveAssembly.FastenScrew.pt_type
            self.pt_state: PrimitiveEnum.AdaptiveAssembly.FastenScrew.State = (
                PrimitiveEnum.AdaptiveAssembly.FastenScrew.State.FastenState
            )


class SurfaceFinishing:
    class Polish(PrimitiveNode):
        pt_name = PrimitiveEnum.SurfaceFinishing.Polish.pt_name

        def __init__(self, name):
            super(SurfaceFinishing.Polish, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.SurfaceFinishing.Polish.pt_type
            self.pt_state: PrimitiveEnum.SurfaceFinishing.Polish.State = (
                PrimitiveEnum.SurfaceFinishing.Polish.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.SurfaceFinishing.Polish.InputParams.Basic.TrajFileName,
            ]

    class Grind(PrimitiveNode):
        pt_name = PrimitiveEnum.SurfaceFinishing.Grind.pt_name

        def __init__(self, name):
            super(SurfaceFinishing.Grind, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.SurfaceFinishing.Grind.pt_type
            self.pt_state: PrimitiveEnum.SurfaceFinishing.Grind.State = (
                PrimitiveEnum.SurfaceFinishing.Grind.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.SurfaceFinishing.Grind.InputParams.Basic.TrajFileName,
            ]

    class PolishECP(PrimitiveNode):
        pt_name = PrimitiveEnum.SurfaceFinishing.PolishECP.pt_name

        def __init__(self, name):
            super(SurfaceFinishing.PolishECP, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.SurfaceFinishing.PolishECP.pt_type
            self.pt_state: PrimitiveEnum.SurfaceFinishing.PolishECP.State = (
                PrimitiveEnum.SurfaceFinishing.PolishECP.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.SurfaceFinishing.PolishECP.InputParams.Basic.TrajFileName,
                PrimitiveEnum.SurfaceFinishing.PolishECP.InputParams.Basic.ECPCoord,
            ]

    class GrindECP(PrimitiveNode):
        pt_name = PrimitiveEnum.SurfaceFinishing.GrindECP.pt_name

        def __init__(self, name):
            super(SurfaceFinishing.GrindECP, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.SurfaceFinishing.GrindECP.pt_type
            self.pt_state: PrimitiveEnum.SurfaceFinishing.GrindECP.State = (
                PrimitiveEnum.SurfaceFinishing.GrindECP.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.SurfaceFinishing.GrindECP.InputParams.Basic.TrajFileName,
                PrimitiveEnum.SurfaceFinishing.GrindECP.InputParams.Basic.ECPCoord,
            ]


class AdaptiveGrasping:
    class GraspComp(PrimitiveNode):
        pt_name = PrimitiveEnum.AdaptiveGrasping.GraspComp.pt_name

        def __init__(self, name):
            super(AdaptiveGrasping.GraspComp, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.AdaptiveGrasping.GraspComp.pt_type
            self.pt_state: PrimitiveEnum.AdaptiveGrasping.GraspComp.State = (
                PrimitiveEnum.AdaptiveGrasping.GraspComp.State.GripComplete
            )


class Synchronization:
    class SyncStart(PrimitiveNode):
        pt_name = PrimitiveEnum.Synchronization.SyncStart.pt_name

        def __init__(self, name):
            super(Synchronization.SyncStart, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Synchronization.SyncStart.pt_type
            self.pt_state: PrimitiveEnum.Synchronization.SyncStart.State = (
                PrimitiveEnum.Synchronization.SyncStart.State.WorkpieceDetected
            )
            self.required_params = [
                PrimitiveEnum.Synchronization.SyncStart.InputParams.Basic.SyncDevice,
                PrimitiveEnum.Synchronization.SyncStart.InputParams.Basic.TeachCoord,
            ]

    class SyncHold(PrimitiveNode):
        pt_name = PrimitiveEnum.Synchronization.SyncHold.pt_name

        def __init__(self, name):
            super(Synchronization.SyncHold, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Synchronization.SyncHold.pt_type
            self.pt_state: PrimitiveEnum.Synchronization.SyncHold.State = (
                PrimitiveEnum.Synchronization.SyncHold.State.TimePeriod
            )

    class SyncEnd(PrimitiveNode):
        pt_name = PrimitiveEnum.Synchronization.SyncEnd.pt_name

        def __init__(self, name):
            super(Synchronization.SyncEnd, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Synchronization.SyncEnd.pt_type
            self.pt_state: PrimitiveEnum.Synchronization.SyncEnd.State = (
                PrimitiveEnum.Synchronization.SyncEnd.State.Terminated
            )
            self.required_params = [
                PrimitiveEnum.Synchronization.SyncEnd.InputParams.Basic.SyncDevice
            ]


class ZeroGravityFloating:
    class FloatingCartesian(PrimitiveNode):
        pt_name = PrimitiveEnum.ZeroGravityFloating.FloatingCartesian.pt_name

        def __init__(self, name):
            super(ZeroGravityFloating.FloatingCartesian, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.ZeroGravityFloating.FloatingCartesian.pt_type
            self.pt_state: PrimitiveEnum.ZeroGravityFloating.FloatingCartesian.State = (
                PrimitiveEnum.ZeroGravityFloating.FloatingCartesian.State.IdleTime
            )

    class FloatingJoint(PrimitiveNode):
        pt_name = PrimitiveEnum.ZeroGravityFloating.FloatingJoint.pt_name

        def __init__(self, name):
            super(ZeroGravityFloating.FloatingJoint, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.ZeroGravityFloating.FloatingJoint.pt_type
            self.pt_state: PrimitiveEnum.ZeroGravityFloating.FloatingJoint.State = (
                PrimitiveEnum.ZeroGravityFloating.FloatingJoint.State.IdleTime
            )


class RehabilitationPhysiotherapy:
    class Massage(PrimitiveNode):
        pt_name = PrimitiveEnum.RehabilitationPhysiotherapy.Massage.pt_name

        def __init__(self, name):
            super(RehabilitationPhysiotherapy.Massage, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.RehabilitationPhysiotherapy.Massage.pt_type
            self.required_params = [
                PrimitiveEnum.RehabilitationPhysiotherapy.Massage.InputParams.Basic.Target,
                PrimitiveEnum.RehabilitationPhysiotherapy.Massage.InputParams.Basic.TargetWrench,
                PrimitiveEnum.RehabilitationPhysiotherapy.Massage.InputParams.Basic.ForceAxis,
            ]
            self.pt_state: PrimitiveEnum.RehabilitationPhysiotherapy.Massage.State = (
                PrimitiveEnum.RehabilitationPhysiotherapy.Massage.State.ReachedTarget
            )


class HighPerformanceVisionGuidance:
    class VSTeach(PrimitiveNode):
        pt_name = PrimitiveEnum.HighPerformanceVisionGuidance.VSTeach.pt_name

        def __init__(self, name):
            super(HighPerformanceVisionGuidance.VSTeach, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.HighPerformanceVisionGuidance.VSTeach.pt_type
            self.pt_state: PrimitiveEnum.HighPerformanceVisionGuidance.VSTeach.State = (
                PrimitiveEnum.HighPerformanceVisionGuidance.VSTeach.State.Terminated
            )
            self.required_params = [
                PrimitiveEnum.HighPerformanceVisionGuidance.VSTeach.InputParams.Basic.ObjName,
            ]

    class HPImageBasedVS(PrimitiveNode):
        pt_name = PrimitiveEnum.HighPerformanceVisionGuidance.HPImageBasedVS.pt_name

        def __init__(self, name):
            super(HighPerformanceVisionGuidance.HPImageBasedVS, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = (
                PrimitiveEnum.HighPerformanceVisionGuidance.HPImageBasedVS.pt_type
            )
            self.pt_state: (
                PrimitiveEnum.HighPerformanceVisionGuidance.HPImageBasedVS.State
            ) = (
                PrimitiveEnum.HighPerformanceVisionGuidance.HPImageBasedVS.State.ObjAligned
            )
            self.required_params = [
                PrimitiveEnum.HighPerformanceVisionGuidance.HPImageBasedVS.InputParams.Basic.TargetFeaturePts,
                PrimitiveEnum.HighPerformanceVisionGuidance.HPImageBasedVS.InputParams.Basic.TargetDepth,
                PrimitiveEnum.HighPerformanceVisionGuidance.HPImageBasedVS.InputParams.Basic.ObjName,
            ]

    class HPPoseBasedVS(PrimitiveNode):
        pt_name = PrimitiveEnum.HighPerformanceVisionGuidance.HPPoseBasedVS.pt_name

        def __init__(self, name):
            super(HighPerformanceVisionGuidance.HPPoseBasedVS, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = (
                PrimitiveEnum.HighPerformanceVisionGuidance.HPPoseBasedVS.pt_type
            )
            self.pt_state: (
                PrimitiveEnum.HighPerformanceVisionGuidance.HPPoseBasedVS.State
            ) = (
                PrimitiveEnum.HighPerformanceVisionGuidance.HPPoseBasedVS.State.ObjAligned
            )
            self.required_params = [
                PrimitiveEnum.HighPerformanceVisionGuidance.HPPoseBasedVS.InputParams.Basic.MaxAcc,
                PrimitiveEnum.HighPerformanceVisionGuidance.HPPoseBasedVS.InputParams.Basic.MaxVel,
                PrimitiveEnum.HighPerformanceVisionGuidance.HPPoseBasedVS.InputParams.Basic.ObjName,
            ]

    class HPOffsetServo(PrimitiveNode):
        pt_name = PrimitiveEnum.HighPerformanceVisionGuidance.HPOffsetServo.pt_name

        def __init__(self, name):
            super(HighPerformanceVisionGuidance.HPOffsetServo, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = (
                PrimitiveEnum.HighPerformanceVisionGuidance.HPOffsetServo.pt_type
            )
            self.pt_state: (
                PrimitiveEnum.HighPerformanceVisionGuidance.HPOffsetServo.State
            ) = (
                PrimitiveEnum.HighPerformanceVisionGuidance.HPOffsetServo.State.ObjAligned
            )
            self.required_params = [
                PrimitiveEnum.HighPerformanceVisionGuidance.HPOffsetServo.InputParams.Basic.MaxAcc,
                PrimitiveEnum.HighPerformanceVisionGuidance.HPOffsetServo.InputParams.Basic.MaxVel,
                PrimitiveEnum.HighPerformanceVisionGuidance.HPOffsetServo.InputParams.Basic.ObjName,
            ]


class Showcase:
    class BalanceBall(PrimitiveNode):
        pt_name = PrimitiveEnum.Showcase.BalanceBall.pt_name

        def __init__(self, name):
            super(Showcase.BalanceBall, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Showcase.BalanceBall.pt_type
            self.pt_state: PrimitiveEnum.Showcase.BalanceBall.State = (
                PrimitiveEnum.Showcase.BalanceBall.State.TimePeriod
            )
            self.required_params = [
                PrimitiveEnum.Showcase.BalanceBall.InputParams.Basic.BallWeight,
                PrimitiveEnum.Showcase.BalanceBall.InputParams.Basic.BallFricCoeff,
                PrimitiveEnum.Showcase.BalanceBall.InputParams.Basic.COPOffsetX,
                PrimitiveEnum.Showcase.BalanceBall.InputParams.Basic.COPOffsetY,
            ]

    class BalanceGlasses(PrimitiveNode):
        pt_name = PrimitiveEnum.Showcase.BalanceGlasses.pt_name

        def __init__(self, name):
            super(Showcase.BalanceGlasses, self).__init__(name)
            self.m_pt_name = self.pt_name
            self.m_pt_type = PrimitiveEnum.Showcase.BalanceGlasses.pt_type
            self.pt_state: PrimitiveEnum.Showcase.BalanceGlasses.State = (
                PrimitiveEnum.Showcase.BalanceGlasses.State.ReachedTarget
            )
            self.required_params = [
                PrimitiveEnum.Showcase.BalanceGlasses.InputParams.Basic.Target
            ]
