from elements.utils.expression_util import ExpressionUtil
from elements.proto.ProtoPlanParams_pb2 import ProtoExpressionParams
from loguru import logger


class Expression:
    def __init__(self, expr_str: str, target: str):
        self.expr_str = expr_str
        self.target = target
        try:
            self._expressions = ExpressionUtil.split_test(expr_str)
        except ValueError:
            self._expressions = []
            logger.error(f"Invalid expression: {expr_str}")

    def to_proto(self):
        # 这里可以根据需要实现将表达式转换为 proto 消息的逻辑
        # 这里只是一个示例，实际实现可能会更加复杂
        return self.expr_str
