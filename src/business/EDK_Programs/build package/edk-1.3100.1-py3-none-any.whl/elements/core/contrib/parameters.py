from abc import ABCMeta
from enum import Enum
from typing import Union

from elements.common.enums import (
    AIStateEnum,
    DeviceStateEnum,
    GPIOStateEnum,
    ParameterCategoryEnum,
    PlanEnum,
    SystemStateEnum,
    ToolNameEnum,
    VariableEnum,
)
from elements.core.variables import PlanVariable, ProjectVariable


class SwitchTcpParam:
    def __init__(
        self,
        switch: bool = True,
        name: str = ToolNameEnum.NO_TOOL.value,
        index: int = 0,
        var_name: str = "",
    ):
        self.m_switch_tcp = switch
        self.m_tool_name = name
        self.m_tcp_index = index
        self.m_tcp_var_name = var_name


class Parameter(metaclass=ABCMeta):
    def __init__(
        self, name: str, module_name: str = "", type: str = "", category: str = ""
    ):
        self.m_name = name
        self.m_module_name = module_name
        self.m_category = category
        self.type_mapping = None
        self.m_type = type


class ParameterPlanState(Parameter):
    category = "PLAN_STATE"

    def __init__(self, state: PlanEnum.State):
        super(ParameterPlanState, self).__init__(state.value["name"])
        self.m_module_name = "rootNode"
        self.m_category = ParameterCategoryEnum.PLAN_STATE.value
        self.m_type = state.value["type"]


class ParameterDeviceState:
    category = "DEVICE_STATE"

    class ConveyorModbusTCP1(Parameter):
        type = "Conveyor-ModbusTCP-1"

        def __init__(self, state: DeviceStateEnum.ConveyorStatusEnum):
            super(ParameterDeviceState.ConveyorModbusTCP1, self).__init__(
                state.value["name"]
            )
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class ConveyorModbusTCP2(Parameter):
        type = "Conveyor-ModbusTCP2"

        def __init__(self, state: DeviceStateEnum.ConveyorStatusEnum):
            super(ParameterDeviceState.ConveyorModbusTCP2, self).__init__(
                state.value["name"]
            )
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class ConveyorModbusTCP3(Parameter):
        type = "Conveyor-ModbusTCP3"

        def __init__(self, state: DeviceStateEnum.ConveyorStatusEnum):
            super(ParameterDeviceState.ConveyorModbusTCP3, self).__init__(
                state.value["name"]
            )
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class ConveyorSerialPort1(Parameter):
        type = "Conveyor-SerialPort1"

        def __init__(self, state: DeviceStateEnum.ConveyorStatusEnum):
            super(ParameterDeviceState.ConveyorSerialPort1, self).__init__(
                state.value["name"]
            )
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class ConveyorSerialPort2(Parameter):
        type = "Conveyor-SerialPort2"

        def __init__(self, state: DeviceStateEnum.ConveyorStatusEnum):
            super(ParameterDeviceState.ConveyorSerialPort2, self).__init__(
                state.value["name"]
            )
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class ConveyorSerialPort3(Parameter):
        type = "Conveyor-SerialPort3"

        def __init__(self, state: DeviceStateEnum.ConveyorStatusEnum):
            super(ParameterDeviceState.ConveyorSerialPort3, self).__init__(
                state.value["name"]
            )
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class GripperDahuan(Parameter):
        type = "GripperDahuan"

        def __init__(self, state: DeviceStateEnum.GripperDahuanStateEnum):
            super(ParameterDeviceState.GripperDahuan, self).__init__(
                state.value["name"]
            )
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class GripperDahuanModbus(Parameter):
        type = "GripperDahuanModbus"

        def __init__(self, state: DeviceStateEnum.GripperDahuanModbusStateEnum):
            super(ParameterDeviceState.GripperDahuanModbus, self).__init__(
                state.value["name"]
            )
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class FlexivGN01(Parameter):
        type = "Flexiv-GN01"

        def __init__(self, state: DeviceStateEnum.FlexivGN01StateEnum):
            super(ParameterDeviceState.FlexivGN01, self).__init__(state.value["name"])
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class GripperFlexivModbus(Parameter):
        type = "GripperFlexivModbus"

        def __init__(self, state: DeviceStateEnum.GripperFlexivModbusStateEnum):
            super(ParameterDeviceState.GripperFlexivModbus, self).__init__(
                state.value["name"]
            )
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class Robotiq2F85(Parameter):
        type = "Robotiq-2F-85"

        def __init__(self, state: DeviceStateEnum.Robotiq2F85StateEnum):
            super(ParameterDeviceState.Robotiq2F85, self).__init__(state.value["name"])
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class RobotiqHandE(Parameter):
        type = "Robotiq-Hand-E"

        def __init__(self, state: DeviceStateEnum.RobotiqHandEStateEnum):
            super(ParameterDeviceState.RobotiqHandE, self).__init__(state.value["name"])
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class IndustrialCam(Parameter):
        type = "IndustrialCam"

        def __init__(self, state: DeviceStateEnum.IndustrialCamStateEnum):
            super(ParameterDeviceState.IndustrialCam, self).__init__(
                state.value["name"]
            )
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]

    class MirkaAIROS550CV(Parameter):
        type = "Mirka-AIROS-550CV"

        def __init__(self, state: DeviceStateEnum.MirkaAIROS550CVStateEnum):
            super(ParameterDeviceState.MirkaAIROS550CV, self).__init__(
                state.value["name"]
            )
            self.m_module_name = self.type
            self.m_category = ParameterCategoryEnum.DEVICE_STATE.value
            self.m_type = state.value["type"]
            self.m_robotUnit = state.value["unit"]


class ParameterPlanVariable(Parameter):

    def __init__(self, plan_var: PlanVariable):
        super(ParameterPlanVariable, self).__init__(plan_var.m_name)
        self.m_module_name = "rootNode"
        self.m_type = plan_var.m_type
        self.m_category = ParameterCategoryEnum.PLAN_VAR.value
        self.m_robotUnit = plan_var.m_robotUnit


class ParameterProjectVariable(Parameter):
    def __init__(self, prj_var: ProjectVariable):
        super(ParameterProjectVariable, self).__init__(prj_var.m_name)
        self.m_module_name = "rootNode"
        self.m_type = prj_var.m_type
        self.m_category = ParameterCategoryEnum.PROJ_VAR.value
        self.m_robotUnit = prj_var.m_robotUnit


class ParameterGlobalVariable(Parameter):
    category = "GLOBAL_VAR"

    def __init__(
        self, global_var_name: str, global_var_type: VariableEnum.VariableType
    ):
        super(ParameterGlobalVariable, self).__init__(global_var_name)
        self.m_module_name = ""
        self.m_type = global_var_type
        self.m_category = ParameterCategoryEnum.GLOBAL_VAR.value
        if global_var_type in [
            VariableEnum.VariableType.COORD,
            VariableEnum.VariableType.POSE,
            VariableEnum.VariableType.ARRAY_COORD,
            VariableEnum.VariableType.ARRAY_COORD,
        ]:
            self.m_robotUnit = "m-deg"
        else:
            self.m_robotUnit = "none"


class ParameterPtState(Parameter):
    category = "PT_STATE"

    def __init__(self, pt: Union["PrimitiveNode", "Plan"], state: Enum):  # noqa: F821
        super(ParameterPtState, self).__init__(state.value["name"])
        if hasattr(pt, "m_node_name"):
            self.m_module_name = pt.m_node_name
        else:
            self.m_module_name = pt.m_plan_name
        self.m_category = ParameterCategoryEnum.PT_STATE.value
        self.m_type = state.value["type"]
        self.m_robotUnit = state.value["unit"]
        self.pt = pt


class ParameterGPIOState:
    class GPIOSystem(Parameter):
        def __init__(self, state: GPIOStateEnum.GPIOSystem):
            super(ParameterGPIOState.GPIOSystem, self).__init__(state.value)
            self.m_name = state.value["name"]
            self.m_module_name = "GPIOSystem"
            self.m_category = ParameterCategoryEnum.GPIO_STATE.value
            self.m_robotUnit = state.value["unit"]
            self.m_type = state.value["type"]

    class GPIOProfinetSlave(Parameter):
        def __init__(self, state: GPIOStateEnum.GPIOProfinetSlave):
            super(ParameterGPIOState.GPIOProfinetSlave, self).__init__(state.value)
            self.m_name = state.value["name"]
            self.m_module_name = "GPIOProfinetSlave"
            self.m_category = ParameterCategoryEnum.GPIO_STATE.value
            self.m_robotUnit = state.value["unit"]
            self.m_type = state.value["type"]

    class GPIOModbusTCPSlave(Parameter):
        def __init__(self, state: GPIOStateEnum.GPIOModbusTCPSlave):
            super(ParameterGPIOState.GPIOModbusTCPSlave, self).__init__(state.value)
            self.m_name = state.value["name"]
            self.m_module_name = "GPIOModbusTCPSlave"
            self.m_category = ParameterCategoryEnum.GPIO_STATE.value
            self.m_robotUnit = state.value["unit"]
            self.m_type = state.value["type"]

    class GPIOAnybus(Parameter):
        def __init__(self, state: Enum):
            super(ParameterGPIOState.GPIOAnybus, self).__init__(state.value)
            self.m_name = state.value["name"]
            self.m_module_name = "GPIOAnybus"
            self.m_category = ParameterCategoryEnum.GPIO_STATE.value
            self.m_robotUnit = state.value["unit"]
            self.m_type = state.value["type"]


class ParameterSystemState(Parameter):
    category = "SYS_STATE"

    def __init__(self, state: SystemStateEnum):
        super(ParameterSystemState, self).__init__(state.value)
        self.m_name = state.value["name"]
        self.m_module_name = "SYSTEM"
        self.m_category = ParameterCategoryEnum.SYS_STATE.value
        self.m_robotUnit = state.value["unit"]
        self.m_type = state.value["type"]


class ParameterAIState(Parameter):
    def __init__(self, state: AIStateEnum):
        super(ParameterAIState, self).__init__(state.value)
        self.m_name = state.value["name"]
        self.m_module_name = "AI"
        self.m_category = ParameterCategoryEnum.AI_STATE.value
        self.m_type = state.value["type"]


class ParameterPlanInput(Parameter):
    category = "PLAN_INPUT"

    def __init__(
        self, param: Union[PlanEnum.InputParams.Basic, PlanEnum.InputParams.Advanced]
    ):
        super(ParameterPlanInput, self).__init__(param.value)
        self.m_name = param.value["name"]
        self.m_module_name = "rootNode"
        self.m_category = ParameterCategoryEnum.PLAN_INPUT.value
        self.m_type = param.value["type"]


class ParameterPlanOutput(Parameter):
    def __init__(self, state: PlanEnum.OutputParams):
        super(ParameterPlanOutput, self).__init__(state.value)
        self.m_name = state.value["name"]
        self.m_module_name = "rootNode"
        self.m_category = ParameterCategoryEnum.PLAN_OUTPUT.value
        self.m_type = state.value["type"]


class ParameterPtInput(Parameter):

    def __init__(
        self, pt: Union["PrimitiveNode", "Plan"], pt_param: Enum  # noqa: F821
    ):
        super(ParameterPtInput, self).__init__(pt_param.value.get("name"))
        if hasattr(pt, "m_plan_name"):
            self.m_module_name = pt.m_plan_name
        else:
            self.m_module_name = pt.m_node_name
        self.m_category = ParameterCategoryEnum.PT_INPUT.value
        self.m_type = pt_param.value.get("type")
        self.pt = pt


class ParameterPtOutput(Parameter):
    def __init__(
        self, pt: Union["PrimitiveNode", "Plan"], pt_param: Enum  # noqa: F821
    ):
        super(ParameterPtOutput, self).__init__(pt_param.value.get("name"))
        if hasattr(pt, "m_plan_name"):
            self.m_module_name = pt.m_plan_name
        else:
            self.m_module_name = pt.m_node_name
        self.m_category = ParameterCategoryEnum.PT_OUTPUT.value
        self.m_type = pt_param.value.get("type")
        self.pt = pt
