from abc import ABCMeta
from enum import Enum
from typing import List

from elements.common.enums import PlanEnum
from elements.core import gen_proto_obj
from elements.core.contrib.parameters import SwitchTcpParam
from elements.core.transit import Transit
from elements.proto.ProtoPlanParams_pb2 import ProtoNodeParams


class Node(metaclass=ABCMeta):
    def __init__(self, name: str):
        self.m_node_name = name
        self.m_pt_name = ""
        self.m_pt_type = ""
        self.m_is_breakpoint = False
        self.m_lock_external_axes = True
        self.m_enable_sync_motion = False
        self.cm_switch_tcp_param = SwitchTcpParam()
        self.parent = None
        self.transits = []
        self.next_primitives: List["Node"] = []
        self.next_subplans: List["Plan"] = []  # noqa F821

    def add_transit(self, transit: Transit):
        from elements.core.plan import Plan

        if isinstance(transit.end_node, Plan):
            self.next_subplans.append(transit.end_node)
        elif isinstance(transit.end_node, Node):
            self.next_primitives.append(transit.end_node)
        else:
            raise TypeError(f"Unsupported type: {type(transit.end_node)}")
        self.transits.append(transit)

    @property
    def name(self):
        return self.m_node_name

    def to_graph(self):
        from transitions.extensions import GraphMachine

        states = []
        states.extend([node.m_node_name for node in self.next_primitives])
        states.extend([plan.m_plan_name for plan in self.next_subplans])
        transitions = []
        for transit in self.transits:
            transitions.append(
                {
                    "trigger": transit.name,
                    "source": transit.m_start_node_name,
                    "dest": transit.m_end_node_name,
                }
            )
        machine = GraphMachine(
            model=self,
            states=states,
            transitions=transitions,
            use_pygraphviz=False,
        )
        graph = machine.get_graph()
        # 移除默认添加的initial结点
        graph.body = [
            line for line in graph.body if not line.strip().startswith("initial")
        ]
        graph.node_attr["fontname"] = "Microsoft Yahei"
        graph.node_attr["fontname"] = "Microsoft Yahei"
        graph.graph_attr["fontname"] = "Microsoft Yahei"
        graph.graph_attr["dpi"] = "300"  # 设置分辨率
        graph.graph_attr.pop("label")  # 删除标题
        for node in self.next_primitives:
            graph.node(
                name=node.m_node_name,
                shape="ellipse",
                color="red",
                style="filled",
                fillcolor="pink",
            )
        for subplan in self.next_subplans:
            graph.node(
                name=subplan.m_plan_name,
                shape="box",
                color="blue",
                style="filled",
                fillcolor="lightblue",
            )
        graph.draw(f"{self.m_node_name}.png", prog="dot")

    def to_proto(self) -> ProtoNodeParams:
        obj = ProtoNodeParams()
        for k, v in self.__dict__.items():
            if k.startswith("m_"):
                if isinstance(v, Enum):
                    setattr(obj, k[2:], v.value)
                else:
                    setattr(obj, k[2:], v)
            elif k.startswith("cm_"):
                gen_proto_obj(obj, k[3:], v)
            elif k.startswith("cml_"):
                sub_v_objs = []
                for item in v:
                    sub_v_objs.append(item.to_proto())
                getattr(obj, k[4:]).extend(sub_v_objs)
        return obj


class RootNode(Node):
    def __init__(self, name: str = "rootNode"):
        super(RootNode, self).__init__(name=name)
        self.m_pt_name = PlanEnum.plan_name
        self.m_pt_type = PlanEnum.plan_type


class StartNode(Node):
    def __init__(self, name: str = "startNode"):
        super().__init__(name=name)
        self.m_pt_name = PlanEnum.plan_name
        self.m_pt_type = PlanEnum.plan_type


class PlanNode(Node):
    def __init__(self, name: str):
        super().__init__(name)
        self.m_pt_name = PlanEnum.plan_name
        self.m_pt_type = PlanEnum.plan_type
