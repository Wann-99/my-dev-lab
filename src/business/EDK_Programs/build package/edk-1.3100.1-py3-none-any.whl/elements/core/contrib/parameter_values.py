from abc import ABCMeta
from enum import Enum

from elements.common.enums import (
    ParameterCategoryEnum,
    ParameterValueTypeEnum,
    VariableEnum,
)
from elements.core.variables import GlobalVariable, PlanVariable, ProjectVariable


class ParameterValue(metaclass=ABCMeta):
    def __init__(self, value: str):
        self._value = value
        self.m_type = None

    @property
    def value(self):
        return str(self._value)


class ParameterValueConstInt(ParameterValue):
    type = ParameterValueTypeEnum.INT.value

    def __init__(self, value: int = 0):
        super(ParameterValueConstInt, self).__init__(str(value))
        self._value = value
        self.m_type = ParameterValueTypeEnum.INT
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = [str(value)]

    @property
    def value(self):
        return str(self._value)


class ParameterValueConstBool(ParameterValue):
    type = ParameterValueTypeEnum.BOOL.value

    def __init__(self, value: bool = False):
        super(ParameterValueConstBool, self).__init__(str(int(value)))
        self._value = value
        self.m_type = ParameterValueTypeEnum.BOOL
        self.m_category = ParameterCategoryEnum.CONST.value
        if value:
            self.ml_data = ["1"]
        else:
            self.ml_data = ["0"]

    @property
    def value(self):
        return str(self._value)


class ParameterValueConstDouble(ParameterValue):
    type = ParameterValueTypeEnum.DOUBLE.value

    def __init__(self, value: float = 0.0):
        super(ParameterValueConstDouble, self).__init__(str(value))
        self._value = value
        self.m_type = ParameterValueTypeEnum.DOUBLE
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = [str(value)]

    @property
    def value(self):
        return str(self._value)


class ParameterValueConstString(ParameterValue):
    type = ParameterValueTypeEnum.STRING.value

    def __init__(self, value: str = ""):
        super(ParameterValueConstString, self).__init__(value)
        self._value = value
        self.m_type = ParameterValueTypeEnum.STRING
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = [value]

    @property
    def value(self):
        return self._value


class ParameterValueConstVEC2D(ParameterValue):
    type = ParameterValueTypeEnum.VEC_2D.value

    def __init__(self, d1: float = 0.0, d2: float = 0.0):
        value = ",".join(str(item) for item in [d1, d2])
        super(ParameterValueConstVEC2D, self).__init__(str(value))
        self.m_type = ParameterValueTypeEnum.VEC_2D
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstVEC3D(ParameterValue):
    type = ParameterValueTypeEnum.VEC_3D.value

    def __init__(self, d1: float = 0.0, d2: float = 0.0, d3: float = 0.0):
        value = ",".join(str(item) for item in [d1, d2, d3])
        super(ParameterValueConstVEC3D, self).__init__(str(value))
        self.m_type = ParameterValueTypeEnum.VEC_3D
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstVEC4D(ParameterValue):
    type = ParameterValueTypeEnum.VEC_4D.value

    def __init__(
        self, d1: float = 0.0, d2: float = 0.0, d3: float = 0.0, d4: float = 0.0
    ):
        value = ",".join(str(item) for item in [d1, d2, d3, d4])
        super(ParameterValueConstVEC4D, self).__init__(str(value))
        self.m_type = ParameterValueTypeEnum.VEC_4D
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstVEC6D(ParameterValue):
    type = ParameterValueTypeEnum.VEC_6D.value

    def __init__(
        self,
        d1: float = 0.0,
        d2: float = 0.0,
        d3: float = 0.0,
        d4: float = 0.0,
        d5: float = 0.0,
        d6: float = 0.0,
    ):
        value = ",".join(str(item) for item in [d1, d2, d3, d4, d5, d6])
        super(ParameterValueConstVEC6D, self).__init__(str(value))
        self.m_type = ParameterValueTypeEnum.VEC_6D
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstVEC7D(ParameterValue):
    type = ParameterValueTypeEnum.VEC_7D.value

    def __init__(
        self,
        d1: float = 0.0,
        d2: float = 0.0,
        d3: float = 0.0,
        d4: float = 0.0,
        d5: float = 0.0,
        d6: float = 0.0,
        d7: float = 0.0,
    ):
        value = ",".join(str(item) for item in [d1, d2, d3, d4, d5, d6, d7])
        super(ParameterValueConstVEC7D, self).__init__(str(value))
        self.m_type = ParameterValueTypeEnum.VEC_7D
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstVEC2I(ParameterValue):
    type = ParameterValueTypeEnum.VEC_2I.value

    def __init__(self, i1: int = 0, i2: int = 0):
        value = ",".join(str(item) for item in [i1, i2])
        super(ParameterValueConstVEC2I, self).__init__(str(value))
        self.m_type = ParameterValueTypeEnum.VEC_2I
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstVEC3I(ParameterValue):
    type = ParameterValueTypeEnum.VEC_3I.value

    def __init__(self, i1: int = 0, i2: int = 0, i3: int = 0):
        value = ",".join(str(item) for item in [i1, i2, i3])
        super(ParameterValueConstVEC3I, self).__init__(str(value))
        self.m_type = ParameterValueTypeEnum.VEC_3I
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstVEC6I(ParameterValue):
    type = ParameterValueTypeEnum.VEC_6I.value

    def __init__(
        self,
        i1: int = 0,
        i2: int = 0,
        i3: int = 0,
        i4: int = 0,
        i5: int = 0,
        i6: int = 0,
    ):
        value = ",".join(str(item) for item in [i1, i2, i3, i4, i5, i6])
        super(ParameterValueConstVEC6I, self).__init__(str(value))
        self.m_type = ParameterValueTypeEnum.VEC_6I
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstType(ParameterValue):
    type = ParameterValueTypeEnum.TYPE.value

    def __init__(self, value: Enum):
        super(ParameterValueConstType, self).__init__(value.value)
        self.m_type = ParameterValueTypeEnum.TYPE
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = [self._value]


class ParameterValueConstMSG(ParameterValue):
    type = ParameterValueTypeEnum.MSG.value

    def __init__(self, value: str = ""):
        super(ParameterValueConstMSG, self).__init__(value)
        self._value = value
        self.m_type = ParameterValueTypeEnum.MSG
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = [value]


class ParameterValueConstFile(ParameterValue):
    type = ParameterValueTypeEnum.FILE.value

    def __init__(self, value: str = ""):
        super(ParameterValueConstFile, self).__init__(value)
        self._value = value
        self.m_type = ParameterValueTypeEnum.FILE
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = [value]


class ParameterValueConstObjName(ParameterValue):
    type = ParameterValueTypeEnum.OBJNAME.value

    def __init__(self, value: str = ""):
        super(ParameterValueConstObjName, self).__init__(value)
        self._value = value
        self.m_type = ParameterValueTypeEnum.OBJNAME
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = [value]


class ParameterValueConstArrayType(ParameterValue):
    type = ParameterValueTypeEnum.ARRAY_TYPE.value

    def __init__(self, value: list[Enum]):
        value = ",".join(str(item.value) for item in value)
        super(ParameterValueConstArrayType, self).__init__(value)
        self.m_type = ParameterValueTypeEnum.ARRAY_TYPE
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstArrayDouble(ParameterValue):
    type = ParameterValueTypeEnum.ARRAY_DOUBLE.value

    def __init__(self, value: list[float]):
        value = ",".join(str(item) for item in value)
        super(ParameterValueConstArrayDouble, self).__init__(value)
        self.m_type = ParameterValueTypeEnum.ARRAY_DOUBLE
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstArrayVEC2D(ParameterValue):
    type = ParameterValueTypeEnum.ARRAY_VEC_2D.value

    def __init__(self, value: list[list[float]]):
        if not isinstance(value, list):
            raise TypeError("Value must be a list")
        if all(isinstance(item, list) and len(item) % 2 == 0 for item in value):
            value = [item for sublist in value for item in sublist]
        else:
            raise TypeError("Item must be a Vec_2d")
        if not all(isinstance(item, float) for item in value):
            raise TypeError("All items should be float")

        value = ",".join(str(item) for item in value)
        super(ParameterValueConstArrayVEC2D, self).__init__(str(value))

        self.m_type = ParameterValueTypeEnum.ARRAY_VEC_2D
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstArrayVEC6D(ParameterValue):
    type = ParameterValueTypeEnum.ARRAY_VEC_6D.value

    def __init__(self, value: list[list[float]]):
        if not isinstance(value, list):
            raise TypeError("Value must be a list")
        if all(isinstance(item, list) and len(item) % 6 == 0 for item in value):
            value = [item for sublist in value for item in sublist]
        else:
            raise TypeError("Item must be a Vec_6d")
        if not all(isinstance(item, float) for item in value):
            raise TypeError("All items should be float")

        value = ",".join(str(item) for item in value)

        super(ParameterValueConstArrayVEC6D, self).__init__(str(value))
        self.m_type = ParameterValueTypeEnum.ARRAY_VEC_6D
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstJPos(ParameterValue):
    type = ParameterValueTypeEnum.JPOS.value

    def __init__(
        self,
        a1: float = 0.0,
        a2: float = -40.0,
        a3: float = 0.0,
        a4: float = 90.0,
        a5: float = 0.0,
        a6: float = 40.0,
        a7: float = 0.0,
        ext1: float = 0.0,
        ext2: float = 0.0,
        ext3: float = 0.0,
        ext4: float = 0.0,
        ext5: float = 0.0,
        ext6: float = 0.0,
    ):
        value = ",".join(
            str(item)
            for item in [a1, a2, a3, a4, a5, a6, a7, ext1, ext2, ext3, ext4, ext5, ext6]
        )
        super(ParameterValueConstJPos, self).__init__(value)
        self.m_type = ParameterValueTypeEnum.JPOS
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")

    @property
    def value(self):
        return str(self.ml_data)


class ParameterValueConstPose(ParameterValue):
    type = ParameterValueTypeEnum.POSE.value

    def __init__(
        self,
        x: float = 0.0,
        y: float = 0.0,
        z: float = 0.0,
        rx: float = 0.0,
        ry: float = 0.0,
        rz: float = 0.0,
    ):
        value = ",".join(
            str(item) for item in [x / 1000, y / 1000, z / 1000, rx, ry, rz]
        )
        super(ParameterValueConstPose, self).__init__(value)
        self.m_type = ParameterValueTypeEnum.POSE
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = [
            str(x / 1000),
            str(y / 1000),
            str(z / 1000),
            str(rx),
            str(ry),
            str(rz),
        ]

    @property
    def value(self):
        return str(self.ml_data)


class ParameterValueConstCoord(ParameterValue):
    type = ParameterValueTypeEnum.COORD.value

    def __init__(
        self,
        x: float = 0.0,
        y: float = 0.0,
        z: float = 0.0,
        rx: float = 0.0,
        ry: float = 0.0,
        rz: float = 0.0,
        coord: str = "WORLD::WORLD_ORIGIN",
        ref_a1: float = 0.0,
        ref_a2: float = -40.0,
        ref_a3: float = 0.0,
        ref_a4: float = 90.0,
        ref_a5: float = 0.0,
        ref_a6: float = 40.0,
        ref_a7: float = 0.0,
        ext1: float = 0.0,
        ext2: float = 0.0,
        ext3: float = 0.0,
        ext4: float = 0.0,
        ext5: float = 0.0,
        ext6: float = 0.0,
    ):
        value = ",".join(
            str(item)
            for item in [
                x / 1000,
                y / 1000,
                z / 1000,
                rx,
                ry,
                rz,
                coord,
                ref_a1,
                ref_a2,
                ref_a3,
                ref_a4,
                ref_a5,
                ref_a6,
                ref_a7,
                ext1,
                ext2,
                ext3,
                ext4,
                ext5,
                ext6,
            ]
        )
        super(ParameterValueConstCoord, self).__init__(value)
        self.m_type = VariableEnum.VariableType.COORD
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = [
            str(x / 1000),
            str(y / 1000),
            str(z / 1000),
            str(rx),
            str(ry),
            str(rz),
            coord.split("::")[0],
            coord.split("::")[1],
            str(ref_a1),
            str(ref_a2),
            str(ref_a3),
            str(ref_a4),
            str(ref_a5),
            str(ref_a6),
            str(ref_a7),
            str(ext1),
            str(ext2),
            str(ext3),
            str(ext4),
            str(ext5),
            str(ext6),
        ]

    @property
    def value(self):
        return str(self.ml_data)


class ParameterValueConstArrayJPos(ParameterValue):
    type = ParameterValueTypeEnum.ARRAY_JPOS.value

    def __init__(self, value: list[list[float | int]]):
        if not isinstance(value, list):
            raise TypeError("Value must be a list")
        if all(isinstance(item, list) and len(item) % 13 == 0 for item in value):
            value = [item for sublist in value for item in sublist]
        else:
            raise TypeError("Item must be a JPos")
        if not all(isinstance(item, float | int) for item in value):
            raise TypeError("All items should be number")

        value = ",".join(str(item) for item in value)
        super(ParameterValueConstArrayJPos, self).__init__(str(value))

        self.m_type = ParameterValueTypeEnum.ARRAY_JPOS
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValueConstArrayCoord(ParameterValue):
    type = ParameterValueTypeEnum.ARRAY_COORD.value

    def __init__(self, value: list[list]):
        if not isinstance(value, list):
            raise TypeError("Value must be a list")
        if all(isinstance(item, list) and len(item) % 20 == 0 for item in value):
            value = [item for sublist in value for item in sublist]
        else:
            raise TypeError("Item must be a Coord")
        convert_data = []
        for i in range(len(value)):
            if i % 20 == 6:
                if not isinstance(value[i], str) or "::" not in value[i]:
                    raise ValueError(
                        f"coord_system:{value[i]} does not match expectation."
                    )
                convert_data.extend(value[i].split("::"))
            else:
                if not isinstance(value[i], float | int):
                    raise TypeError("All items should be number")
                if i % 20 < 3:
                    convert_data.append(value[i] / 1000)
                else:
                    convert_data.append(value[i])

        value = ",".join(str(item) for item in convert_data)
        super(ParameterValueConstArrayCoord, self).__init__(str(value))

        self.m_type = ParameterValueTypeEnum.ARRAY_COORD
        self.m_category = ParameterCategoryEnum.CONST.value
        self.ml_data = value.split(",")


class ParameterValuePlanVariable(ParameterValue):

    def __init__(self, plan_var: PlanVariable):
        super(ParameterValuePlanVariable, self).__init__(plan_var.value)
        self.m_name = plan_var.m_name
        self.m_module_name = "rootNode"
        self.m_type = plan_var.m_type
        self.m_category = ParameterCategoryEnum.PLAN_VAR.value


class ParameterValueProjectVariable(ParameterValue):
    def __init__(self, prj_var: ProjectVariable):
        super(ParameterValueProjectVariable, self).__init__(prj_var.value)
        self.m_name = prj_var.m_name
        self.m_module_name = "rootNode"
        self.m_type = prj_var.m_type
        self.m_category = ParameterCategoryEnum.PROJ_VAR.value


class ParameterValueGlobalVariable(ParameterValue):
    """
    ToDo: 尚未实现
    """

    def __init__(self, g_var: GlobalVariable):
        super(ParameterValueGlobalVariable, self).__init__(g_var.value)
        self.m_name = g_var.m_name
        self.m_type = g_var.m_type
        self.m_category = ParameterCategoryEnum.GLOBAL_VAR.value
