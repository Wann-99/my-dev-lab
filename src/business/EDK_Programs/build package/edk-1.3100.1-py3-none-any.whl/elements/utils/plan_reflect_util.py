import importlib
import inspect


class PlanReflectUtil:

    @staticmethod
    def get_nested_class(module, class_path: str):
        """通过字符串路径获取嵌套类，比如 'A.B.C'"""
        obj = module
        for attr in class_path.split("."):
            obj = getattr(obj, attr)
        return obj

    @staticmethod
    def module_classes_key_value(
        module_name: str, classes_name: str, value_name: str
    ) -> str:
        module = importlib.import_module(module_name)
        cls = PlanReflectUtil.get_nested_class(module, classes_name)
        for var, var_value in inspect.getmembers(cls):
            if var_value.value == value_name:
                return classes_name + "." + var_value.name
        raise Exception(
            f"Could not find value_name '{value_name}' under '{module_name}'/'{classes_name}'"
        )

    @staticmethod
    def module_class_class_key_dict(
        module_name: str,
        class_name: str,
        sub_class_key: str,
        sub_class_value: str,
        target_value_name: str,
    ) -> str:
        """
        module /  class / class / key-dict
        """
        module = importlib.import_module(module_name)
        sub_class_name = ""
        for name, cls in inspect.getmembers(module, inspect.isclass):
            # match class name
            if (
                name.startswith("__")
                or cls.__module__ != module_name
                or name != class_name
            ):
                continue

            for _name, _value in inspect.getmembers(cls):
                if _name.startswith("__"):
                    continue
                if (
                    hasattr(_value, sub_class_key)
                    and getattr(_value, sub_class_key).value == sub_class_value
                ):
                    sub_class_name = _name
                    for __name, __value in inspect.getmembers(_value):
                        if __value.value["name"] == target_value_name:
                            return ".".join([name, _name, __name])

        raise Exception(
            f"Could not find value name '{target_value_name}' under '{module_name}'/'{class_name}'/'{sub_class_name}'"
        )

    @staticmethod
    def module_class_class_class_key_dict(
        module_name: str,
        class_name: str,
        target_sub_class_name: str,
        target_property_name: str,
        target_name: str,
    ) -> str:
        """
        module / class / class / class (target_class_name) / key-dict
        """
        module = importlib.import_module(module_name)
        # match class name
        for name, cls in inspect.getmembers(module, inspect.isclass):

            if (
                name.startswith("__")
                or cls.__module__ != module_name
                or name != class_name
            ):
                continue
            # primitive category
            for category_name, category_value in inspect.getmembers(cls):
                if category_name.startswith("__"):
                    continue
                # primitive name
                for primitive_name, primitive_value in inspect.getmembers(
                    category_value
                ):
                    if (
                        primitive_name.startswith("__")
                        or not hasattr(primitive_value, "pt_name")
                    ) or getattr(primitive_value, "pt_name") != target_sub_class_name:
                        continue
                    # InputParams / OutputParams / State
                    for property_name, property_value in inspect.getmembers(
                        primitive_value
                    ):
                        if property_name != target_property_name:
                            continue
                        # "State", "OutputParams"
                        if property_name in ["State", "OutputParams"]:
                            for _name, _value in inspect.getmembers(property_value):
                                if (
                                    hasattr(_value, "name")
                                    and getattr(_value, "value").get("name")
                                    == target_name
                                ):
                                    return ".".join(
                                        [
                                            class_name,
                                            category_name,
                                            primitive_name,
                                            property_name,
                                            _name,
                                        ]
                                    )
                        else:
                            # InputParams
                            for _name, _value in inspect.getmembers(property_value):
                                for __name, __value in inspect.getmembers(_value):
                                    if (
                                        hasattr(__value, "name")
                                        and getattr(__value, "value").get("name")
                                        == target_name
                                    ):
                                        return ".".join(
                                            [
                                                category_name,
                                                primitive_name,
                                                property_name,
                                                _name,
                                                __name,
                                            ]
                                        )
        raise Exception(
            f"Could not find value name '{target_name}' under "
            f"'{module_name}/{class_name}/{target_sub_class_name}/{target_property_name}'"
        )

    @staticmethod
    def module_class_key_dict(
        module_name: str,
        class_name: str,
        target_name: str = "",
        target_value: str = "",
        target_type: str = "",
    ):
        module = importlib.import_module(module_name)
        # category
        for name, cls in inspect.getmembers(module, inspect.isclass):
            # only parse class defined under module_name
            if (
                name.startswith("__")
                or cls.__module__ != module_name
                or name != class_name
            ):
                continue
            for var, var_value in inspect.getmembers(cls):
                if target_value and var_value.value.get("value") != target_value:
                    continue
                if target_type and var_value.value.get("type") != target_type:
                    continue
                if target_name and var_value.value.get("name") != target_name:
                    continue
                return name + "." + var_value.name
        raise Exception(
            f"Could not find target_value_name {target_value} / {target_type} under '{module_name}'.'{class_name}'"
        )

    @staticmethod
    def module_class_class_key_value(
        module_name: str, class_name: str, sub_class_key: str, target_class_value: str
    ) -> str:
        module = importlib.import_module(module_name)

        for name, cls in inspect.getmembers(module, inspect.isclass):
            # only parse class defined under module_name
            if name.startswith("__") or cls.__name__ != class_name:
                continue
            for sub_name, sub_cls in inspect.getmembers(cls, inspect.isclass):
                if sub_name.startswith("__"):
                    continue
                if (
                    hasattr(sub_cls, sub_class_key)
                    and getattr(sub_cls, sub_class_key) == target_class_value
                ):
                    return f"{name}.{sub_name}"
        raise Exception(
            f"Could not find target_class_value '{sub_class_key}:{target_class_value}' under '{module_name}/{class_name}'"
        )

    @staticmethod
    def module_class_class_class_key_value(
        module_name: str, class_name: str, sub_class_name: str, target_value: str
    ) -> str:
        module = importlib.import_module(module_name)

        for name, cls in inspect.getmembers(module, inspect.isclass):
            # only parse class defined under module_name
            if name.startswith("__") or cls.__name__ != class_name:
                continue
            for sub_name, sub_cls in inspect.getmembers(cls, inspect.isclass):
                if sub_name.startswith("__") or sub_name != sub_class_name:
                    continue
                for _name, _value in inspect.getmembers(sub_cls, inspect.isclass):
                    for item in _value:
                        if item.value == target_value:
                            return f"{name}.{sub_name}.{_name}.{item.name}"
        raise Exception(
            f"Could not find target_value '{sub_class_name}:{target_value}' under '{module_name}.{class_name}.{sub_class_name}'"
        )

    @staticmethod
    def get_primitive_class_by_pt_name(pt_name: str) -> str:
        """
        module / class / class / property
        """
        module_name = "elements.core.primitives"
        module = importlib.import_module(module_name)
        # category
        for name, cls in inspect.getmembers(module, inspect.isclass):
            # only parse class defined under module_name
            if name.startswith("__") or cls.__module__ != module_name:
                continue
            # primitive
            for sub_name, sub_cls in inspect.getmembers(cls, inspect.isclass):
                if sub_name.startswith("__"):
                    continue
                if hasattr(sub_cls, "pt_name") and sub_cls.pt_name == pt_name:
                    return f"{name}.{pt_name}"
        raise Exception(f"Could not find primitive name '{pt_name}'")

    @staticmethod
    def get_primitive_parameter_class_by_param_name(
        module_name: str, primitive_name: str, param_name: str
    ) -> str:
        """
        module / class / class / class / key-dict
        """
        module = importlib.import_module(module_name)
        param_cls = PlanReflectUtil.get_nested_class(module, f"{primitive_name}")
        # PrimitiveInputParameterEnum.Motion.MoveC
        for name, cls in inspect.getmembers(param_cls, inspect.isclass):
            if name == "__class__":
                continue
            # Basic, Advanced
            for var, var_value in inspect.getmembers(cls):
                if var.startswith("__") or var in ["name", "value"]:
                    continue
                for param in var_value:
                    if "name" in param.value and param.value["name"] == param_name:
                        return (
                            primitive_name + "." + name + "." + var + "." + param.name
                        )
        raise Exception(f"Could not find param name name '{param_name}'")

    @staticmethod
    def get_primitive_parameter_value_class_by_param_type(
        module_name: str, param_type: str
    ) -> str:
        """
        module / class / property
        """
        module = importlib.import_module(module_name)
        for name, cls in inspect.getmembers(module, inspect.isclass):
            if name == "__class__" or cls.__module__ != module_name:
                continue
            if hasattr(cls, "type") and cls.type == param_type:
                return name
        raise Exception(f"Could not find param type '{param_type}'")

    @staticmethod
    def get_transit_condition_operator_type_by_condition_type(
        condition_type: str,
    ) -> str:
        """
        module / class / key-dict
        """
        return PlanReflectUtil.module_class_key_dict(
            module_name="elements.common.enums",
            class_name="TransitConditionOperatorEnum",
            target_type=condition_type,
        )

    @staticmethod
    def get_transit_condition_pt_state_by_pt_state(pt_name: str, pt_state: str) -> str:
        """
        module /  class / class (key-value) / key-dict
        """
        return PlanReflectUtil.module_class_class_class_key_dict(
            module_name="elements.common.enums",
            class_name="PrimitiveEnum",
            target_sub_class_name=pt_name,
            target_property_name="State",
            target_name=pt_state,
        )

    @staticmethod
    def get_transit_condition_plan_state_by_pt_state(plan_state: str) -> str:
        """
        module /  class / key-dict
        """
        module_name = "elements.common.enums"
        module = importlib.import_module(module_name)
        class_name = "PlanEnum"
        sub_class_name = "State"
        for name, cls in inspect.getmembers(module, inspect.isclass):
            # match class name
            if (
                name.startswith("__")
                or cls.__module__ != module_name
                or name != class_name
            ):
                continue
            for _name, _value in inspect.getmembers(cls):
                if _name.startswith("__") or _name != sub_class_name:
                    continue
                for __name, __value in inspect.getmembers(_value):
                    if __value.value["name"] == plan_state:
                        return ".".join([name, _name, __name])

        raise Exception(
            f"Could not find plan state '{plan_state}' under '{module_name}.{class_name}.{sub_class_name}'"
        )

    @staticmethod
    def get_transit_condition_sys_state_by_sys_state(sys_state: str) -> str:
        """
        module / class / key-dict
        """
        return PlanReflectUtil.module_class_key_dict(
            module_name="elements.common.enums",
            class_name="SystemStateEnum",
            target_name=sys_state,
        )

    @staticmethod
    def get_transit_condition_plan_input_by_input_param(input_param: str) -> str:
        """
        module / class / key-dict
        """
        return PlanReflectUtil.module_class_key_dict(
            module_name="elements.common.enums",
            class_name="PlanInputEnum",
            target_name=input_param,
        )

    @staticmethod
    def get_variable_type_by_type(type_name: str) -> str:
        return PlanReflectUtil.module_classes_key_value(
            module_name="elements.common.enums",
            classes_name="VariableEnum.VariableType",
            value_name=type_name,
        )

    @staticmethod
    def get_device_state_class_by_device_name(device_name: str) -> str:
        """
        module / class / class (key-value)
        """
        return PlanReflectUtil.module_class_class_key_value(
            module_name="elements.core.contrib.parameters",
            class_name="ParameterDeviceState",
            sub_class_key="type",
            target_class_value=device_name,
        )

    @staticmethod
    def get_device_state_by_state_name(device_name: str, state_name: str) -> str:
        """
        module / class / class (key-value) / key-dict
        """
        return PlanReflectUtil.module_class_class_key_dict(
            module_name="elements.common.enums",
            class_name="DeviceStateEnum",
            sub_class_key="type",
            sub_class_value=device_name,
            target_value_name=state_name,
        )

    @staticmethod
    def get_device_state_value_by_state_value(state_value: str) -> str:
        return PlanReflectUtil.module_class_class_class_key_value(
            module_name="elements.common.enums",
            class_name="ParameterTypeValueEnum",
            sub_class_name="DeviceStateValue",
            target_value=state_value,
        )
