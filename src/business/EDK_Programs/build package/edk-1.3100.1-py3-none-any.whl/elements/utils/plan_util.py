from google.protobuf.text_format import Parse

from elements.common.enums import SoftwareVersionEnum
from elements.proto.ProtoPlanParams_pb2 import ProtoPlanParams
from elements.utils.plan_reflect_util import PlanReflectUtil
from elements.utils.plan_template_util import PlanTemplateUtil


class PlanUtil:

    @staticmethod
    def to_code(plan_file_name: str):
        def get_pt_name_by_node_name(node_name: str) -> str:
            for node in plan_obj.node_list:
                if node.node_name == node_name:
                    return node.pt_name
            raise Exception(f"Could not find node name '{node_name}'")

        # read plan proto
        with open(plan_file_name, "r") as f:
            plan_obj = ProtoPlanParams()
            Parse(f.read(), plan_obj)

        plan_name = plan_obj.plan_name

        # add import
        code_strs = [
            "from elements.core.plan import *",
            "from elements.core.primitives import *",
            "from elements.core.transit import *",
            "from elements.core.contrib.parameter_values import *",
            "from elements.core.contrib.parameters import *",
            "from elements.common.wrappers import TRANSIT",
            "from elements.common.enums import *",
            "\n",
        ]

        # define transit
        for transit in plan_obj.transit_list:
            if transit.start_node_name == "startNode":
                start_node_name = "start"
            else:
                start_node_name = transit.start_node_name
            end_node_name = transit.end_node_name
            transit_func_name = f"tr_{start_node_name.lower()}_{end_node_name.lower()}"
            if transit.trigger_condition.condition_type == "NO_CHECK":
                transit_condition = (
                    PlanTemplateUtil.TRANSIT_CONDITION_NOCHECK.substitute()
                )
            else:
                condition_type = PlanReflectUtil.get_transit_condition_operator_type_by_condition_type(
                    condition_type=transit.trigger_condition.condition_type
                )

                if transit.trigger_condition.lhs_param.category == "PT_STATE":
                    pt_name = get_pt_name_by_node_name(
                        transit.trigger_condition.lhs_param.module_name
                    )
                    lhs_param = PlanTemplateUtil.TRANSIT_CONDITION_LHS_PT_STATE.substitute(
                        pt=transit.trigger_condition.lhs_param.module_name,
                        state=PlanReflectUtil.get_transit_condition_pt_state_by_pt_state(
                            pt_name=pt_name,
                            pt_state=transit.trigger_condition.lhs_param.name,
                        ),
                    )
                elif transit.trigger_condition.lhs_param.category == "PLAN_STATE":
                    lhs_param = PlanTemplateUtil.TRANSIT_CONDITION_LHS_PLAN_STATE.substitute(
                        state=PlanReflectUtil.get_transit_condition_plan_state_by_pt_state(
                            plan_state=transit.trigger_condition.lhs_param.name
                        )
                    )
                elif transit.trigger_condition.lhs_param.category == "SYS_STATE":
                    lhs_param = PlanTemplateUtil.TRANSIT_CONDITION_LHS_SYS_STATE.substitute(
                        state=PlanReflectUtil.get_transit_condition_sys_state_by_sys_state(
                            sys_state=transit.trigger_condition.lhs_param.name
                        )
                    )
                elif transit.trigger_condition.lhs_param.category == "PLAN_INPUT":
                    lhs_param = PlanTemplateUtil.TRANSIT_CONDITION_LHS_PLAN_INPUT.substitute(
                        input_param=PlanReflectUtil.get_transit_condition_plan_input_by_input_param(
                            input_param=transit.trigger_condition.lhs_param.name
                        )
                    )
                elif transit.trigger_condition.lhs_param.category == "GLOBAL_VAR":
                    lhs_param = (
                        PlanTemplateUtil.TRANSIT_CONDITION_LHS_GLOBAL_VAR.substitute(
                            global_var_name=transit.trigger_condition.lhs_param.name,
                            global_var_type=PlanReflectUtil.get_variable_type_by_type(
                                type_name=transit.trigger_condition.lhs_param.type
                            ),
                        )
                    )
                elif transit.trigger_condition.lhs_param.category == "DEVICE_STATE":
                    lhs_param = PlanTemplateUtil.TRANSIT_CONDITION_LHS_DEVICE_STATE.substitute(
                        device_state_class=PlanReflectUtil.get_device_state_class_by_device_name(
                            device_name=transit.trigger_condition.lhs_param.module_name
                        ),
                        state=PlanReflectUtil.get_device_state_by_state_name(
                            device_name=transit.trigger_condition.lhs_param.module_name,
                            state_name=transit.trigger_condition.lhs_param.name,
                        ),
                    )
                else:
                    raise Exception("Unknown trigger condition category")

                if transit.trigger_condition.rhs_param.type == "BOOL":
                    rhs_param = PlanTemplateUtil.TRANSIT_CONDITION_RHS_BOOL.substitute(
                        value=bool(transit.trigger_condition.rhs_param.data[0])
                    )
                elif transit.trigger_condition.rhs_param.type == "INT":
                    rhs_param = PlanTemplateUtil.TRANSIT_CONDITION_RHS_INT.substitute(
                        value=transit.trigger_condition.rhs_param.data[0]
                    )
                elif transit.trigger_condition.rhs_param.type == "TYPE":
                    rhs_param = PlanTemplateUtil.TRANSIT_CONDITION_RHS_TYPE.substitute(
                        value=PlanReflectUtil.get_device_state_value_by_state_value(
                            state_value=transit.trigger_condition.rhs_param.data[0]
                        )
                    )
                elif transit.trigger_condition.rhs_param.type == "DOUBLE":
                    rhs_param = (
                        PlanTemplateUtil.TRANSIT_CONDITION_RHS_DOUBLE.substitute(
                            value=transit.trigger_condition.rhs_param.data[0]
                        )
                    )
                elif transit.trigger_condition.rhs_param.type == "VEC_2i":
                    rhs_param = PlanTemplateUtil.TRANSIT_CONDITION_RHS_VEC2I.substitute(
                        i1=transit.trigger_condition.rhs_param.data[0],
                        i2=transit.trigger_condition.rhs_param.data[1],
                    )
                elif transit.trigger_condition.rhs_param.type == "VEC_3i":
                    rhs_param = PlanTemplateUtil.TRANSIT_CONDITION_RHS_VEC3I.substitute(
                        i1=transit.trigger_condition.rhs_param.data[0],
                        i2=transit.trigger_condition.rhs_param.data[1],
                        i3=transit.trigger_condition.rhs_param.data[2],
                    )
                elif transit.trigger_condition.rhs_param.type == "VEC_6i":
                    rhs_param = PlanTemplateUtil.TRANSIT_CONDITION_RHS_VEC6I.substitute(
                        i1=transit.trigger_condition.rhs_param.data[0],
                        i2=transit.trigger_condition.rhs_param.data[1],
                        i3=transit.trigger_condition.rhs_param.data[2],
                        i4=transit.trigger_condition.rhs_param.data[3],
                        i5=transit.trigger_condition.rhs_param.data[4],
                        i6=transit.trigger_condition.rhs_param.data[5],
                    )
                elif transit.trigger_condition.rhs_param.type == "VEC_2d":
                    rhs_param = PlanTemplateUtil.TRANSIT_CONDITION_RHS_VEC2D.substitute(
                        d1=transit.trigger_condition.rhs_param.data[0],
                        d2=transit.trigger_condition.rhs_param.data[1],
                    )
                elif transit.trigger_condition.rhs_param.type == "VEC_3d":
                    rhs_param = PlanTemplateUtil.TRANSIT_CONDITION_RHS_VEC3D.substitute(
                        d1=transit.trigger_condition.rhs_param.data[0],
                        d2=transit.trigger_condition.rhs_param.data[1],
                        d3=transit.trigger_condition.rhs_param.data[2],
                    )
                elif transit.trigger_condition.rhs_param.type == "VEC_6d":
                    rhs_param = PlanTemplateUtil.TRANSIT_CONDITION_RHS_VEC6D.substitute(
                        d1=transit.trigger_condition.rhs_param.data[0],
                        d2=transit.trigger_condition.rhs_param.data[1],
                        d3=transit.trigger_condition.rhs_param.data[2],
                        d4=transit.trigger_condition.rhs_param.data[3],
                        d5=transit.trigger_condition.rhs_param.data[4],
                        d6=transit.trigger_condition.rhs_param.data[5],
                    )
                elif transit.trigger_condition.rhs_param.type == "VEC_7d":
                    rhs_param = PlanTemplateUtil.TRANSIT_CONDITION_RHS_VEC7D.substitute(
                        d1=transit.trigger_condition.rhs_param.data[0],
                        d2=transit.trigger_condition.rhs_param.data[1],
                        d3=transit.trigger_condition.rhs_param.data[2],
                        d4=transit.trigger_condition.rhs_param.data[3],
                        d5=transit.trigger_condition.rhs_param.data[4],
                        d6=transit.trigger_condition.rhs_param.data[5],
                        d7=transit.trigger_condition.rhs_param.data[6],
                    )
                else:
                    raise Exception(
                        f"Unknown trigger condition type {transit.trigger_condition.rhs_param.type}"
                    )

                transit_condition = PlanTemplateUtil.TRANSIT_CONDITION.substitute(
                    condition_type=condition_type,
                    lhs_param=lhs_param,
                    rhs_param=rhs_param,
                )
            code_strs.append(
                PlanTemplateUtil.TRANSIT.substitute(
                    transit_func=transit_func_name, transit_condition=transit_condition
                )
            )
            code_strs.append("\n")

        # add main
        code_strs.append("if __name__ == '__main__':")

        plan_description = plan_obj.plan_desc
        plan_logger_enabled = plan_obj.plan_log.enable_log
        plan_logger_interval = plan_obj.plan_log.time_interval
        plan_version = str(SoftwareVersionEnum(plan_obj.sw_ver)).split(".")[-1]
        code_strs.append(
            PlanTemplateUtil.PLAN.substitute(
                plan_obj=plan_name,
                plan_name=plan_name,
                plan_version=plan_version,
                plan_description=plan_description,
                plan_logger_enabled=plan_logger_enabled,
                plan_logger_interval=plan_logger_interval,
            )
        )
        code_strs.append("\n")

        # add primitive
        for primitive in plan_obj.node_list:
            # primitive's node_name == lhs_param.module_name
            node_name = primitive.node_name
            code_strs.append("    # add primitive {}".format(node_name))
            primitive_class = PlanReflectUtil.get_primitive_class_by_pt_name(
                primitive.pt_name
            )
            primitive_tool = primitive.switch_tcp_param.tool_name
            # define primitive
            code_strs.append(
                PlanTemplateUtil.PRIMITIVE.substitute(
                    plan_obj=plan_name,
                    primitive_obj=node_name,
                    primitive_name=node_name,
                    primitive_tool=primitive_tool,
                    primitive_class=primitive_class,
                )
            )
            # add primitive to plan
            code_strs.append(
                PlanTemplateUtil.PLAN_PRIMITIVE.substitute(
                    plan_obj=plan_name,
                    primitive_obj=node_name,
                )
            )

            # add parameter
            for parameter in primitive.param_assignment:
                param_name = (
                    PlanReflectUtil.get_primitive_parameter_class_by_param_name(
                        module_name="elements.common.enums",
                        primitive_name="PrimitiveEnum" + "." + primitive_class,
                        param_name=parameter.lhs_param.name,
                    )
                )
                param_value_class = (
                    PlanReflectUtil.get_primitive_parameter_value_class_by_param_type(
                        module_name="elements.core.contrib.parameter_values",
                        param_type=parameter.lhs_param.type,
                    )
                )
                param_value_str = ""
                if parameter.rhs_param.type == "COORD":
                    param_value_str = (
                        ", ".join(parameter.rhs_param.data[:6])
                        + ", '"
                        + parameter.rhs_param.data[6]
                        + ":"
                        + parameter.rhs_param.data[7]
                        + "', "
                        + ", ".join(parameter.rhs_param.data[8:])
                    )
                elif parameter.rhs_param.type == "JPOS":
                    param_value_str = ", ".join(parameter.rhs_param.data)
                elif parameter.rhs_param.type in ["INT", "DOUBLE"]:
                    param_value_str = parameter.rhs_param.data[0]
                else:
                    raise Exception(
                        f"Unknown parameter type {parameter.rhs_param.type}"
                    )
                # add parameter to primitive
                code_strs.append(
                    PlanTemplateUtil.PRIMITIVE_INPUT_PARAMETER.substitute(
                        primitive_obj=node_name,
                        param_name=param_name,
                        param_value_class=param_value_class,
                        param_value=param_value_str,
                    )
                )

            code_strs.append("\n")

        # add transit to plan
        for transit in plan_obj.transit_list:
            if transit.start_node_name == "startNode":
                start_node = plan_name + ".start_node"
                start_node_name = "start"
            else:
                start_node = transit.start_node_name
                start_node_name = transit.start_node_name
            end_node = transit.end_node_name
            end_node_name = transit.end_node_name
            transit_func_name = f"tr_{start_node_name.lower()}_{end_node_name.lower()}"
            code_strs.append(f"    # add transit {transit_func_name}")
            code_strs.append(
                PlanTemplateUtil.PLAN_TRANSIT.substitute(
                    plan_obj=plan_name,
                    transit_func=transit_func_name,
                    start_node=start_node,
                    end_node=end_node,
                )
            )

        # write code to file
        with open(plan_name + ".py", "w") as f:
            f.write("\n".join(code_strs))

    @staticmethod
    def format_code(file_name: str):
        import black

        with open(file_name, "r", encoding="utf-8") as f:
            code = f.read()
        formatted_code = black.format_str(code, mode=black.FileMode())

        with open(file_name, "w", encoding="utf-8") as f:
            f.write(formatted_code)


if __name__ == "__main__":
    file_name = "debug/p2_plan_state"
    # file_name = "debug/p2_device_state"
    # file_name = "debug/p2_pt_state"
    # file_name = "debug/p2_sys_state"
    PlanUtil.to_code(file_name + ".plan")
    PlanUtil.format_code(file_name + ".py")
