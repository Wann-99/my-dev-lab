from string import Template


class PlanTemplateUtil:
    # plan
    PLAN = Template(
        "    $plan_obj = Plan(name='$plan_name')\n"
        "    $plan_obj.description = '$plan_description'\n"
        "    $plan_obj.sw_ver = '$plan_version'\n"
        "    $plan_obj.plan_logger_enabled = $plan_logger_enabled\n"
        "    $plan_obj.plan_logger_interval = $plan_logger_interval"
    )

    # primitive
    PRIMITIVE = Template(
        "    $primitive_obj = $primitive_class(name='$primitive_name')\n"
        "    $primitive_obj.set_tool('$primitive_tool')"
    )

    # plan / primitive
    PLAN_PRIMITIVE = Template("    $plan_obj.add_primitive($primitive_obj)")

    # primitive / parameter
    PRIMITIVE_INPUT_PARAMETER = Template(
        "    $primitive_obj.add_parameter(\n"
        "        param=$param_name,\n"
        "        param_value=$param_value_class($param_value)\n"
        "    )"
    )

    # transit
    TRANSIT = Template(
        "@TRANSIT\n"
        "def $transit_func(start, end) -> Transit:\n"
        "    transit = Transit(start=start, end=end)\n"
        "    $transit_condition\n"
        "    return transit"
    )

    # transit / condition
    TRANSIT_CONDITION = Template(
        "transit.add_condition(\n"
        "        condition_type=$condition_type,\n"
        "        lhs_param=$lhs_param,\n"
        "        rhs_param=$rhs_param)"
    )

    # transit / condition(no check)
    TRANSIT_CONDITION_NOCHECK = Template(
        "transit.add_condition(TransitConditionOperatorEnum.NO_CHECK)"
    )

    # transit / condition / lhs
    TRANSIT_CONDITION_LHS_PT_STATE = Template("ParameterPtState(pt=$pt, state=$state)")
    TRANSIT_CONDITION_LHS_PLAN_STATE = Template("ParameterPlanState(state=$state)")
    TRANSIT_CONDITION_LHS_PLAN_INPUT = Template(
        "ParameterPlanInput(param=$input_param)"
    )
    TRANSIT_CONDITION_LHS_SYS_STATE = Template("ParameterSystemState(state=$state)")
    TRANSIT_CONDITION_LHS_GLOBAL_VAR = Template(
        "ParameterGlobalVariable(global_var_name=global_var_name， global_var_type=$global_var_type)"
    )
    TRANSIT_CONDITION_LHS_DEVICE_STATE = Template("$device_state_class(state=$state)")

    # transit / condition / rhs
    TRANSIT_CONDITION_RHS_BOOL = Template("ParameterValueConstBool(value=$value)")
    TRANSIT_CONDITION_RHS_INT = Template("ParameterValueConstInt(value=$value)")
    TRANSIT_CONDITION_RHS_DOUBLE = Template("ParameterValueConstDouble(value=$value)")
    TRANSIT_CONDITION_RHS_TYPE = Template("ParameterValueConstType(value=$value)")
    TRANSIT_CONDITION_RHS_VEC2D = Template("ParameterValueConstVEC2D(d1=$d1, d2=$d2)")
    TRANSIT_CONDITION_RHS_VEC3D = Template(
        "ParameterValueConstVEC3D(d1=$d1, d2=$d2, d3=$d3)"
    )
    TRANSIT_CONDITION_RHS_VEC6D = Template(
        "ParameterValueConstVEC6D(d1=$d1, d2=$d2, d3=$d3, d4=$d4, d5=$d5, d6=$d6)"
    )
    TRANSIT_CONDITION_RHS_VEC7D = Template(
        "ParameterValueConstVEC7D(d1=$d1, d2=$d2, d3=$d3, d4=$d4, d5=$d5, d6=$d6, d7=$d7)"
    )
    TRANSIT_CONDITION_RHS_VEC2I = Template("ParameterValueConstVEC2I(i1=$i1, i2=$i2)")
    TRANSIT_CONDITION_RHS_VEC3I = Template(
        "ParameterValueConstVEC3I(i1=$i1, i2=$i2, i3=$i3)"
    )
    TRANSIT_CONDITION_RHS_VEC6I = Template(
        "ParameterValueConstVEC6I(i1=$i1, i2=$i2, i3=$i3, i4=$i4, i5=$i5, i6=$i6)"
    )

    # plan / transit
    PLAN_TRANSIT = Template(
        "    $plan_obj.add_transit($transit_func(start=$start_node, end=$end_node))"
    )
