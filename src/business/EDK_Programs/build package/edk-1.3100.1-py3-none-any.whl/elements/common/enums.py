from enum import Enum, IntEnum

from elements.proto.ProtoPlanParams_pb2 import ProtoPlanParams


class ParameterValueTypeEnum(Enum):
    BOOL = "BOOL"
    INT = "INT"
    TYPE = "TYPE"
    DOUBLE = "DOUBLE"
    STRING = "STRING"
    COORD = "COORD"
    JPOS = "JPOS"
    POSE = "POSE"
    FILE = "FILE"
    OBJNAME = "OBJNAME"
    MSG = "MSG"
    VEC_2D = "VEC_2d"
    VEC_3D = "VEC_3d"
    VEC_4D = "VEC_4d"
    VEC_6D = "VEC_6d"
    VEC_7D = "VEC_7d"
    VEC_2I = "VEC_2i"
    VEC_3I = "VEC_3i"
    VEC_6I = "VEC_6i"
    ARRAY_DOUBLE = "ARRAY_DOUBLE"
    ARRAY_VEC_2D = "ARRAY_VEC_2d"
    ARRAY_VEC_6D = "ARRAY_VEC_6d"
    ARRAY_JPOS = "ARRAY_JPOS"
    ARRAY_COORD = "ARRAY_COORD"
    ARRAY_TYPE = "ARRAY_TYPE"


class ParameterCategoryEnum(Enum):
    PT_INPUT = "PT_INPUT"
    PT_OUTPUT = "PT_OUTPUT"
    PT_STATE = "PT_STATE"
    DEVICE_STATE = "DEVICE_STATE"
    AI_STATE = "AI_STATE"
    PLAN_INPUT = "PLAN_INPUT"
    PLAN_OUTPUT = "PLAN_OUTPUT"
    PLAN_STATE = "PLAN_STATE"
    SYS_STATE = "SYS_STATE"
    GPIO_STATE = "GPIO_STATE"
    PLAN_VAR = "PLAN_VAR"
    PROJ_VAR = "PROJ_VAR"
    GLOBAL_VAR = "GLOBAL_VAR"
    CONST = "CONST"


class TransitConditionOperatorEnum(Enum):
    NO_CHECK = {"type": "NO_CHECK", "value": "NO_CHECK"}
    OR = {"type": "OR", "value": "||"}
    AND = {"type": "AND", "value": "&&"}
    EQUAL = {"type": "EQUAL", "value": "=="}
    NOTEQUAL = {"type": "NOTEQUAL", "value": "!="}
    GREATER = {"type": "GREATER", "value": ">"}
    GREATER_EQUAL = {"type": "GREATER_EQUAL", "value": ">="}
    LESS = {"type": "LESS", "value": "<"}
    LESS_EQUAL = {"type": "LESS_EQUAL", "value": "<="}


class TransitOperationOperatorEnum(Enum):
    ADD = {"type": "ADDITION", "value": "+"}
    SUB = {"type": "SUBTRACTION", "value": "-"}
    MUL = {"type": "MULTIPLICATION", "value": "*"}
    DIV = {"type": "DIVISION", "value": "/"}
    MOD = {"type": "MODULO", "value": "%"}

    ABS = {"type": "ABSOLUTE_VALUE", "value": "abs"}
    SIN = {"type": "SIN", "value": "sin"}
    COS = {"type": "COS", "value": "cos"}
    TAN = {"type": "TAN", "value": "tan"}
    ARCSIN = {"type": "ARCSIN", "value": "arcsin"}
    ARCCOS = {"type": "ARCCOS", "value": "arccos"}
    ARCTAN = {"type": "ARCTAN", "value": "arctan"}

    ELEMENT_GET = {"type": "ELEMENT_GET", "value": "ELEMENT_GET"}
    ELEMENT_SET = {"type": "ELEMENT_SET", "value": "ELEMENT_SET"}
    ELEMENT_ADD = {"type": "ELEMENT_ADD", "value": "push_back"}
    ELEMENT_INSERT = {"type": "ELEMENT_INSERT", "value": "ELEMENT_INSERT"}
    ELEMENT_REMOVE = {"type": "ELEMENT_REMOVE", "value": "remove"}
    ELEMENT_CLEAR = {"type": "ELEMENT_CLEAR", "value": "clear"}

    POS_DISTANCE = {"type": "POS_DISTANCE", "value": "pos_distance"}
    QUAT_DISTANCE = {"type": "QUAT_DISTANCE", "value": "quat_distance"}
    INVERSE = {"type": "INVERSE", "value": "inverse"}
    TRANS_OFF = {"type": "TRANS_OFFSET", "value": "TRANS_OFFSET"}
    SET_ORIENTATION = {"type": "SET_ORIENTATION", "value": "setOrientation"}

    SET_JNT_POS = {"type": "SET_JNT_POS", "value": "setJntPos"}
    GET_JNT_POS = {"type": "GET_JNT_POS", "value": "getJntPos"}
    SET_EXT_JNT_POS = {"type": "SET_EXT_JNT_POS", "value": "setExtJntPos"}
    GET_EXT_JNT_POS = {"type": "GET_EXT_JNT_POS", "value": "getExtJntPos"}
    SET_JPOS = {"type": "SET_JPOS", "value": "setJPos"}
    GET_JPOS = {"type": "GET_JPOS", "value": "getJPos"}

    QUERY_OBJ_VALID = {"type": "QUERY_OBJ_VALID", "value": "GetObjectValid"}
    QUERY_OBJ_KEYPOINTS = {"type": "QUERY_OBJ_KEYPOINTS", "value": "GetObjectKeyPoints"}
    QUERY_OBJ_KEYPOINTS_POS = {
        "type": "QUERY_OBJ_KEYPOINTS_POS",
        "value": "GetObjectKeyPointsPos",
    }
    QUERY_OBJ_COORD = {"type": "QUERY_OBJ_COORD", "value": "GetObjectCoordinate"}
    QUERY_OBJ_DATA_DOUBLE = {
        "type": "QUERY_OBJ_DATA_DOUBLE",
        "value": "GetObjectCustomData",
    }
    QUERY_OBJ_DATA_INT = {"type": "QUERY_OBJ_DATA_INT", "value": "GetObjectCustomData"}
    QUERY_OBJ_DATA_STRING = {
        "type": "QUERY_OBJ_DATA_STRING",
        "value": "GetObjectCustomData",
    }

    TYPE_CONVERT = {"type": "TYPECONVERT", "value": "typeConvert"}
    SET_TOOL_TCP = {"type": "SET_TOOL_TCP", "value": "setToolTcp"}
    GET_TOOL_TCP = {"type": "GET_TOOL_TCP", "value": "getToolTcp"}
    SET_WORK_COORD = {"type": "SET_WORK_COORD", "value": "setWorkCoord"}
    GET_WORK_COORD = {"type": "GET_WORK_COORD", "value": "getWorkCoord"}


class DeviceStateEnum:
    class ConveyorStatusEnum(Enum):
        type = ""

        CurrentPosition = {"name": "currentPosition", "type": "DOUBLE", "unit": "m"}
        CurrentVelocity = {"name": "currentVelocity", "type": "DOUBLE", "unit": "m/s"}
        CurrentState = {"name": "currentState", "type": "TYPE", "unit": "none"}

    class GripperDahuanStateEnum(Enum):
        type = "GripperDahuan"

        State = {"name": "state", "type": "TYPE", "unit": "none"}
        Width = {"name": "width", "type": "DOUBLE", "unit": "m"}
        ReachedForce = {"name": "reachedForce", "type": "BOOL", "unit": "none"}
        ReachedWidth = {"name": "reachedWidth", "type": "BOOL", "unit": "none"}
        Moving = {"name": "moving", "type": "BOOL", "unit": "none"}
        DesiredWidth = {"name": "desiredWidth", "type": "DOUBLE", "unit": "m"}
        Current = {"name": "current", "type": "DOUBLE", "unit": "A"}
        Force = {"name": "force", "type": "DOUBLE", "unit": "N"}

    class GripperDahuanModbusStateEnum(Enum):
        type = "GripperDahuanModbus"

        State = {"name": "state", "type": "TYPE", "unit": "none"}
        Width = {"name": "width", "type": "DOUBLE", "unit": "m"}
        ReachedForce = {"name": "reachedForce", "type": "BOOL", "unit": "none"}
        ReachedWidth = {"name": "reachedWidth", "type": "BOOL", "unit": "none"}
        Moving = {"name": "moving", "type": "BOOL", "unit": "none"}
        ClampState = {"name": "clampState", "type": "INT", "unit": "none"}

    class FlexivGN01StateEnum(Enum):
        type = "Flexiv-GN01"

        State = {"name": "state", "type": "TYPE", "unit": "none"}
        Width = {"name": "width", "type": "DOUBLE", "unit": "m"}
        Force = {"name": "force", "type": "DOUBLE", "unit": "N"}
        ReachedForce = {"name": "reachedForce", "type": "BOOL", "unit": "none"}
        ReachedWidth = {"name": "reachedWidth", "type": "BOOL", "unit": "none"}
        Moving = {"name": "moving", "type": "BOOL", "unit": "none"}
        RecaliDone = {"name": "reCaliDone", "type": "BOOL", "unit": "none"}
        FaultWord = {"name": "faultWord", "type": "INT", "unit": "none"}

    class GripperFlexivModbusStateEnum(Enum):
        type = "GripperFlexivModbus"

        State = {"name": "state", "type": "TYPE", "unit": "none"}
        Width = {"name": "width", "type": "DOUBLE", "unit": "m"}
        Force = {"name": "force", "type": "DOUBLE", "unit": "N"}
        ReachedForce = {"name": "reachedForce", "type": "BOOL", "unit": "none"}
        ReachedWidth = {"name": "reachedWidth", "type": "BOOL", "unit": "none"}
        Moving = {"name": "moving", "type": "BOOL", "unit": "none"}
        RecaliDone = {"name": "reCaliDone", "type": "BOOL", "unit": "none"}
        FaultWord = {"name": "faultWord", "type": "INT", "unit": "none"}

    class Robotiq2F85StateEnum(Enum):
        type = "Robotiq-2F-85"

        State = {"name": "state", "type": "TYPE", "unit": "none"}
        Width = {"name": "width", "type": "DOUBLE", "unit": "m"}
        ReachedForce = {"name": "reachedForce", "type": "BOOL", "unit": "none"}
        ReachedWidth = {"name": "reachedWidth", "type": "BOOL", "unit": "none"}
        Moving = {"name": "moving", "type": "BOOL", "unit": "none"}
        DesiredWidth = {"name": "desiredWidth", "type": "DOUBLE", "unit": "m"}
        Current = {"name": "current", "type": "DOUBLE", "unit": "A"}

    class RobotiqHandEStateEnum(Enum):
        type = "Robotiq-Hand-E"

        State = {"name": "state", "type": "TYPE", "unit": "none"}
        Width = {"name": "width", "type": "DOUBLE", "unit": "m"}
        ReachedForce = {"name": "reachedForce", "type": "BOOL", "unit": "none"}
        ReachedWidth = {"name": "reachedWidth", "type": "BOOL", "unit": "none"}
        Moving = {"name": "moving", "type": "BOOL", "unit": "none"}
        DesiredWidth = {"name": "desiredWidth", "type": "DOUBLE", "unit": "m"}
        Current = {"name": "current", "type": "DOUBLE", "unit": "A"}

    class IndustrialCamStateEnum(Enum):
        type = "IndustrialCam"

        ConnectionStateParam = {
            "name": "connectionState",
            "type": "TYPE",
            "unit": "none",
        }
        Index = {"name": "index", "type": "INT", "unit": "none"}
        DetectStateParam = {"name": "detectState", "type": "TYPE", "unit": "none"}
        DataX = {"name": "data_x", "type": "DOUBLE", "unit": "m"}
        DataY = {"name": "data_y", "type": "DOUBLE", "unit": "m"}
        DataZ = {"name": "data_z", "type": "DOUBLE", "unit": "m"}
        DataRx = {"name": "data_rx", "type": "DOUBLE", "unit": "deg"}
        DataRy = {"name": "data_ry", "type": "DOUBLE", "unit": "deg"}
        DataRz = {"name": "data_rz", "type": "DOUBLE", "unit": "deg"}
        EccType = {"name": "eccType", "type": "INT", "unit": "none"}

    class MirkaAIROS550CVStateEnum(Enum):
        type = "Mirka-AIROS-550CV"

        SpeedOverCount = {"name": "speedOverCount", "type": "INT", "unit": "none"}
        ToolOverWarmCount = {"name": "toolOverWarmCount", "type": "INT", "unit": "none"}
        DriverOverWarmCount = {
            "name": "driverOverWarmCount",
            "type": "INT",
            "unit": "none",
        }
        ToolOverHeatCount = {"name": "toolOverHeatCount", "type": "INT", "unit": "none"}
        DriverOverheatCount = {
            "name": "driverOverheatCount",
            "type": "INT",
            "unit": "none",
        }
        ToolOverHeatStopCount = {
            "name": "toolOverHeatStopCount",
            "type": "INT",
            "unit": "none",
        }
        DriverOverheatStopCount = {
            "name": "driverOverheatStopCount",
            "type": "INT",
            "unit": "none",
        }
        PowerVoltageUnLimitedCount = {
            "name": "powerVoltageUnLimitedCount",
            "type": "INT",
            "unit": "none",
        }
        CurrentOverLittleCount = {
            "name": "currentOverLittleCount",
            "type": "INT",
            "unit": "none",
        }
        CurrentOverLargeCount = {
            "name": "currentOverLargeCount",
            "type": "INT",
            "unit": "none",
        }
        RunTimeLongCount = {"name": "runTimeLongCount", "type": "INT", "unit": "none"}
        RunTimeMiddleCount = {
            "name": "runTimeMiddleCount",
            "type": "INT",
            "unit": "none",
        }
        RunTimeShortCount = {"name": "runTimeShortCount", "type": "INT", "unit": "none"}
        RunTimeHourCount = {"name": "runTimeHourCount", "type": "INT", "unit": "none"}
        RunTimeMinuteCount = {
            "name": "runTimeMinuteCount",
            "type": "INT",
            "unit": "none",
        }
        RunTimeSecondCount = {
            "name": "runTimeSecondCount",
            "type": "INT",
            "unit": "none",
        }
        AverageCurrent = {"name": "averageCurrent", "type": "INT", "unit": "mA"}
        AverageSpeed = {"name": "averageSpeed", "type": "INT", "unit": "rpm"}
        ToolTemperature = {"name": "toolTemperature", "type": "INT", "unit": "℃"}
        MotorDriverTemperature = {
            "name": "motorDriverTemperature",
            "type": "INT",
            "unit": "℃",
        }
        WarningSignal = {"name": "warningSignal", "type": "INT", "unit": "none"}


class AIStateEnum(Enum):
    AI_STATE = {"name": "aiState", "type": "TYPE"}
    AI_STATUS_CODE = {"name": "aiStatusCode", "type": "TYPE"}
    REV_SNAPSHOT_INDEX = {"name": "revSnapshotIndex", "type": "INT"}
    OBJECT_CATEGORY_NUM_IN_MAP = {"name": "objectCategoryNumInMap", "type": "INT"}
    OBJECT_NUM_IN_MAP = {"name": "objectNumInMap", "type": "INT"}
    OBJECT_NAME_LIST = {"name": "objectNameList", "type": "ARRAY_STRING"}


class SystemStateEnum(Enum):
    TCP_POSE = {"name": "tcpPose", "type": "COORD", "unit": "m-deg"}
    TCP_TRANS_VEL_X = {"name": "tcpTransVelX", "type": "DOUBLE", "unit": "m/s"}
    TCP_TRANS_VEL_Y = {"name": "tcpTransVelY", "type": "DOUBLE", "unit": "m/s"}
    TCP_TRANS_VEL_Z = {"name": "tcpTransVelZ", "type": "DOUBLE", "unit": "m/s"}
    TCP_ANG_VEL_X = {"name": "tcpAngVelX", "type": "DOUBLE", "unit": "deg/s"}
    TCP_ANG_VEL_Y = {"name": "tcpAngVelY", "type": "DOUBLE", "unit": "deg/s"}
    TCP_ANG_VEL_Z = {"name": "tcpAngVelZ", "type": "DOUBLE", "unit": "deg/s"}
    TCP_TRANS_VEL_NORM = {"name": "tcpTransVelNorm", "type": "DOUBLE", "unit": "m/s"}
    TCP_ANG_VEL_NORM = {"name": "tcpAngVelNorm", "type": "DOUBLE", "unit": "deg/s"}
    CARTESIAN_POS_X = {"name": "CartesianPosX", "type": "DOUBLE", "unit": "m"}
    CARTESIAN_POS_Y = {"name": "CartesianPosY", "type": "DOUBLE", "unit": "m"}
    CARTESIAN_POS_Z = {"name": "CartesianPosZ", "type": "DOUBLE", "unit": "m"}
    EULER_ANGLE_RX = {"name": "EulerAngleRx", "type": "DOUBLE", "unit": "deg"}
    EULER_ANGLE_RY = {"name": "EulerAngleRy", "type": "DOUBLE", "unit": "deg"}
    EULER_ANGLE_RZ = {"name": "EulerAngleRz", "type": "DOUBLE", "unit": "deg"}
    CARTESIAN_FORCE_X = {"name": "CartesianForceX", "type": "DOUBLE", "unit": "N"}
    CARTESIAN_FORCE_Y = {"name": "CartesianForceY", "type": "DOUBLE", "unit": "N"}
    CARTESIAN_FORCE_Z = {"name": "CartesianForceZ", "type": "DOUBLE", "unit": "N"}
    CARTESIAN_MOMENT_X = {"name": "CartesianMomentX", "type": "DOUBLE", "unit": "Nm"}
    CARTESIAN_MOMENT_Y = {"name": "CartesianMomentY", "type": "DOUBLE", "unit": "Nm"}
    CARTESIAN_MOMENT_Z = {"name": "CartesianMomentZ", "type": "DOUBLE", "unit": "Nm"}
    CARTESIAN_FORCE = {"name": "CartesianForce", "type": "DOUBLE", "unit": "N"}
    CARTESIAN_MOMENT = {"name": "CartesianMoment", "type": "DOUBLE", "unit": "Nm"}
    TOTAL_EXT_JOINT_TORQUE = {
        "name": "totalExtJointTorque",
        "type": "DOUBLE",
        "unit": "Nm",
    }
    COLLISION_FLAG = {"name": "collisionFlag", "type": "BOOL", "unit": "none"}
    JPOS = {"name": "jPos", "type": "JPOS", "unit": "deg"}
    AXIS_POS_1 = {"name": "axisPos1", "type": "DOUBLE", "unit": "deg"}
    AXIS_POS_2 = {"name": "axisPos2", "type": "DOUBLE", "unit": "deg"}
    AXIS_POS_3 = {"name": "axisPos3", "type": "DOUBLE", "unit": "deg"}
    AXIS_POS_4 = {"name": "axisPos4", "type": "DOUBLE", "unit": "deg"}
    AXIS_POS_5 = {"name": "axisPos5", "type": "DOUBLE", "unit": "deg"}
    AXIS_POS_6 = {"name": "axisPos6", "type": "DOUBLE", "unit": "deg"}
    AXIS_POS_7 = {"name": "axisPos7", "type": "DOUBLE", "unit": "deg"}
    AXIS_VEL_1 = {"name": "axisVel1", "type": "DOUBLE", "unit": "deg/s"}
    AXIS_VEL_2 = {"name": "axisVel2", "type": "DOUBLE", "unit": "deg/s"}
    AXIS_VEL_3 = {"name": "axisVel3", "type": "DOUBLE", "unit": "deg/s"}
    AXIS_VEL_4 = {"name": "axisVel4", "type": "DOUBLE", "unit": "deg/s"}
    AXIS_VEL_5 = {"name": "axisVel5", "type": "DOUBLE", "unit": "deg/s"}
    AXIS_VEL_6 = {"name": "axisVel6", "type": "DOUBLE", "unit": "deg/s"}
    AXIS_VEL_7 = {"name": "axisVel7", "type": "DOUBLE", "unit": "deg/s"}
    AXIS_TORQUE_1 = {"name": "axisTorque1", "type": "DOUBLE", "unit": "Nm"}
    AXIS_TORQUE_2 = {"name": "axisTorque2", "type": "DOUBLE", "unit": "Nm"}
    AXIS_TORQUE_3 = {"name": "axisTorque3", "type": "DOUBLE", "unit": "Nm"}
    AXIS_TORQUE_4 = {"name": "axisTorque4", "type": "DOUBLE", "unit": "Nm"}
    AXIS_TORQUE_5 = {"name": "axisTorque5", "type": "DOUBLE", "unit": "Nm"}
    AXIS_TORQUE_6 = {"name": "axisTorque6", "type": "DOUBLE", "unit": "Nm"}
    AXIS_TORQUE_7 = {"name": "axisTorque7", "type": "DOUBLE", "unit": "Nm"}
    EXT_AXIS_POS_1 = {"name": "extAxisPos1", "type": "DOUBLE", "unit": "deg"}
    EXT_AXIS_POS_2 = {"name": "extAxisPos2", "type": "DOUBLE", "unit": "deg"}
    EXT_AXIS_POS_3 = {"name": "extAxisPos3", "type": "DOUBLE", "unit": "deg"}
    EXT_AXIS_POS_4 = {"name": "extAxisPos4", "type": "DOUBLE", "unit": "deg"}
    EXT_AXIS_POS_5 = {"name": "extAxisPos5", "type": "DOUBLE", "unit": "deg"}
    EXT_AXIS_POS_6 = {"name": "extAxisPos6", "type": "DOUBLE", "unit": "deg"}
    EXT_AXIS_VEL_1 = {"name": "extAxisVel1", "type": "DOUBLE", "unit": "deg/s"}
    EXT_AXIS_VEL_2 = {"name": "extAxisVel2", "type": "DOUBLE", "unit": "deg/s"}
    EXT_AXIS_VEL_3 = {"name": "extAxisVel3", "type": "DOUBLE", "unit": "deg/s"}
    EXT_AXIS_VEL_4 = {"name": "extAxisVel4", "type": "DOUBLE", "unit": "deg/s"}
    EXT_AXIS_VEL_5 = {"name": "extAxisVel5", "type": "DOUBLE", "unit": "deg/s"}
    EXT_AXIS_VEL_6 = {"name": "extAxisVel6", "type": "DOUBLE", "unit": "deg/s"}
    JOINT_POS = {"name": "jointPos", "type": "VEC_7d", "unit": "deg"}
    MOTION_BAR_ENABLE_PRESSED = {
        "name": "motionbarEnablePressed",
        "type": "BOOL",
        "unit": "none",
    }
    MOTION_BAR_ESTOP_PRESSED = {
        "name": "motionbarEstopPressed",
        "type": "BOOL",
        "unit": "none",
    }
    IS_CONFIRMED = {"name": "isConfirmed", "type": "BOOL", "unit": "none"}
    IS_SERVO_ON = {"name": "isServoOn", "type": "BOOL", "unit": "none"}
    OPERATION_MODE = {"name": "operationMode", "type": "TYPE", "unit": "none"}
    IS_FAULT = {"name": "isFault", "type": "BOOL", "unit": "none"}
    REMOTE_ACTIVE = {"name": "remoteActive", "type": "BOOL", "unit": "none"}
    UI_APP_CONNECTED = {"name": "uiAppConnected", "type": "BOOL", "unit": "none"}
    ROBOT_MODEL_MAJOR_VERSION = {
        "name": "robotModelMajorVersion",
        "type": "TYPE",
        "unit": "none",
    }
    ROBOT_MODEL_MINOR_VERSION = {
        "name": "robotModelMinorVersion",
        "type": "STRING",
        "unit": "none",
    }
    TCP_WRENCH_LPF_FC_TYPE = {
        "name": "tcpWrenchLpfFcType",
        "type": "TYPE",
        "unit": "none",
    }
    CURRENT_TOOL_NAME = {"name": "currentToolName", "type": "STRING", "unit": "none"}
    PROJECT_RUNNING = {"name": "projectRunning", "type": "BOOL", "unit": "none"}
    PROJECT_PAUSED = {"name": "projectPaused", "type": "BOOL", "unit": "none"}
    SPEED_RATIO = {"name": "speedRatio", "type": "INT", "unit": "none"}


class GPIOStateEnum:
    class GPIOSystem(Enum):
        GPIOIn0 = {"name": "gpioIn0", "type": "BOOL", "unit": "none"}
        GPIOIn1 = {"name": "gpioIn1", "type": "BOOL", "unit": "none"}
        GPIOIn2 = {"name": "gpioIn2", "type": "BOOL", "unit": "none"}
        GPIOIn3 = {"name": "gpioIn3", "type": "BOOL", "unit": "none"}
        GPIOIn4 = {"name": "gpioIn4", "type": "BOOL", "unit": "none"}
        GPIOIn5 = {"name": "gpioIn5", "type": "BOOL", "unit": "none"}
        GPIOIn6 = {"name": "gpioIn6", "type": "BOOL", "unit": "none"}
        GPIOIn7 = {"name": "gpioIn7", "type": "BOOL", "unit": "none"}
        GPIOIn8 = {"name": "gpioIn8", "type": "BOOL", "unit": "none"}
        GPIOIn9 = {"name": "gpioIn9", "type": "BOOL", "unit": "none"}
        GPIOIn10 = {"name": "gpioIn10", "type": "BOOL", "unit": "none"}
        GPIOIn11 = {"name": "gpioIn11", "type": "BOOL", "unit": "none"}
        GPIOIn12 = {"name": "gpioIn12", "type": "BOOL", "unit": "none"}
        GPIOIn13 = {"name": "gpioIn13", "type": "BOOL", "unit": "none"}
        GPIOIn14 = {"name": "gpioIn14", "type": "BOOL", "unit": "none"}
        GPIOIn15 = {"name": "gpioIn15", "type": "BOOL", "unit": "none"}
        GPIOIn16 = {"name": "gpioIn16", "type": "BOOL", "unit": "none"}
        GPIOIn17 = {"name": "gpioIn17", "type": "BOOL", "unit": "none"}

    class GPIOModbusTCPSlave(Enum):
        MTBitIn0 = {"name": "mTBitIn0", "type": "BOOL", "unit": "none"}
        MTBitIn1 = {"name": "mTBitIn1", "type": "BOOL", "unit": "none"}
        MTBitIn2 = {"name": "mTBitIn2", "type": "BOOL", "unit": "none"}
        MTBitIn3 = {"name": "mTBitIn3", "type": "BOOL", "unit": "none"}
        MTBitIn4 = {"name": "mTBitIn4", "type": "BOOL", "unit": "none"}
        MTBitIn5 = {"name": "mTBitIn5", "type": "BOOL", "unit": "none"}
        MTBitIn6 = {"name": "mTBitIn6", "type": "BOOL", "unit": "none"}
        MTBitIn7 = {"name": "mTBitIn7", "type": "BOOL", "unit": "none"}
        MTBitIn8 = {"name": "mTBitIn8", "type": "BOOL", "unit": "none"}
        MTBitIn9 = {"name": "mTBitIn9", "type": "BOOL", "unit": "none"}
        MTBitIn10 = {"name": "mTBitIn10", "type": "BOOL", "unit": "none"}
        MTBitIn11 = {"name": "mTBitIn11", "type": "BOOL", "unit": "none"}
        MTBitIn12 = {"name": "mTBitIn12", "type": "BOOL", "unit": "none"}
        MTBitIn13 = {"name": "mTBitIn13", "type": "BOOL", "unit": "none"}
        MTBitIn14 = {"name": "mTBitIn14", "type": "BOOL", "unit": "none"}
        MTBitIn15 = {"name": "mTBitIn15", "type": "BOOL", "unit": "none"}
        MTBitIn16 = {"name": "mTBitIn16", "type": "BOOL", "unit": "none"}
        MTBitIn17 = {"name": "mTBitIn17", "type": "BOOL", "unit": "none"}
        MTBitIn18 = {"name": "mTBitIn18", "type": "BOOL", "unit": "none"}
        MTBitIn19 = {"name": "mTBitIn19", "type": "BOOL", "unit": "none"}
        MTBitIn20 = {"name": "mTBitIn20", "type": "BOOL", "unit": "none"}
        MTBitIn21 = {"name": "mTBitIn21", "type": "BOOL", "unit": "none"}
        MTBitIn22 = {"name": "mTBitIn22", "type": "BOOL", "unit": "none"}
        MTBitIn23 = {"name": "mTBitIn23", "type": "BOOL", "unit": "none"}
        MTBitIn24 = {"name": "mTBitIn24", "type": "BOOL", "unit": "none"}
        MTBitIn25 = {"name": "mTBitIn25", "type": "BOOL", "unit": "none"}
        MTBitIn26 = {"name": "mTBitIn26", "type": "BOOL", "unit": "none"}
        MTBitIn27 = {"name": "mTBitIn27", "type": "BOOL", "unit": "none"}
        MTBitIn28 = {"name": "mTBitIn28", "type": "BOOL", "unit": "none"}
        MTBitIn29 = {"name": "mTBitIn29", "type": "BOOL", "unit": "none"}
        MTBitIn30 = {"name": "mTBitIn30", "type": "BOOL", "unit": "none"}
        MTBitIn31 = {"name": "mTBitIn31", "type": "BOOL", "unit": "none"}
        MTBitIn32 = {"name": "mTBitIn32", "type": "BOOL", "unit": "none"}
        MTBitIn33 = {"name": "mTBitIn33", "type": "BOOL", "unit": "none"}
        MTBitIn34 = {"name": "mTBitIn34", "type": "BOOL", "unit": "none"}
        MTBitIn35 = {"name": "mTBitIn35", "type": "BOOL", "unit": "none"}
        MTBitIn36 = {"name": "mTBitIn36", "type": "BOOL", "unit": "none"}
        MTBitIn37 = {"name": "mTBitIn37", "type": "BOOL", "unit": "none"}
        MTBitIn38 = {"name": "mTBitIn38", "type": "BOOL", "unit": "none"}
        MTBitIn39 = {"name": "mTBitIn39", "type": "BOOL", "unit": "none"}
        MTBitIn40 = {"name": "mTBitIn40", "type": "BOOL", "unit": "none"}
        MTBitIn41 = {"name": "mTBitIn41", "type": "BOOL", "unit": "none"}
        MTBitIn42 = {"name": "mTBitIn42", "type": "BOOL", "unit": "none"}
        MTBitIn43 = {"name": "mTBitIn43", "type": "BOOL", "unit": "none"}
        MTBitIn44 = {"name": "mTBitIn44", "type": "BOOL", "unit": "none"}
        MTBitIn45 = {"name": "mTBitIn45", "type": "BOOL", "unit": "none"}
        MTBitIn46 = {"name": "mTBitIn46", "type": "BOOL", "unit": "none"}
        MTBitIn47 = {"name": "mTBitIn47", "type": "BOOL", "unit": "none"}
        MTBitIn48 = {"name": "mTBitIn48", "type": "BOOL", "unit": "none"}
        MTBitIn49 = {"name": "mTBitIn49", "type": "BOOL", "unit": "none"}
        MTBitIn50 = {"name": "mTBitIn50", "type": "BOOL", "unit": "none"}
        MTBitIn51 = {"name": "mTBitIn51", "type": "BOOL", "unit": "none"}
        MTBitIn52 = {"name": "mTBitIn52", "type": "BOOL", "unit": "none"}
        MTBitIn53 = {"name": "mTBitIn53", "type": "BOOL", "unit": "none"}
        MTBitIn54 = {"name": "mTBitIn54", "type": "BOOL", "unit": "none"}
        MTBitIn55 = {"name": "mTBitIn55", "type": "BOOL", "unit": "none"}
        MTBitIn56 = {"name": "mTBitIn56", "type": "BOOL", "unit": "none"}
        MTBitIn57 = {"name": "mTBitIn57", "type": "BOOL", "unit": "none"}
        MTBitIn58 = {"name": "mTBitIn58", "type": "BOOL", "unit": "none"}
        MTBitIn59 = {"name": "mTBitIn59", "type": "BOOL", "unit": "none"}
        MTBitIn60 = {"name": "mTBitIn60", "type": "BOOL", "unit": "none"}
        MTBitIn61 = {"name": "mTBitIn61", "type": "BOOL", "unit": "none"}
        MTBitIn62 = {"name": "mTBitIn62", "type": "BOOL", "unit": "none"}
        MTBitIn63 = {"name": "mTBitIn63", "type": "BOOL", "unit": "none"}
        MTBitIn64 = {"name": "mTBitIn64", "type": "BOOL", "unit": "none"}
        MTBitIn65 = {"name": "mTBitIn65", "type": "BOOL", "unit": "none"}
        MTBitIn66 = {"name": "mTBitIn66", "type": "BOOL", "unit": "none"}
        MTBitIn67 = {"name": "mTBitIn67", "type": "BOOL", "unit": "none"}
        MTBitIn68 = {"name": "mTBitIn68", "type": "BOOL", "unit": "none"}
        MTBitIn69 = {"name": "mTBitIn69", "type": "BOOL", "unit": "none"}
        MTBitIn70 = {"name": "mTBitIn70", "type": "BOOL", "unit": "none"}
        MTBitIn71 = {"name": "mTBitIn71", "type": "BOOL", "unit": "none"}
        MTBitIn72 = {"name": "mTBitIn72", "type": "BOOL", "unit": "none"}
        MTBitIn73 = {"name": "mTBitIn73", "type": "BOOL", "unit": "none"}
        MTBitIn74 = {"name": "mTBitIn74", "type": "BOOL", "unit": "none"}
        MTBitIn75 = {"name": "mTBitIn75", "type": "BOOL", "unit": "none"}
        MTBitIn76 = {"name": "mTBitIn76", "type": "BOOL", "unit": "none"}
        MTBitIn77 = {"name": "mTBitIn77", "type": "BOOL", "unit": "none"}
        MTBitIn78 = {"name": "mTBitIn78", "type": "BOOL", "unit": "none"}
        MTBitIn79 = {"name": "mTBitIn79", "type": "BOOL", "unit": "none"}
        MTBitIn80 = {"name": "mTBitIn80", "type": "BOOL", "unit": "none"}
        MTBitIn81 = {"name": "mTBitIn81", "type": "BOOL", "unit": "none"}
        MTBitIn82 = {"name": "mTBitIn82", "type": "BOOL", "unit": "none"}
        MTBitIn83 = {"name": "mTBitIn83", "type": "BOOL", "unit": "none"}
        MTBitIn84 = {"name": "mTBitIn84", "type": "BOOL", "unit": "none"}
        MTBitIn85 = {"name": "mTBitIn85", "type": "BOOL", "unit": "none"}
        MTBitIn86 = {"name": "mTBitIn86", "type": "BOOL", "unit": "none"}
        MTBitIn87 = {"name": "mTBitIn87", "type": "BOOL", "unit": "none"}
        MTBitIn88 = {"name": "mTBitIn88", "type": "BOOL", "unit": "none"}
        MTBitIn89 = {"name": "mTBitIn89", "type": "BOOL", "unit": "none"}
        MTBitIn90 = {"name": "mTBitIn90", "type": "BOOL", "unit": "none"}
        MTBitIn91 = {"name": "mTBitIn91", "type": "BOOL", "unit": "none"}
        MTBitIn92 = {"name": "mTBitIn92", "type": "BOOL", "unit": "none"}
        MTBitIn93 = {"name": "mTBitIn93", "type": "BOOL", "unit": "none"}
        MTBitIn94 = {"name": "mTBitIn94", "type": "BOOL", "unit": "none"}
        MTBitIn95 = {"name": "mTBitIn95", "type": "BOOL", "unit": "none"}
        MTBitIn96 = {"name": "mTBitIn96", "type": "BOOL", "unit": "none"}
        MTBitIn97 = {"name": "mTBitIn97", "type": "BOOL", "unit": "none"}
        MTBitIn98 = {"name": "mTBitIn98", "type": "BOOL", "unit": "none"}
        MTBitIn99 = {"name": "mTBitIn99", "type": "BOOL", "unit": "none"}
        MTBitIn100 = {"name": "mTBitIn100", "type": "BOOL", "unit": "none"}
        MTBitIn101 = {"name": "mTBitIn101", "type": "BOOL", "unit": "none"}
        MTBitIn102 = {"name": "mTBitIn102", "type": "BOOL", "unit": "none"}
        MTBitIn103 = {"name": "mTBitIn103", "type": "BOOL", "unit": "none"}
        MTBitIn104 = {"name": "mTBitIn104", "type": "BOOL", "unit": "none"}
        MTBitIn105 = {"name": "mTBitIn105", "type": "BOOL", "unit": "none"}
        MTBitIn106 = {"name": "mTBitIn106", "type": "BOOL", "unit": "none"}
        MTBitIn107 = {"name": "mTBitIn107", "type": "BOOL", "unit": "none"}
        MTBitIn108 = {"name": "mTBitIn108", "type": "BOOL", "unit": "none"}
        MTBitIn109 = {"name": "mTBitIn109", "type": "BOOL", "unit": "none"}
        MTBitIn110 = {"name": "mTBitIn110", "type": "BOOL", "unit": "none"}
        MTBitIn111 = {"name": "mTBitIn111", "type": "BOOL", "unit": "none"}
        MTBitIn112 = {"name": "mTBitIn112", "type": "BOOL", "unit": "none"}
        MTBitIn113 = {"name": "mTBitIn113", "type": "BOOL", "unit": "none"}
        MTBitIn114 = {"name": "mTBitIn114", "type": "BOOL", "unit": "none"}
        MTBitIn115 = {"name": "mTBitIn115", "type": "BOOL", "unit": "none"}
        MTBitIn116 = {"name": "mTBitIn116", "type": "BOOL", "unit": "none"}
        MTBitIn117 = {"name": "mTBitIn117", "type": "BOOL", "unit": "none"}
        MTBitIn118 = {"name": "mTBitIn118", "type": "BOOL", "unit": "none"}
        MTBitIn119 = {"name": "mTBitIn119", "type": "BOOL", "unit": "none"}
        MTBitIn120 = {"name": "mTBitIn120", "type": "BOOL", "unit": "none"}
        MTBitIn121 = {"name": "mTBitIn121", "type": "BOOL", "unit": "none"}
        MTBitIn122 = {"name": "mTBitIn122", "type": "BOOL", "unit": "none"}
        MTBitIn123 = {"name": "mTBitIn123", "type": "BOOL", "unit": "none"}
        MTBitIn124 = {"name": "mTBitIn124", "type": "BOOL", "unit": "none"}
        MTBitIn125 = {"name": "mTBitIn125", "type": "BOOL", "unit": "none"}
        MTBitIn126 = {"name": "mTBitIn126", "type": "BOOL", "unit": "none"}
        MTBitIn127 = {"name": "mTBitIn127", "type": "BOOL", "unit": "none"}
        MTBitIn128 = {"name": "mTBitIn128", "type": "BOOL", "unit": "none"}
        MTBitIn129 = {"name": "mTBitIn129", "type": "BOOL", "unit": "none"}
        MTBitIn130 = {"name": "mTBitIn130", "type": "BOOL", "unit": "none"}
        MTBitIn131 = {"name": "mTBitIn131", "type": "BOOL", "unit": "none"}
        MTBitIn132 = {"name": "mTBitIn132", "type": "BOOL", "unit": "none"}
        MTBitIn133 = {"name": "mTBitIn133", "type": "BOOL", "unit": "none"}
        MTBitIn134 = {"name": "mTBitIn134", "type": "BOOL", "unit": "none"}
        MTBitIn135 = {"name": "mTBitIn135", "type": "BOOL", "unit": "none"}
        MTBitIn136 = {"name": "mTBitIn136", "type": "BOOL", "unit": "none"}
        MTBitIn137 = {"name": "mTBitIn137", "type": "BOOL", "unit": "none"}
        MTBitIn138 = {"name": "mTBitIn138", "type": "BOOL", "unit": "none"}
        MTBitIn139 = {"name": "mTBitIn139", "type": "BOOL", "unit": "none"}
        MTBitIn140 = {"name": "mTBitIn140", "type": "BOOL", "unit": "none"}
        MTBitIn141 = {"name": "mTBitIn141", "type": "BOOL", "unit": "none"}
        MTBitIn142 = {"name": "mTBitIn142", "type": "BOOL", "unit": "none"}
        MTBitIn143 = {"name": "mTBitIn143", "type": "BOOL", "unit": "none"}
        MTBitIn144 = {"name": "mTBitIn144", "type": "BOOL", "unit": "none"}
        MTBitIn145 = {"name": "mTBitIn145", "type": "BOOL", "unit": "none"}
        MTBitIn146 = {"name": "mTBitIn146", "type": "BOOL", "unit": "none"}
        MTBitIn147 = {"name": "mTBitIn147", "type": "BOOL", "unit": "none"}
        MTBitIn148 = {"name": "mTBitIn148", "type": "BOOL", "unit": "none"}
        MTBitIn149 = {"name": "mTBitIn149", "type": "BOOL", "unit": "none"}
        MTBitIn150 = {"name": "mTBitIn150", "type": "BOOL", "unit": "none"}
        MTBitIn151 = {"name": "mTBitIn151", "type": "BOOL", "unit": "none"}
        MTBitIn152 = {"name": "mTBitIn152", "type": "BOOL", "unit": "none"}
        MTBitIn153 = {"name": "mTBitIn153", "type": "BOOL", "unit": "none"}
        MTBitIn154 = {"name": "mTBitIn154", "type": "BOOL", "unit": "none"}
        MTBitIn155 = {"name": "mTBitIn155", "type": "BOOL", "unit": "none"}
        MTBitIn156 = {"name": "mTBitIn156", "type": "BOOL", "unit": "none"}
        MTBitIn157 = {"name": "mTBitIn157", "type": "BOOL", "unit": "none"}
        MTBitIn158 = {"name": "mTBitIn158", "type": "BOOL", "unit": "none"}
        MTBitIn159 = {"name": "mTBitIn159", "type": "BOOL", "unit": "none"}
        MTBitIn160 = {"name": "mTBitIn160", "type": "BOOL", "unit": "none"}
        MTBitIn161 = {"name": "mTBitIn161", "type": "BOOL", "unit": "none"}
        MTBitIn162 = {"name": "mTBitIn162", "type": "BOOL", "unit": "none"}
        MTBitIn163 = {"name": "mTBitIn163", "type": "BOOL", "unit": "none"}
        MTBitIn164 = {"name": "mTBitIn164", "type": "BOOL", "unit": "none"}
        MTBitIn165 = {"name": "mTBitIn165", "type": "BOOL", "unit": "none"}
        MTBitIn166 = {"name": "mTBitIn166", "type": "BOOL", "unit": "none"}
        MTBitIn167 = {"name": "mTBitIn167", "type": "BOOL", "unit": "none"}
        MTBitIn168 = {"name": "mTBitIn168", "type": "BOOL", "unit": "none"}
        MTBitIn169 = {"name": "mTBitIn169", "type": "BOOL", "unit": "none"}
        MTBitIn170 = {"name": "mTBitIn170", "type": "BOOL", "unit": "none"}
        MTBitIn171 = {"name": "mTBitIn171", "type": "BOOL", "unit": "none"}
        MTBitIn172 = {"name": "mTBitIn172", "type": "BOOL", "unit": "none"}
        MTBitIn173 = {"name": "mTBitIn173", "type": "BOOL", "unit": "none"}
        MTBitIn174 = {"name": "mTBitIn174", "type": "BOOL", "unit": "none"}
        MTBitIn175 = {"name": "mTBitIn175", "type": "BOOL", "unit": "none"}
        MTBitIn176 = {"name": "mTBitIn176", "type": "BOOL", "unit": "none"}
        MTBitIn177 = {"name": "mTBitIn177", "type": "BOOL", "unit": "none"}
        MTBitIn178 = {"name": "mTBitIn178", "type": "BOOL", "unit": "none"}
        MTBitIn179 = {"name": "mTBitIn179", "type": "BOOL", "unit": "none"}
        MTBitIn180 = {"name": "mTBitIn180", "type": "BOOL", "unit": "none"}
        MTBitIn181 = {"name": "mTBitIn181", "type": "BOOL", "unit": "none"}
        MTBitIn182 = {"name": "mTBitIn182", "type": "BOOL", "unit": "none"}
        MTBitIn183 = {"name": "mTBitIn183", "type": "BOOL", "unit": "none"}
        MTBitIn184 = {"name": "mTBitIn184", "type": "BOOL", "unit": "none"}
        MTBitIn185 = {"name": "mTBitIn185", "type": "BOOL", "unit": "none"}
        MTBitIn186 = {"name": "mTBitIn186", "type": "BOOL", "unit": "none"}
        MTBitIn187 = {"name": "mTBitIn187", "type": "BOOL", "unit": "none"}
        MTBitIn188 = {"name": "mTBitIn188", "type": "BOOL", "unit": "none"}
        MTBitIn189 = {"name": "mTBitIn189", "type": "BOOL", "unit": "none"}
        MTBitIn190 = {"name": "mTBitIn190", "type": "BOOL", "unit": "none"}
        MTBitIn191 = {"name": "mTBitIn191", "type": "BOOL", "unit": "none"}
        MTBitIn192 = {"name": "mTBitIn192", "type": "BOOL", "unit": "none"}
        MTBitIn193 = {"name": "mTBitIn193", "type": "BOOL", "unit": "none"}
        MTBitIn194 = {"name": "mTBitIn194", "type": "BOOL", "unit": "none"}
        MTBitIn195 = {"name": "mTBitIn195", "type": "BOOL", "unit": "none"}
        MTBitIn196 = {"name": "mTBitIn196", "type": "BOOL", "unit": "none"}
        MTBitIn197 = {"name": "mTBitIn197", "type": "BOOL", "unit": "none"}
        MTBitIn198 = {"name": "mTBitIn198", "type": "BOOL", "unit": "none"}
        MTBitIn199 = {"name": "mTBitIn199", "type": "BOOL", "unit": "none"}
        MTBitIn200 = {"name": "mTBitIn200", "type": "BOOL", "unit": "none"}
        MTBitIn201 = {"name": "mTBitIn201", "type": "BOOL", "unit": "none"}
        MTBitIn202 = {"name": "mTBitIn202", "type": "BOOL", "unit": "none"}
        MTBitIn203 = {"name": "mTBitIn203", "type": "BOOL", "unit": "none"}
        MTBitIn204 = {"name": "mTBitIn204", "type": "BOOL", "unit": "none"}
        MTBitIn205 = {"name": "mTBitIn205", "type": "BOOL", "unit": "none"}
        MTBitIn206 = {"name": "mTBitIn206", "type": "BOOL", "unit": "none"}
        MTBitIn207 = {"name": "mTBitIn207", "type": "BOOL", "unit": "none"}
        MTBitIn208 = {"name": "mTBitIn208", "type": "BOOL", "unit": "none"}
        MTBitIn209 = {"name": "mTBitIn209", "type": "BOOL", "unit": "none"}
        MTBitIn210 = {"name": "mTBitIn210", "type": "BOOL", "unit": "none"}
        MTBitIn211 = {"name": "mTBitIn211", "type": "BOOL", "unit": "none"}
        MTBitIn212 = {"name": "mTBitIn212", "type": "BOOL", "unit": "none"}
        MTBitIn213 = {"name": "mTBitIn213", "type": "BOOL", "unit": "none"}
        MTBitIn214 = {"name": "mTBitIn214", "type": "BOOL", "unit": "none"}
        MTBitIn215 = {"name": "mTBitIn215", "type": "BOOL", "unit": "none"}
        MTBitIn216 = {"name": "mTBitIn216", "type": "BOOL", "unit": "none"}
        MTBitIn217 = {"name": "mTBitIn217", "type": "BOOL", "unit": "none"}
        MTBitIn218 = {"name": "mTBitIn218", "type": "BOOL", "unit": "none"}
        MTBitIn219 = {"name": "mTBitIn219", "type": "BOOL", "unit": "none"}
        MTBitIn220 = {"name": "mTBitIn220", "type": "BOOL", "unit": "none"}
        MTBitIn221 = {"name": "mTBitIn221", "type": "BOOL", "unit": "none"}
        MTBitIn222 = {"name": "mTBitIn222", "type": "BOOL", "unit": "none"}
        MTBitIn223 = {"name": "mTBitIn223", "type": "BOOL", "unit": "none"}
        MTBitIn224 = {"name": "mTBitIn224", "type": "BOOL", "unit": "none"}
        MTBitIn225 = {"name": "mTBitIn225", "type": "BOOL", "unit": "none"}
        MTBitIn226 = {"name": "mTBitIn226", "type": "BOOL", "unit": "none"}
        MTBitIn227 = {"name": "mTBitIn227", "type": "BOOL", "unit": "none"}
        MTBitIn228 = {"name": "mTBitIn228", "type": "BOOL", "unit": "none"}
        MTBitIn229 = {"name": "mTBitIn229", "type": "BOOL", "unit": "none"}
        MTBitIn230 = {"name": "mTBitIn230", "type": "BOOL", "unit": "none"}
        MTBitIn231 = {"name": "mTBitIn231", "type": "BOOL", "unit": "none"}
        MTBitIn232 = {"name": "mTBitIn232", "type": "BOOL", "unit": "none"}
        MTBitIn233 = {"name": "mTBitIn233", "type": "BOOL", "unit": "none"}
        MTBitIn234 = {"name": "mTBitIn234", "type": "BOOL", "unit": "none"}
        MTBitIn235 = {"name": "mTBitIn235", "type": "BOOL", "unit": "none"}
        MTBitIn236 = {"name": "mTBitIn236", "type": "BOOL", "unit": "none"}
        MTBitIn237 = {"name": "mTBitIn237", "type": "BOOL", "unit": "none"}
        MTBitIn238 = {"name": "mTBitIn238", "type": "BOOL", "unit": "none"}
        MTBitIn239 = {"name": "mTBitIn239", "type": "BOOL", "unit": "none"}
        MTBitIn240 = {"name": "mTBitIn240", "type": "BOOL", "unit": "none"}
        MTBitIn241 = {"name": "mTBitIn241", "type": "BOOL", "unit": "none"}
        MTBitIn242 = {"name": "mTBitIn242", "type": "BOOL", "unit": "none"}
        MTBitIn243 = {"name": "mTBitIn243", "type": "BOOL", "unit": "none"}
        MTBitIn244 = {"name": "mTBitIn244", "type": "BOOL", "unit": "none"}
        MTBitIn245 = {"name": "mTBitIn245", "type": "BOOL", "unit": "none"}
        MTBitIn246 = {"name": "mTBitIn246", "type": "BOOL", "unit": "none"}
        MTBitIn247 = {"name": "mTBitIn247", "type": "BOOL", "unit": "none"}
        MTBitIn248 = {"name": "mTBitIn248", "type": "BOOL", "unit": "none"}
        MTBitIn249 = {"name": "mTBitIn249", "type": "BOOL", "unit": "none"}
        MTBitIn250 = {"name": "mTBitIn250", "type": "BOOL", "unit": "none"}
        MTBitIn251 = {"name": "mTBitIn251", "type": "BOOL", "unit": "none"}
        MTBitIn252 = {"name": "mTBitIn252", "type": "BOOL", "unit": "none"}
        MTBitIn253 = {"name": "mTBitIn253", "type": "BOOL", "unit": "none"}
        MTBitIn254 = {"name": "mTBitIn254", "type": "BOOL", "unit": "none"}
        MTBitIn255 = {"name": "mTBitIn255", "type": "BOOL", "unit": "none"}

        MTIntIn0 = {"name": "mTIntIn0", "type": "INT", "unit": "none"}
        MTIntIn1 = {"name": "mTIntIn1", "type": "INT", "unit": "none"}
        MTIntIn2 = {"name": "mTIntIn2", "type": "INT", "unit": "none"}
        MTIntIn3 = {"name": "mTIntIn3", "type": "INT", "unit": "none"}
        MTIntIn4 = {"name": "mTIntIn4", "type": "INT", "unit": "none"}
        MTIntIn5 = {"name": "mTIntIn5", "type": "INT", "unit": "none"}
        MTIntIn6 = {"name": "mTIntIn6", "type": "INT", "unit": "none"}
        MTIntIn7 = {"name": "mTIntIn7", "type": "INT", "unit": "none"}
        MTIntIn8 = {"name": "mTIntIn8", "type": "INT", "unit": "none"}
        MTIntIn9 = {"name": "mTIntIn9", "type": "INT", "unit": "none"}
        MTIntIn10 = {"name": "mTIntIn10", "type": "INT", "unit": "none"}
        MTIntIn11 = {"name": "mTIntIn11", "type": "INT", "unit": "none"}
        MTIntIn12 = {"name": "mTIntIn12", "type": "INT", "unit": "none"}
        MTIntIn13 = {"name": "mTIntIn13", "type": "INT", "unit": "none"}
        MTIntIn14 = {"name": "mTIntIn14", "type": "INT", "unit": "none"}
        MTIntIn15 = {"name": "mTIntIn15", "type": "INT", "unit": "none"}
        MTIntIn16 = {"name": "mTIntIn16", "type": "INT", "unit": "none"}
        MTIntIn17 = {"name": "mTIntIn17", "type": "INT", "unit": "none"}
        MTIntIn18 = {"name": "mTIntIn18", "type": "INT", "unit": "none"}
        MTIntIn19 = {"name": "mTIntIn19", "type": "INT", "unit": "none"}
        MTIntIn20 = {"name": "mTIntIn20", "type": "INT", "unit": "none"}
        MTIntIn21 = {"name": "mTIntIn21", "type": "INT", "unit": "none"}
        MTIntIn22 = {"name": "mTIntIn22", "type": "INT", "unit": "none"}
        MTIntIn23 = {"name": "mTIntIn23", "type": "INT", "unit": "none"}
        MTIntIn24 = {"name": "mTIntIn24", "type": "INT", "unit": "none"}
        MTIntIn25 = {"name": "mTIntIn25", "type": "INT", "unit": "none"}
        MTIntIn26 = {"name": "mTIntIn26", "type": "INT", "unit": "none"}
        MTIntIn27 = {"name": "mTIntIn27", "type": "INT", "unit": "none"}
        MTIntIn28 = {"name": "mTIntIn28", "type": "INT", "unit": "none"}
        MTIntIn29 = {"name": "mTIntIn29", "type": "INT", "unit": "none"}
        MTIntIn30 = {"name": "mTIntIn30", "type": "INT", "unit": "none"}
        MTIntIn31 = {"name": "mTIntIn31", "type": "INT", "unit": "none"}
        MTIntIn32 = {"name": "mTIntIn32", "type": "INT", "unit": "none"}
        MTIntIn33 = {"name": "mTIntIn33", "type": "INT", "unit": "none"}
        MTIntIn34 = {"name": "mTIntIn34", "type": "INT", "unit": "none"}
        MTIntIn35 = {"name": "mTIntIn35", "type": "INT", "unit": "none"}
        MTIntIn36 = {"name": "mTIntIn36", "type": "INT", "unit": "none"}
        MTIntIn37 = {"name": "mTIntIn37", "type": "INT", "unit": "none"}
        MTIntIn38 = {"name": "mTIntIn38", "type": "INT", "unit": "none"}
        MTIntIn39 = {"name": "mTIntIn39", "type": "INT", "unit": "none"}
        MTIntIn40 = {"name": "mTIntIn40", "type": "INT", "unit": "none"}
        MTIntIn41 = {"name": "mTIntIn41", "type": "INT", "unit": "none"}
        MTIntIn42 = {"name": "mTIntIn42", "type": "INT", "unit": "none"}
        MTIntIn43 = {"name": "mTIntIn43", "type": "INT", "unit": "none"}
        MTIntIn44 = {"name": "mTIntIn44", "type": "INT", "unit": "none"}
        MTIntIn45 = {"name": "mTIntIn45", "type": "INT", "unit": "none"}
        MTIntIn46 = {"name": "mTIntIn46", "type": "INT", "unit": "none"}
        MTIntIn47 = {"name": "mTIntIn47", "type": "INT", "unit": "none"}
        MTIntIn48 = {"name": "mTIntIn48", "type": "INT", "unit": "none"}
        MTIntIn49 = {"name": "mTIntIn49", "type": "INT", "unit": "none"}
        MTIntIn50 = {"name": "mTIntIn50", "type": "INT", "unit": "none"}
        MTIntIn51 = {"name": "mTIntIn51", "type": "INT", "unit": "none"}
        MTIntIn52 = {"name": "mTIntIn52", "type": "INT", "unit": "none"}
        MTIntIn53 = {"name": "mTIntIn53", "type": "INT", "unit": "none"}
        MTIntIn54 = {"name": "mTIntIn54", "type": "INT", "unit": "none"}
        MTIntIn55 = {"name": "mTIntIn55", "type": "INT", "unit": "none"}
        MTIntIn56 = {"name": "mTIntIn56", "type": "INT", "unit": "none"}
        MTIntIn57 = {"name": "mTIntIn57", "type": "INT", "unit": "none"}
        MTIntIn58 = {"name": "mTIntIn58", "type": "INT", "unit": "none"}
        MTIntIn59 = {"name": "mTIntIn59", "type": "INT", "unit": "none"}
        MTIntIn60 = {"name": "mTIntIn60", "type": "INT", "unit": "none"}
        MTIntIn61 = {"name": "mTIntIn61", "type": "INT", "unit": "none"}
        MTIntIn62 = {"name": "mTIntIn62", "type": "INT", "unit": "none"}
        MTIntIn63 = {"name": "mTIntIn63", "type": "INT", "unit": "none"}

        MTFloatIn0 = {"name": "mTFloatIn0", "type": "DOUBLE", "unit": "none"}
        MTFloatIn1 = {"name": "mTFloatIn1", "type": "DOUBLE", "unit": "none"}
        MTFloatIn2 = {"name": "mTFloatIn2", "type": "DOUBLE", "unit": "none"}
        MTFloatIn3 = {"name": "mTFloatIn3", "type": "DOUBLE", "unit": "none"}
        MTFloatIn4 = {"name": "mTFloatIn4", "type": "DOUBLE", "unit": "none"}
        MTFloatIn5 = {"name": "mTFloatIn5", "type": "DOUBLE", "unit": "none"}
        MTFloatIn6 = {"name": "mTFloatIn6", "type": "DOUBLE", "unit": "none"}
        MTFloatIn7 = {"name": "mTFloatIn7", "type": "DOUBLE", "unit": "none"}
        MTFloatIn8 = {"name": "mTFloatIn8", "type": "DOUBLE", "unit": "none"}
        MTFloatIn9 = {"name": "mTFloatIn9", "type": "DOUBLE", "unit": "none"}
        MTFloatIn10 = {"name": "mTFloatIn10", "type": "DOUBLE", "unit": "none"}
        MTFloatIn11 = {"name": "mTFloatIn11", "type": "DOUBLE", "unit": "none"}
        MTFloatIn12 = {"name": "mTFloatIn12", "type": "DOUBLE", "unit": "none"}
        MTFloatIn13 = {"name": "mTFloatIn13", "type": "DOUBLE", "unit": "none"}
        MTFloatIn14 = {"name": "mTFloatIn14", "type": "DOUBLE", "unit": "none"}
        MTFloatIn15 = {"name": "mTFloatIn15", "type": "DOUBLE", "unit": "none"}
        MTFloatIn16 = {"name": "mTFloatIn16", "type": "DOUBLE", "unit": "none"}
        MTFloatIn17 = {"name": "mTFloatIn17", "type": "DOUBLE", "unit": "none"}
        MTFloatIn18 = {"name": "mTFloatIn18", "type": "DOUBLE", "unit": "none"}
        MTFloatIn19 = {"name": "mTFloatIn19", "type": "DOUBLE", "unit": "none"}
        MTFloatIn20 = {"name": "mTFloatIn20", "type": "DOUBLE", "unit": "none"}
        MTFloatIn21 = {"name": "mTFloatIn21", "type": "DOUBLE", "unit": "none"}
        MTFloatIn22 = {"name": "mTFloatIn22", "type": "DOUBLE", "unit": "none"}
        MTFloatIn23 = {"name": "mTFloatIn23", "type": "DOUBLE", "unit": "none"}
        MTFloatIn24 = {"name": "mTFloatIn24", "type": "DOUBLE", "unit": "none"}
        MTFloatIn25 = {"name": "mTFloatIn25", "type": "DOUBLE", "unit": "none"}
        MTFloatIn26 = {"name": "mTFloatIn26", "type": "DOUBLE", "unit": "none"}
        MTFloatIn27 = {"name": "mTFloatIn27", "type": "DOUBLE", "unit": "none"}
        MTFloatIn28 = {"name": "mTFloatIn28", "type": "DOUBLE", "unit": "none"}
        MTFloatIn29 = {"name": "mTFloatIn29", "type": "DOUBLE", "unit": "none"}
        MTFloatIn30 = {"name": "mTFloatIn30", "type": "DOUBLE", "unit": "none"}
        MTFloatIn31 = {"name": "mTFloatIn31", "type": "DOUBLE", "unit": "none"}
        MTFloatIn32 = {"name": "mTFloatIn32", "type": "DOUBLE", "unit": "none"}
        MTFloatIn33 = {"name": "mTFloatIn33", "type": "DOUBLE", "unit": "none"}
        MTFloatIn34 = {"name": "mTFloatIn34", "type": "DOUBLE", "unit": "none"}
        MTFloatIn35 = {"name": "mTFloatIn35", "type": "DOUBLE", "unit": "none"}
        MTFloatIn36 = {"name": "mTFloatIn36", "type": "DOUBLE", "unit": "none"}
        MTFloatIn37 = {"name": "mTFloatIn37", "type": "DOUBLE", "unit": "none"}
        MTFloatIn38 = {"name": "mTFloatIn38", "type": "DOUBLE", "unit": "none"}
        MTFloatIn39 = {"name": "mTFloatIn39", "type": "DOUBLE", "unit": "none"}
        MTFloatIn40 = {"name": "mTFloatIn40", "type": "DOUBLE", "unit": "none"}
        MTFloatIn41 = {"name": "mTFloatIn41", "type": "DOUBLE", "unit": "none"}
        MTFloatIn42 = {"name": "mTFloatIn42", "type": "DOUBLE", "unit": "none"}
        MTFloatIn43 = {"name": "mTFloatIn43", "type": "DOUBLE", "unit": "none"}
        MTFloatIn44 = {"name": "mTFloatIn44", "type": "DOUBLE", "unit": "none"}
        MTFloatIn45 = {"name": "mTFloatIn45", "type": "DOUBLE", "unit": "none"}
        MTFloatIn46 = {"name": "mTFloatIn46", "type": "DOUBLE", "unit": "none"}
        MTFloatIn47 = {"name": "mTFloatIn47", "type": "DOUBLE", "unit": "none"}
        MTFloatIn48 = {"name": "mTFloatIn48", "type": "DOUBLE", "unit": "none"}
        MTFloatIn49 = {"name": "mTFloatIn49", "type": "DOUBLE", "unit": "none"}
        MTFloatIn50 = {"name": "mTFloatIn50", "type": "DOUBLE", "unit": "none"}
        MTFloatIn51 = {"name": "mTFloatIn51", "type": "DOUBLE", "unit": "none"}
        MTFloatIn52 = {"name": "mTFloatIn52", "type": "DOUBLE", "unit": "none"}
        MTFloatIn53 = {"name": "mTFloatIn53", "type": "DOUBLE", "unit": "none"}
        MTFloatIn54 = {"name": "mTFloatIn54", "type": "DOUBLE", "unit": "none"}
        MTFloatIn55 = {"name": "mTFloatIn55", "type": "DOUBLE", "unit": "none"}
        MTFloatIn56 = {"name": "mTFloatIn56", "type": "DOUBLE", "unit": "none"}
        MTFloatIn57 = {"name": "mTFloatIn57", "type": "DOUBLE", "unit": "none"}
        MTFloatIn58 = {"name": "mTFloatIn58", "type": "DOUBLE", "unit": "none"}
        MTFloatIn59 = {"name": "mTFloatIn59", "type": "DOUBLE", "unit": "none"}
        MTFloatIn60 = {"name": "mTFloatIn60", "type": "DOUBLE", "unit": "none"}
        MTFloatIn61 = {"name": "mTFloatIn61", "type": "DOUBLE", "unit": "none"}
        MTFloatIn62 = {"name": "mTFloatIn62", "type": "DOUBLE", "unit": "none"}
        MTFloatIn63 = {"name": "mTFloatIn63", "type": "DOUBLE", "unit": "none"}

    class GPIOProfinetSlave(Enum):
        PfBitIn0 = {"name": "pfBitIn0", "type": "BOOL", "unit": "none"}
        PfBitIn1 = {"name": "pfBitIn1", "type": "BOOL", "unit": "none"}
        PfBitIn2 = {"name": "pfBitIn2", "type": "BOOL", "unit": "none"}
        PfBitIn3 = {"name": "pfBitIn3", "type": "BOOL", "unit": "none"}
        PfBitIn4 = {"name": "pfBitIn4", "type": "BOOL", "unit": "none"}
        PfBitIn5 = {"name": "pfBitIn5", "type": "BOOL", "unit": "none"}
        PfBitIn6 = {"name": "pfBitIn6", "type": "BOOL", "unit": "none"}
        PfBitIn7 = {"name": "pfBitIn7", "type": "BOOL", "unit": "none"}
        PfBitIn8 = {"name": "pfBitIn8", "type": "BOOL", "unit": "none"}
        PfBitIn9 = {"name": "pfBitIn9", "type": "BOOL", "unit": "none"}
        PfBitIn10 = {"name": "pfBitIn10", "type": "BOOL", "unit": "none"}
        PfBitIn11 = {"name": "pfBitIn11", "type": "BOOL", "unit": "none"}
        PfBitIn12 = {"name": "pfBitIn12", "type": "BOOL", "unit": "none"}
        PfBitIn13 = {"name": "pfBitIn13", "type": "BOOL", "unit": "none"}
        PfBitIn14 = {"name": "pfBitIn14", "type": "BOOL", "unit": "none"}
        PfBitIn15 = {"name": "pfBitIn15", "type": "BOOL", "unit": "none"}
        PfBitIn16 = {"name": "pfBitIn16", "type": "BOOL", "unit": "none"}
        PfBitIn17 = {"name": "pfBitIn17", "type": "BOOL", "unit": "none"}
        PfBitIn18 = {"name": "pfBitIn18", "type": "BOOL", "unit": "none"}
        PfBitIn19 = {"name": "pfBitIn19", "type": "BOOL", "unit": "none"}
        PfBitIn20 = {"name": "pfBitIn20", "type": "BOOL", "unit": "none"}
        PfBitIn21 = {"name": "pfBitIn21", "type": "BOOL", "unit": "none"}
        PfBitIn22 = {"name": "pfBitIn22", "type": "BOOL", "unit": "none"}
        PfBitIn23 = {"name": "pfBitIn23", "type": "BOOL", "unit": "none"}
        PfBitIn24 = {"name": "pfBitIn24", "type": "BOOL", "unit": "none"}
        PfBitIn25 = {"name": "pfBitIn25", "type": "BOOL", "unit": "none"}
        PfBitIn26 = {"name": "pfBitIn26", "type": "BOOL", "unit": "none"}
        PfBitIn27 = {"name": "pfBitIn27", "type": "BOOL", "unit": "none"}
        PfBitIn28 = {"name": "pfBitIn28", "type": "BOOL", "unit": "none"}
        PfBitIn29 = {"name": "pfBitIn29", "type": "BOOL", "unit": "none"}
        PfBitIn30 = {"name": "pfBitIn30", "type": "BOOL", "unit": "none"}
        PfBitIn31 = {"name": "pfBitIn31", "type": "BOOL", "unit": "none"}
        PfBitIn32 = {"name": "pfBitIn32", "type": "BOOL", "unit": "none"}
        PfBitIn33 = {"name": "pfBitIn33", "type": "BOOL", "unit": "none"}
        PfBitIn34 = {"name": "pfBitIn34", "type": "BOOL", "unit": "none"}
        PfBitIn35 = {"name": "pfBitIn35", "type": "BOOL", "unit": "none"}
        PfBitIn36 = {"name": "pfBitIn36", "type": "BOOL", "unit": "none"}
        PfBitIn37 = {"name": "pfBitIn37", "type": "BOOL", "unit": "none"}
        PfBitIn38 = {"name": "pfBitIn38", "type": "BOOL", "unit": "none"}
        PfBitIn39 = {"name": "pfBitIn39", "type": "BOOL", "unit": "none"}
        PfBitIn40 = {"name": "pfBitIn40", "type": "BOOL", "unit": "none"}
        PfBitIn41 = {"name": "pfBitIn41", "type": "BOOL", "unit": "none"}
        PfBitIn42 = {"name": "pfBitIn42", "type": "BOOL", "unit": "none"}
        PfBitIn43 = {"name": "pfBitIn43", "type": "BOOL", "unit": "none"}
        PfBitIn44 = {"name": "pfBitIn44", "type": "BOOL", "unit": "none"}
        PfBitIn45 = {"name": "pfBitIn45", "type": "BOOL", "unit": "none"}
        PfBitIn46 = {"name": "pfBitIn46", "type": "BOOL", "unit": "none"}
        PfBitIn47 = {"name": "pfBitIn47", "type": "BOOL", "unit": "none"}
        PfBitIn48 = {"name": "pfBitIn48", "type": "BOOL", "unit": "none"}
        PfBitIn49 = {"name": "pfBitIn49", "type": "BOOL", "unit": "none"}
        PfBitIn50 = {"name": "pfBitIn50", "type": "BOOL", "unit": "none"}
        PfBitIn51 = {"name": "pfBitIn51", "type": "BOOL", "unit": "none"}
        PfBitIn52 = {"name": "pfBitIn52", "type": "BOOL", "unit": "none"}
        PfBitIn53 = {"name": "pfBitIn53", "type": "BOOL", "unit": "none"}
        PfBitIn54 = {"name": "pfBitIn54", "type": "BOOL", "unit": "none"}
        PfBitIn55 = {"name": "pfBitIn55", "type": "BOOL", "unit": "none"}
        PfBitIn56 = {"name": "pfBitIn56", "type": "BOOL", "unit": "none"}
        PfBitIn57 = {"name": "pfBitIn57", "type": "BOOL", "unit": "none"}
        PfBitIn58 = {"name": "pfBitIn58", "type": "BOOL", "unit": "none"}
        PfBitIn59 = {"name": "pfBitIn59", "type": "BOOL", "unit": "none"}
        PfBitIn60 = {"name": "pfBitIn60", "type": "BOOL", "unit": "none"}
        PfBitIn61 = {"name": "pfBitIn61", "type": "BOOL", "unit": "none"}
        PfBitIn62 = {"name": "pfBitIn62", "type": "BOOL", "unit": "none"}
        PfBitIn63 = {"name": "pfBitIn63", "type": "BOOL", "unit": "none"}
        PfBitIn64 = {"name": "pfBitIn64", "type": "BOOL", "unit": "none"}
        PfBitIn65 = {"name": "pfBitIn65", "type": "BOOL", "unit": "none"}
        PfBitIn66 = {"name": "pfBitIn66", "type": "BOOL", "unit": "none"}
        PfBitIn67 = {"name": "pfBitIn67", "type": "BOOL", "unit": "none"}
        PfBitIn68 = {"name": "pfBitIn68", "type": "BOOL", "unit": "none"}
        PfBitIn69 = {"name": "pfBitIn69", "type": "BOOL", "unit": "none"}
        PfBitIn70 = {"name": "pfBitIn70", "type": "BOOL", "unit": "none"}
        PfBitIn71 = {"name": "pfBitIn71", "type": "BOOL", "unit": "none"}
        PfBitIn72 = {"name": "pfBitIn72", "type": "BOOL", "unit": "none"}
        PfBitIn73 = {"name": "pfBitIn73", "type": "BOOL", "unit": "none"}
        PfBitIn74 = {"name": "pfBitIn74", "type": "BOOL", "unit": "none"}
        PfBitIn75 = {"name": "pfBitIn75", "type": "BOOL", "unit": "none"}
        PfBitIn76 = {"name": "pfBitIn76", "type": "BOOL", "unit": "none"}
        PfBitIn77 = {"name": "pfBitIn77", "type": "BOOL", "unit": "none"}
        PfBitIn78 = {"name": "pfBitIn78", "type": "BOOL", "unit": "none"}
        PfBitIn79 = {"name": "pfBitIn79", "type": "BOOL", "unit": "none"}
        PfBitIn80 = {"name": "pfBitIn80", "type": "BOOL", "unit": "none"}
        PfBitIn81 = {"name": "pfBitIn81", "type": "BOOL", "unit": "none"}
        PfBitIn82 = {"name": "pfBitIn82", "type": "BOOL", "unit": "none"}
        PfBitIn83 = {"name": "pfBitIn83", "type": "BOOL", "unit": "none"}
        PfBitIn84 = {"name": "pfBitIn84", "type": "BOOL", "unit": "none"}
        PfBitIn85 = {"name": "pfBitIn85", "type": "BOOL", "unit": "none"}
        PfBitIn86 = {"name": "pfBitIn86", "type": "BOOL", "unit": "none"}
        PfBitIn87 = {"name": "pfBitIn87", "type": "BOOL", "unit": "none"}
        PfBitIn88 = {"name": "pfBitIn88", "type": "BOOL", "unit": "none"}
        PfBitIn89 = {"name": "pfBitIn89", "type": "BOOL", "unit": "none"}
        PfBitIn90 = {"name": "pfBitIn90", "type": "BOOL", "unit": "none"}
        PfBitIn91 = {"name": "pfBitIn91", "type": "BOOL", "unit": "none"}
        PfBitIn92 = {"name": "pfBitIn92", "type": "BOOL", "unit": "none"}
        PfBitIn93 = {"name": "pfBitIn93", "type": "BOOL", "unit": "none"}
        PfBitIn94 = {"name": "pfBitIn94", "type": "BOOL", "unit": "none"}
        PfBitIn95 = {"name": "pfBitIn95", "type": "BOOL", "unit": "none"}
        PfBitIn96 = {"name": "pfBitIn96", "type": "BOOL", "unit": "none"}
        PfBitIn97 = {"name": "pfBitIn97", "type": "BOOL", "unit": "none"}
        PfBitIn98 = {"name": "pfBitIn98", "type": "BOOL", "unit": "none"}
        PfBitIn99 = {"name": "pfBitIn99", "type": "BOOL", "unit": "none"}
        PfBitIn100 = {"name": "pfBitIn100", "type": "BOOL", "unit": "none"}
        PfBitIn101 = {"name": "pfBitIn101", "type": "BOOL", "unit": "none"}
        PfBitIn102 = {"name": "pfBitIn102", "type": "BOOL", "unit": "none"}
        PfBitIn103 = {"name": "pfBitIn103", "type": "BOOL", "unit": "none"}
        PfBitIn104 = {"name": "pfBitIn104", "type": "BOOL", "unit": "none"}
        PfBitIn105 = {"name": "pfBitIn105", "type": "BOOL", "unit": "none"}
        PfBitIn106 = {"name": "pfBitIn106", "type": "BOOL", "unit": "none"}
        PfBitIn107 = {"name": "pfBitIn107", "type": "BOOL", "unit": "none"}
        PfBitIn108 = {"name": "pfBitIn108", "type": "BOOL", "unit": "none"}
        PfBitIn109 = {"name": "pfBitIn109", "type": "BOOL", "unit": "none"}
        PfBitIn110 = {"name": "pfBitIn110", "type": "BOOL", "unit": "none"}
        PfBitIn111 = {"name": "pfBitIn111", "type": "BOOL", "unit": "none"}
        PfBitIn112 = {"name": "pfBitIn112", "type": "BOOL", "unit": "none"}
        PfBitIn113 = {"name": "pfBitIn113", "type": "BOOL", "unit": "none"}
        PfBitIn114 = {"name": "pfBitIn114", "type": "BOOL", "unit": "none"}
        PfBitIn115 = {"name": "pfBitIn115", "type": "BOOL", "unit": "none"}
        PfBitIn116 = {"name": "pfBitIn116", "type": "BOOL", "unit": "none"}
        PfBitIn117 = {"name": "pfBitIn117", "type": "BOOL", "unit": "none"}
        PfBitIn118 = {"name": "pfBitIn118", "type": "BOOL", "unit": "none"}
        PfBitIn119 = {"name": "pfBitIn119", "type": "BOOL", "unit": "none"}
        PfBitIn120 = {"name": "pfBitIn120", "type": "BOOL", "unit": "none"}
        PfBitIn121 = {"name": "pfBitIn121", "type": "BOOL", "unit": "none"}
        PfBitIn122 = {"name": "pfBitIn122", "type": "BOOL", "unit": "none"}
        PfBitIn123 = {"name": "pfBitIn123", "type": "BOOL", "unit": "none"}
        PfBitIn124 = {"name": "pfBitIn124", "type": "BOOL", "unit": "none"}
        PfBitIn125 = {"name": "pfBitIn125", "type": "BOOL", "unit": "none"}
        PfBitIn126 = {"name": "pfBitIn126", "type": "BOOL", "unit": "none"}
        PfBitIn127 = {"name": "pfBitIn127", "type": "BOOL", "unit": "none"}
        PfBitIn128 = {"name": "pfBitIn128", "type": "BOOL", "unit": "none"}
        PfBitIn129 = {"name": "pfBitIn129", "type": "BOOL", "unit": "none"}
        PfBitIn130 = {"name": "pfBitIn130", "type": "BOOL", "unit": "none"}
        PfBitIn131 = {"name": "pfBitIn131", "type": "BOOL", "unit": "none"}
        PfBitIn132 = {"name": "pfBitIn132", "type": "BOOL", "unit": "none"}
        PfBitIn133 = {"name": "pfBitIn133", "type": "BOOL", "unit": "none"}
        PfBitIn134 = {"name": "pfBitIn134", "type": "BOOL", "unit": "none"}
        PfBitIn135 = {"name": "pfBitIn135", "type": "BOOL", "unit": "none"}
        PfBitIn136 = {"name": "pfBitIn136", "type": "BOOL", "unit": "none"}
        PfBitIn137 = {"name": "pfBitIn137", "type": "BOOL", "unit": "none"}
        PfBitIn138 = {"name": "pfBitIn138", "type": "BOOL", "unit": "none"}
        PfBitIn139 = {"name": "pfBitIn139", "type": "BOOL", "unit": "none"}
        PfBitIn140 = {"name": "pfBitIn140", "type": "BOOL", "unit": "none"}
        PfBitIn141 = {"name": "pfBitIn141", "type": "BOOL", "unit": "none"}
        PfBitIn142 = {"name": "pfBitIn142", "type": "BOOL", "unit": "none"}
        PfBitIn143 = {"name": "pfBitIn143", "type": "BOOL", "unit": "none"}
        PfBitIn144 = {"name": "pfBitIn144", "type": "BOOL", "unit": "none"}
        PfBitIn145 = {"name": "pfBitIn145", "type": "BOOL", "unit": "none"}
        PfBitIn146 = {"name": "pfBitIn146", "type": "BOOL", "unit": "none"}
        PfBitIn147 = {"name": "pfBitIn147", "type": "BOOL", "unit": "none"}
        PfBitIn148 = {"name": "pfBitIn148", "type": "BOOL", "unit": "none"}
        PfBitIn149 = {"name": "pfBitIn149", "type": "BOOL", "unit": "none"}
        PfBitIn150 = {"name": "pfBitIn150", "type": "BOOL", "unit": "none"}
        PfBitIn151 = {"name": "pfBitIn151", "type": "BOOL", "unit": "none"}
        PfBitIn152 = {"name": "pfBitIn152", "type": "BOOL", "unit": "none"}
        PfBitIn153 = {"name": "pfBitIn153", "type": "BOOL", "unit": "none"}
        PfBitIn154 = {"name": "pfBitIn154", "type": "BOOL", "unit": "none"}
        PfBitIn155 = {"name": "pfBitIn155", "type": "BOOL", "unit": "none"}
        PfBitIn156 = {"name": "pfBitIn156", "type": "BOOL", "unit": "none"}
        PfBitIn157 = {"name": "pfBitIn157", "type": "BOOL", "unit": "none"}
        PfBitIn158 = {"name": "pfBitIn158", "type": "BOOL", "unit": "none"}
        PfBitIn159 = {"name": "pfBitIn159", "type": "BOOL", "unit": "none"}
        PfBitIn160 = {"name": "pfBitIn160", "type": "BOOL", "unit": "none"}
        PfBitIn161 = {"name": "pfBitIn161", "type": "BOOL", "unit": "none"}
        PfBitIn162 = {"name": "pfBitIn162", "type": "BOOL", "unit": "none"}
        PfBitIn163 = {"name": "pfBitIn163", "type": "BOOL", "unit": "none"}
        PfBitIn164 = {"name": "pfBitIn164", "type": "BOOL", "unit": "none"}
        PfBitIn165 = {"name": "pfBitIn165", "type": "BOOL", "unit": "none"}
        PfBitIn166 = {"name": "pfBitIn166", "type": "BOOL", "unit": "none"}
        PfBitIn167 = {"name": "pfBitIn167", "type": "BOOL", "unit": "none"}
        PfBitIn168 = {"name": "pfBitIn168", "type": "BOOL", "unit": "none"}
        PfBitIn169 = {"name": "pfBitIn169", "type": "BOOL", "unit": "none"}
        PfBitIn170 = {"name": "pfBitIn170", "type": "BOOL", "unit": "none"}
        PfBitIn171 = {"name": "pfBitIn171", "type": "BOOL", "unit": "none"}
        PfBitIn172 = {"name": "pfBitIn172", "type": "BOOL", "unit": "none"}
        PfBitIn173 = {"name": "pfBitIn173", "type": "BOOL", "unit": "none"}
        PfBitIn174 = {"name": "pfBitIn174", "type": "BOOL", "unit": "none"}
        PfBitIn175 = {"name": "pfBitIn175", "type": "BOOL", "unit": "none"}
        PfBitIn176 = {"name": "pfBitIn176", "type": "BOOL", "unit": "none"}
        PfBitIn177 = {"name": "pfBitIn177", "type": "BOOL", "unit": "none"}
        PfBitIn178 = {"name": "pfBitIn178", "type": "BOOL", "unit": "none"}
        PfBitIn179 = {"name": "pfBitIn179", "type": "BOOL", "unit": "none"}
        PfBitIn180 = {"name": "pfBitIn180", "type": "BOOL", "unit": "none"}
        PfBitIn181 = {"name": "pfBitIn181", "type": "BOOL", "unit": "none"}
        PfBitIn182 = {"name": "pfBitIn182", "type": "BOOL", "unit": "none"}
        PfBitIn183 = {"name": "pfBitIn183", "type": "BOOL", "unit": "none"}
        PfBitIn184 = {"name": "pfBitIn184", "type": "BOOL", "unit": "none"}
        PfBitIn185 = {"name": "pfBitIn185", "type": "BOOL", "unit": "none"}
        PfBitIn186 = {"name": "pfBitIn186", "type": "BOOL", "unit": "none"}
        PfBitIn187 = {"name": "pfBitIn187", "type": "BOOL", "unit": "none"}
        PfBitIn188 = {"name": "pfBitIn188", "type": "BOOL", "unit": "none"}
        PfBitIn189 = {"name": "pfBitIn189", "type": "BOOL", "unit": "none"}
        PfBitIn190 = {"name": "pfBitIn190", "type": "BOOL", "unit": "none"}
        PfBitIn191 = {"name": "pfBitIn191", "type": "BOOL", "unit": "none"}
        PfBitIn192 = {"name": "pfBitIn192", "type": "BOOL", "unit": "none"}
        PfBitIn193 = {"name": "pfBitIn193", "type": "BOOL", "unit": "none"}
        PfBitIn194 = {"name": "pfBitIn194", "type": "BOOL", "unit": "none"}
        PfBitIn195 = {"name": "pfBitIn195", "type": "BOOL", "unit": "none"}
        PfBitIn196 = {"name": "pfBitIn196", "type": "BOOL", "unit": "none"}
        PfBitIn197 = {"name": "pfBitIn197", "type": "BOOL", "unit": "none"}
        PfBitIn198 = {"name": "pfBitIn198", "type": "BOOL", "unit": "none"}
        PfBitIn199 = {"name": "pfBitIn199", "type": "BOOL", "unit": "none"}
        PfBitIn200 = {"name": "pfBitIn200", "type": "BOOL", "unit": "none"}
        PfBitIn201 = {"name": "pfBitIn201", "type": "BOOL", "unit": "none"}
        PfBitIn202 = {"name": "pfBitIn202", "type": "BOOL", "unit": "none"}
        PfBitIn203 = {"name": "pfBitIn203", "type": "BOOL", "unit": "none"}
        PfBitIn204 = {"name": "pfBitIn204", "type": "BOOL", "unit": "none"}
        PfBitIn205 = {"name": "pfBitIn205", "type": "BOOL", "unit": "none"}
        PfBitIn206 = {"name": "pfBitIn206", "type": "BOOL", "unit": "none"}
        PfBitIn207 = {"name": "pfBitIn207", "type": "BOOL", "unit": "none"}
        PfBitIn208 = {"name": "pfBitIn208", "type": "BOOL", "unit": "none"}
        PfBitIn209 = {"name": "pfBitIn209", "type": "BOOL", "unit": "none"}
        PfBitIn210 = {"name": "pfBitIn210", "type": "BOOL", "unit": "none"}
        PfBitIn211 = {"name": "pfBitIn211", "type": "BOOL", "unit": "none"}
        PfBitIn212 = {"name": "pfBitIn212", "type": "BOOL", "unit": "none"}
        PfBitIn213 = {"name": "pfBitIn213", "type": "BOOL", "unit": "none"}
        PfBitIn214 = {"name": "pfBitIn214", "type": "BOOL", "unit": "none"}
        PfBitIn215 = {"name": "pfBitIn215", "type": "BOOL", "unit": "none"}
        PfBitIn216 = {"name": "pfBitIn216", "type": "BOOL", "unit": "none"}
        PfBitIn217 = {"name": "pfBitIn217", "type": "BOOL", "unit": "none"}
        PfBitIn218 = {"name": "pfBitIn218", "type": "BOOL", "unit": "none"}
        PfBitIn219 = {"name": "pfBitIn219", "type": "BOOL", "unit": "none"}
        PfBitIn220 = {"name": "pfBitIn220", "type": "BOOL", "unit": "none"}
        PfBitIn221 = {"name": "pfBitIn221", "type": "BOOL", "unit": "none"}
        PfBitIn222 = {"name": "pfBitIn222", "type": "BOOL", "unit": "none"}
        PfBitIn223 = {"name": "pfBitIn223", "type": "BOOL", "unit": "none"}
        PfBitIn224 = {"name": "pfBitIn224", "type": "BOOL", "unit": "none"}
        PfBitIn225 = {"name": "pfBitIn225", "type": "BOOL", "unit": "none"}
        PfBitIn226 = {"name": "pfBitIn226", "type": "BOOL", "unit": "none"}
        PfBitIn227 = {"name": "pfBitIn227", "type": "BOOL", "unit": "none"}
        PfBitIn228 = {"name": "pfBitIn228", "type": "BOOL", "unit": "none"}
        PfBitIn229 = {"name": "pfBitIn229", "type": "BOOL", "unit": "none"}
        PfBitIn230 = {"name": "pfBitIn230", "type": "BOOL", "unit": "none"}
        PfBitIn231 = {"name": "pfBitIn231", "type": "BOOL", "unit": "none"}
        PfBitIn232 = {"name": "pfBitIn232", "type": "BOOL", "unit": "none"}
        PfBitIn233 = {"name": "pfBitIn233", "type": "BOOL", "unit": "none"}
        PfBitIn234 = {"name": "pfBitIn234", "type": "BOOL", "unit": "none"}
        PfBitIn235 = {"name": "pfBitIn235", "type": "BOOL", "unit": "none"}
        PfBitIn236 = {"name": "pfBitIn236", "type": "BOOL", "unit": "none"}
        PfBitIn237 = {"name": "pfBitIn237", "type": "BOOL", "unit": "none"}
        PfBitIn238 = {"name": "pfBitIn238", "type": "BOOL", "unit": "none"}
        PfBitIn239 = {"name": "pfBitIn239", "type": "BOOL", "unit": "none"}
        PfBitIn240 = {"name": "pfBitIn240", "type": "BOOL", "unit": "none"}
        PfBitIn241 = {"name": "pfBitIn241", "type": "BOOL", "unit": "none"}
        PfBitIn242 = {"name": "pfBitIn242", "type": "BOOL", "unit": "none"}
        PfBitIn243 = {"name": "pfBitIn243", "type": "BOOL", "unit": "none"}
        PfBitIn244 = {"name": "pfBitIn244", "type": "BOOL", "unit": "none"}
        PfBitIn245 = {"name": "pfBitIn245", "type": "BOOL", "unit": "none"}
        PfBitIn246 = {"name": "pfBitIn246", "type": "BOOL", "unit": "none"}
        PfBitIn247 = {"name": "pfBitIn247", "type": "BOOL", "unit": "none"}
        PfBitIn248 = {"name": "pfBitIn248", "type": "BOOL", "unit": "none"}
        PfBitIn249 = {"name": "pfBitIn249", "type": "BOOL", "unit": "none"}
        PfBitIn250 = {"name": "pfBitIn250", "type": "BOOL", "unit": "none"}
        PfBitIn251 = {"name": "pfBitIn251", "type": "BOOL", "unit": "none"}
        PfBitIn252 = {"name": "pfBitIn252", "type": "BOOL", "unit": "none"}
        PfBitIn253 = {"name": "pfBitIn253", "type": "BOOL", "unit": "none"}
        PfBitIn254 = {"name": "pfBitIn254", "type": "BOOL", "unit": "none"}
        PfBitIn255 = {"name": "pfBitIn255", "type": "BOOL", "unit": "none"}

        PfIntIn0 = {"name": "pfIntIn0", "type": "INT", "unit": "none"}
        PfIntIn1 = {"name": "pfIntIn1", "type": "INT", "unit": "none"}
        PfIntIn2 = {"name": "pfIntIn2", "type": "INT", "unit": "none"}
        PfIntIn3 = {"name": "pfIntIn3", "type": "INT", "unit": "none"}
        PfIntIn4 = {"name": "pfIntIn4", "type": "INT", "unit": "none"}
        PfIntIn5 = {"name": "pfIntIn5", "type": "INT", "unit": "none"}
        PfIntIn6 = {"name": "pfIntIn6", "type": "INT", "unit": "none"}
        PfIntIn7 = {"name": "pfIntIn7", "type": "INT", "unit": "none"}

        PfFloatIn0 = {"name": "pfFloatIn0", "type": "DOUBLE", "unit": "none"}
        PfFloatIn1 = {"name": "pfFloatIn1", "type": "DOUBLE", "unit": "none"}
        PfFloatIn2 = {"name": "pfFloatIn2", "type": "DOUBLE", "unit": "none"}
        PfFloatIn3 = {"name": "pfFloatIn3", "type": "DOUBLE", "unit": "none"}
        PfFloatIn4 = {"name": "pfFloatIn4", "type": "DOUBLE", "unit": "none"}
        PfFloatIn5 = {"name": "pfFloatIn5", "type": "DOUBLE", "unit": "none"}
        PfFloatIn6 = {"name": "pfFloatIn6", "type": "DOUBLE", "unit": "none"}
        PfFloatIn7 = {"name": "pfFloatIn7", "type": "DOUBLE", "unit": "none"}

        PfBubDigitalOutputMask = {
            "name": "pfBubDigitalOutputMask",
            "type": "INT",
            "unit": "none",
        }
        PfBubDigitalOutput = {
            "name": "pfBubDigitalOutput",
            "type": "INT",
            "unit": "none",
        }

    class GPIOAnybus(Enum):
        ABBitIn0 = {"name": "aBBitIn0", "type": "BOOL", "unit": "none"}
        ABBitIn1 = {"name": "aBBitIn1", "type": "BOOL", "unit": "none"}
        ABBitIn2 = {"name": "aBBitIn2", "type": "BOOL", "unit": "none"}
        ABBitIn3 = {"name": "aBBitIn3", "type": "BOOL", "unit": "none"}
        ABBitIn4 = {"name": "aBBitIn4", "type": "BOOL", "unit": "none"}
        ABBitIn5 = {"name": "aBBitIn5", "type": "BOOL", "unit": "none"}
        ABBitIn6 = {"name": "aBBitIn6", "type": "BOOL", "unit": "none"}
        ABBitIn7 = {"name": "aBBitIn7", "type": "BOOL", "unit": "none"}
        ABBitIn8 = {"name": "aBBitIn8", "type": "BOOL", "unit": "none"}
        ABBitIn9 = {"name": "aBBitIn9", "type": "BOOL", "unit": "none"}
        ABBitIn10 = {"name": "aBBitIn10", "type": "BOOL", "unit": "none"}
        ABBitIn11 = {"name": "aBBitIn11", "type": "BOOL", "unit": "none"}
        ABBitIn12 = {"name": "aBBitIn12", "type": "BOOL", "unit": "none"}
        ABBitIn13 = {"name": "aBBitIn13", "type": "BOOL", "unit": "none"}
        ABBitIn14 = {"name": "aBBitIn14", "type": "BOOL", "unit": "none"}
        ABBitIn15 = {"name": "aBBitIn15", "type": "BOOL", "unit": "none"}
        ABBitIn16 = {"name": "aBBitIn16", "type": "BOOL", "unit": "none"}
        ABBitIn17 = {"name": "aBBitIn17", "type": "BOOL", "unit": "none"}
        ABBitIn18 = {"name": "aBBitIn18", "type": "BOOL", "unit": "none"}
        ABBitIn19 = {"name": "aBBitIn19", "type": "BOOL", "unit": "none"}
        ABBitIn20 = {"name": "aBBitIn20", "type": "BOOL", "unit": "none"}
        ABBitIn21 = {"name": "aBBitIn21", "type": "BOOL", "unit": "none"}
        ABBitIn22 = {"name": "aBBitIn22", "type": "BOOL", "unit": "none"}
        ABBitIn23 = {"name": "aBBitIn23", "type": "BOOL", "unit": "none"}
        ABBitIn24 = {"name": "aBBitIn24", "type": "BOOL", "unit": "none"}
        ABBitIn25 = {"name": "aBBitIn25", "type": "BOOL", "unit": "none"}
        ABBitIn26 = {"name": "aBBitIn26", "type": "BOOL", "unit": "none"}
        ABBitIn27 = {"name": "aBBitIn27", "type": "BOOL", "unit": "none"}
        ABBitIn28 = {"name": "aBBitIn28", "type": "BOOL", "unit": "none"}
        ABBitIn29 = {"name": "aBBitIn29", "type": "BOOL", "unit": "none"}
        ABBitIn30 = {"name": "aBBitIn30", "type": "BOOL", "unit": "none"}
        ABBitIn31 = {"name": "aBBitIn31", "type": "BOOL", "unit": "none"}
        ABBitIn32 = {"name": "aBBitIn32", "type": "BOOL", "unit": "none"}
        ABBitIn33 = {"name": "aBBitIn33", "type": "BOOL", "unit": "none"}
        ABBitIn34 = {"name": "aBBitIn34", "type": "BOOL", "unit": "none"}
        ABBitIn35 = {"name": "aBBitIn35", "type": "BOOL", "unit": "none"}
        ABBitIn36 = {"name": "aBBitIn36", "type": "BOOL", "unit": "none"}
        ABBitIn37 = {"name": "aBBitIn37", "type": "BOOL", "unit": "none"}
        ABBitIn38 = {"name": "aBBitIn38", "type": "BOOL", "unit": "none"}
        ABBitIn39 = {"name": "aBBitIn39", "type": "BOOL", "unit": "none"}
        ABBitIn40 = {"name": "aBBitIn40", "type": "BOOL", "unit": "none"}
        ABBitIn41 = {"name": "aBBitIn41", "type": "BOOL", "unit": "none"}
        ABBitIn42 = {"name": "aBBitIn42", "type": "BOOL", "unit": "none"}
        ABBitIn43 = {"name": "aBBitIn43", "type": "BOOL", "unit": "none"}
        ABBitIn44 = {"name": "aBBitIn44", "type": "BOOL", "unit": "none"}
        ABBitIn45 = {"name": "aBBitIn45", "type": "BOOL", "unit": "none"}
        ABBitIn46 = {"name": "aBBitIn46", "type": "BOOL", "unit": "none"}
        ABBitIn47 = {"name": "aBBitIn47", "type": "BOOL", "unit": "none"}
        ABBitIn48 = {"name": "aBBitIn48", "type": "BOOL", "unit": "none"}
        ABBitIn49 = {"name": "aBBitIn49", "type": "BOOL", "unit": "none"}
        ABBitIn50 = {"name": "aBBitIn50", "type": "BOOL", "unit": "none"}
        ABBitIn51 = {"name": "aBBitIn51", "type": "BOOL", "unit": "none"}
        ABBitIn52 = {"name": "aBBitIn52", "type": "BOOL", "unit": "none"}
        ABBitIn53 = {"name": "aBBitIn53", "type": "BOOL", "unit": "none"}
        ABBitIn54 = {"name": "aBBitIn54", "type": "BOOL", "unit": "none"}
        ABBitIn55 = {"name": "aBBitIn55", "type": "BOOL", "unit": "none"}
        ABBitIn56 = {"name": "aBBitIn56", "type": "BOOL", "unit": "none"}
        ABBitIn57 = {"name": "aBBitIn57", "type": "BOOL", "unit": "none"}
        ABBitIn58 = {"name": "aBBitIn58", "type": "BOOL", "unit": "none"}
        ABBitIn59 = {"name": "aBBitIn59", "type": "BOOL", "unit": "none"}
        ABBitIn60 = {"name": "aBBitIn60", "type": "BOOL", "unit": "none"}
        ABBitIn61 = {"name": "aBBitIn61", "type": "BOOL", "unit": "none"}
        ABBitIn62 = {"name": "aBBitIn62", "type": "BOOL", "unit": "none"}
        ABBitIn63 = {"name": "aBBitIn63", "type": "BOOL", "unit": "none"}
        ABBitIn64 = {"name": "aBBitIn64", "type": "BOOL", "unit": "none"}
        ABBitIn65 = {"name": "aBBitIn65", "type": "BOOL", "unit": "none"}
        ABBitIn66 = {"name": "aBBitIn66", "type": "BOOL", "unit": "none"}
        ABBitIn67 = {"name": "aBBitIn67", "type": "BOOL", "unit": "none"}
        ABBitIn68 = {"name": "aBBitIn68", "type": "BOOL", "unit": "none"}
        ABBitIn69 = {"name": "aBBitIn69", "type": "BOOL", "unit": "none"}
        ABBitIn70 = {"name": "aBBitIn70", "type": "BOOL", "unit": "none"}
        ABBitIn71 = {"name": "aBBitIn71", "type": "BOOL", "unit": "none"}
        ABBitIn72 = {"name": "aBBitIn72", "type": "BOOL", "unit": "none"}
        ABBitIn73 = {"name": "aBBitIn73", "type": "BOOL", "unit": "none"}
        ABBitIn74 = {"name": "aBBitIn74", "type": "BOOL", "unit": "none"}
        ABBitIn75 = {"name": "aBBitIn75", "type": "BOOL", "unit": "none"}
        ABBitIn76 = {"name": "aBBitIn76", "type": "BOOL", "unit": "none"}
        ABBitIn77 = {"name": "aBBitIn77", "type": "BOOL", "unit": "none"}
        ABBitIn78 = {"name": "aBBitIn78", "type": "BOOL", "unit": "none"}
        ABBitIn79 = {"name": "aBBitIn79", "type": "BOOL", "unit": "none"}
        ABBitIn80 = {"name": "aBBitIn80", "type": "BOOL", "unit": "none"}
        ABBitIn81 = {"name": "aBBitIn81", "type": "BOOL", "unit": "none"}
        ABBitIn82 = {"name": "aBBitIn82", "type": "BOOL", "unit": "none"}
        ABBitIn83 = {"name": "aBBitIn83", "type": "BOOL", "unit": "none"}
        ABBitIn84 = {"name": "aBBitIn84", "type": "BOOL", "unit": "none"}
        ABBitIn85 = {"name": "aBBitIn85", "type": "BOOL", "unit": "none"}
        ABBitIn86 = {"name": "aBBitIn86", "type": "BOOL", "unit": "none"}
        ABBitIn87 = {"name": "aBBitIn87", "type": "BOOL", "unit": "none"}
        ABBitIn88 = {"name": "aBBitIn88", "type": "BOOL", "unit": "none"}
        ABBitIn89 = {"name": "aBBitIn89", "type": "BOOL", "unit": "none"}
        ABBitIn90 = {"name": "aBBitIn90", "type": "BOOL", "unit": "none"}
        ABBitIn91 = {"name": "aBBitIn91", "type": "BOOL", "unit": "none"}
        ABBitIn92 = {"name": "aBBitIn92", "type": "BOOL", "unit": "none"}
        ABBitIn93 = {"name": "aBBitIn93", "type": "BOOL", "unit": "none"}
        ABBitIn94 = {"name": "aBBitIn94", "type": "BOOL", "unit": "none"}
        ABBitIn95 = {"name": "aBBitIn95", "type": "BOOL", "unit": "none"}
        ABBitIn96 = {"name": "aBBitIn96", "type": "BOOL", "unit": "none"}
        ABBitIn97 = {"name": "aBBitIn97", "type": "BOOL", "unit": "none"}
        ABBitIn98 = {"name": "aBBitIn98", "type": "BOOL", "unit": "none"}
        ABBitIn99 = {"name": "aBBitIn99", "type": "BOOL", "unit": "none"}
        ABBitIn100 = {"name": "aBBitIn100", "type": "BOOL", "unit": "none"}
        ABBitIn101 = {"name": "aBBitIn101", "type": "BOOL", "unit": "none"}
        ABBitIn102 = {"name": "aBBitIn102", "type": "BOOL", "unit": "none"}
        ABBitIn103 = {"name": "aBBitIn103", "type": "BOOL", "unit": "none"}
        ABBitIn104 = {"name": "aBBitIn104", "type": "BOOL", "unit": "none"}
        ABBitIn105 = {"name": "aBBitIn105", "type": "BOOL", "unit": "none"}
        ABBitIn106 = {"name": "aBBitIn106", "type": "BOOL", "unit": "none"}
        ABBitIn107 = {"name": "aBBitIn107", "type": "BOOL", "unit": "none"}
        ABBitIn108 = {"name": "aBBitIn108", "type": "BOOL", "unit": "none"}
        ABBitIn109 = {"name": "aBBitIn109", "type": "BOOL", "unit": "none"}
        ABBitIn110 = {"name": "aBBitIn110", "type": "BOOL", "unit": "none"}
        ABBitIn111 = {"name": "aBBitIn111", "type": "BOOL", "unit": "none"}
        ABBitIn112 = {"name": "aBBitIn112", "type": "BOOL", "unit": "none"}
        ABBitIn113 = {"name": "aBBitIn113", "type": "BOOL", "unit": "none"}
        ABBitIn114 = {"name": "aBBitIn114", "type": "BOOL", "unit": "none"}
        ABBitIn115 = {"name": "aBBitIn115", "type": "BOOL", "unit": "none"}
        ABBitIn116 = {"name": "aBBitIn116", "type": "BOOL", "unit": "none"}
        ABBitIn117 = {"name": "aBBitIn117", "type": "BOOL", "unit": "none"}
        ABBitIn118 = {"name": "aBBitIn118", "type": "BOOL", "unit": "none"}
        ABBitIn119 = {"name": "aBBitIn119", "type": "BOOL", "unit": "none"}
        ABBitIn120 = {"name": "aBBitIn120", "type": "BOOL", "unit": "none"}
        ABBitIn121 = {"name": "aBBitIn121", "type": "BOOL", "unit": "none"}
        ABBitIn122 = {"name": "aBBitIn122", "type": "BOOL", "unit": "none"}
        ABBitIn123 = {"name": "aBBitIn123", "type": "BOOL", "unit": "none"}
        ABBitIn124 = {"name": "aBBitIn124", "type": "BOOL", "unit": "none"}
        ABBitIn125 = {"name": "aBBitIn125", "type": "BOOL", "unit": "none"}
        ABBitIn126 = {"name": "aBBitIn126", "type": "BOOL", "unit": "none"}
        ABBitIn127 = {"name": "aBBitIn127", "type": "BOOL", "unit": "none"}
        ABBitIn128 = {"name": "aBBitIn128", "type": "BOOL", "unit": "none"}
        ABBitIn129 = {"name": "aBBitIn129", "type": "BOOL", "unit": "none"}
        ABBitIn130 = {"name": "aBBitIn130", "type": "BOOL", "unit": "none"}
        ABBitIn131 = {"name": "aBBitIn131", "type": "BOOL", "unit": "none"}
        ABBitIn132 = {"name": "aBBitIn132", "type": "BOOL", "unit": "none"}
        ABBitIn133 = {"name": "aBBitIn133", "type": "BOOL", "unit": "none"}
        ABBitIn134 = {"name": "aBBitIn134", "type": "BOOL", "unit": "none"}
        ABBitIn135 = {"name": "aBBitIn135", "type": "BOOL", "unit": "none"}
        ABBitIn136 = {"name": "aBBitIn136", "type": "BOOL", "unit": "none"}
        ABBitIn137 = {"name": "aBBitIn137", "type": "BOOL", "unit": "none"}
        ABBitIn138 = {"name": "aBBitIn138", "type": "BOOL", "unit": "none"}
        ABBitIn139 = {"name": "aBBitIn139", "type": "BOOL", "unit": "none"}
        ABBitIn140 = {"name": "aBBitIn140", "type": "BOOL", "unit": "none"}
        ABBitIn141 = {"name": "aBBitIn141", "type": "BOOL", "unit": "none"}
        ABBitIn142 = {"name": "aBBitIn142", "type": "BOOL", "unit": "none"}
        ABBitIn143 = {"name": "aBBitIn143", "type": "BOOL", "unit": "none"}
        ABBitIn144 = {"name": "aBBitIn144", "type": "BOOL", "unit": "none"}
        ABBitIn145 = {"name": "aBBitIn145", "type": "BOOL", "unit": "none"}
        ABBitIn146 = {"name": "aBBitIn146", "type": "BOOL", "unit": "none"}
        ABBitIn147 = {"name": "aBBitIn147", "type": "BOOL", "unit": "none"}
        ABBitIn148 = {"name": "aBBitIn148", "type": "BOOL", "unit": "none"}
        ABBitIn149 = {"name": "aBBitIn149", "type": "BOOL", "unit": "none"}
        ABBitIn150 = {"name": "aBBitIn150", "type": "BOOL", "unit": "none"}
        ABBitIn151 = {"name": "aBBitIn151", "type": "BOOL", "unit": "none"}
        ABBitIn152 = {"name": "aBBitIn152", "type": "BOOL", "unit": "none"}
        ABBitIn153 = {"name": "aBBitIn153", "type": "BOOL", "unit": "none"}
        ABBitIn154 = {"name": "aBBitIn154", "type": "BOOL", "unit": "none"}
        ABBitIn155 = {"name": "aBBitIn155", "type": "BOOL", "unit": "none"}
        ABBitIn156 = {"name": "aBBitIn156", "type": "BOOL", "unit": "none"}
        ABBitIn157 = {"name": "aBBitIn157", "type": "BOOL", "unit": "none"}
        ABBitIn158 = {"name": "aBBitIn158", "type": "BOOL", "unit": "none"}
        ABBitIn159 = {"name": "aBBitIn159", "type": "BOOL", "unit": "none"}
        ABBitIn160 = {"name": "aBBitIn160", "type": "BOOL", "unit": "none"}
        ABBitIn161 = {"name": "aBBitIn161", "type": "BOOL", "unit": "none"}
        ABBitIn162 = {"name": "aBBitIn162", "type": "BOOL", "unit": "none"}
        ABBitIn163 = {"name": "aBBitIn163", "type": "BOOL", "unit": "none"}
        ABBitIn164 = {"name": "aBBitIn164", "type": "BOOL", "unit": "none"}
        ABBitIn165 = {"name": "aBBitIn165", "type": "BOOL", "unit": "none"}
        ABBitIn166 = {"name": "aBBitIn166", "type": "BOOL", "unit": "none"}
        ABBitIn167 = {"name": "aBBitIn167", "type": "BOOL", "unit": "none"}
        ABBitIn168 = {"name": "aBBitIn168", "type": "BOOL", "unit": "none"}
        ABBitIn169 = {"name": "aBBitIn169", "type": "BOOL", "unit": "none"}
        ABBitIn170 = {"name": "aBBitIn170", "type": "BOOL", "unit": "none"}
        ABBitIn171 = {"name": "aBBitIn171", "type": "BOOL", "unit": "none"}
        ABBitIn172 = {"name": "aBBitIn172", "type": "BOOL", "unit": "none"}
        ABBitIn173 = {"name": "aBBitIn173", "type": "BOOL", "unit": "none"}
        ABBitIn174 = {"name": "aBBitIn174", "type": "BOOL", "unit": "none"}
        ABBitIn175 = {"name": "aBBitIn175", "type": "BOOL", "unit": "none"}
        ABBitIn176 = {"name": "aBBitIn176", "type": "BOOL", "unit": "none"}
        ABBitIn177 = {"name": "aBBitIn177", "type": "BOOL", "unit": "none"}
        ABBitIn178 = {"name": "aBBitIn178", "type": "BOOL", "unit": "none"}
        ABBitIn179 = {"name": "aBBitIn179", "type": "BOOL", "unit": "none"}
        ABBitIn180 = {"name": "aBBitIn180", "type": "BOOL", "unit": "none"}
        ABBitIn181 = {"name": "aBBitIn181", "type": "BOOL", "unit": "none"}
        ABBitIn182 = {"name": "aBBitIn182", "type": "BOOL", "unit": "none"}
        ABBitIn183 = {"name": "aBBitIn183", "type": "BOOL", "unit": "none"}
        ABBitIn184 = {"name": "aBBitIn184", "type": "BOOL", "unit": "none"}
        ABBitIn185 = {"name": "aBBitIn185", "type": "BOOL", "unit": "none"}
        ABBitIn186 = {"name": "aBBitIn186", "type": "BOOL", "unit": "none"}
        ABBitIn187 = {"name": "aBBitIn187", "type": "BOOL", "unit": "none"}
        ABBitIn188 = {"name": "aBBitIn188", "type": "BOOL", "unit": "none"}
        ABBitIn189 = {"name": "aBBitIn189", "type": "BOOL", "unit": "none"}
        ABBitIn190 = {"name": "aBBitIn190", "type": "BOOL", "unit": "none"}
        ABBitIn191 = {"name": "aBBitIn191", "type": "BOOL", "unit": "none"}
        ABBitIn192 = {"name": "aBBitIn192", "type": "BOOL", "unit": "none"}
        ABBitIn193 = {"name": "aBBitIn193", "type": "BOOL", "unit": "none"}
        ABBitIn194 = {"name": "aBBitIn194", "type": "BOOL", "unit": "none"}
        ABBitIn195 = {"name": "aBBitIn195", "type": "BOOL", "unit": "none"}
        ABBitIn196 = {"name": "aBBitIn196", "type": "BOOL", "unit": "none"}
        ABBitIn197 = {"name": "aBBitIn197", "type": "BOOL", "unit": "none"}
        ABBitIn198 = {"name": "aBBitIn198", "type": "BOOL", "unit": "none"}
        ABBitIn199 = {"name": "aBBitIn199", "type": "BOOL", "unit": "none"}
        ABBitIn200 = {"name": "aBBitIn200", "type": "BOOL", "unit": "none"}
        ABBitIn201 = {"name": "aBBitIn201", "type": "BOOL", "unit": "none"}
        ABBitIn202 = {"name": "aBBitIn202", "type": "BOOL", "unit": "none"}
        ABBitIn203 = {"name": "aBBitIn203", "type": "BOOL", "unit": "none"}
        ABBitIn204 = {"name": "aBBitIn204", "type": "BOOL", "unit": "none"}
        ABBitIn205 = {"name": "aBBitIn205", "type": "BOOL", "unit": "none"}
        ABBitIn206 = {"name": "aBBitIn206", "type": "BOOL", "unit": "none"}
        ABBitIn207 = {"name": "aBBitIn207", "type": "BOOL", "unit": "none"}
        ABBitIn208 = {"name": "aBBitIn208", "type": "BOOL", "unit": "none"}
        ABBitIn209 = {"name": "aBBitIn209", "type": "BOOL", "unit": "none"}
        ABBitIn210 = {"name": "aBBitIn210", "type": "BOOL", "unit": "none"}
        ABBitIn211 = {"name": "aBBitIn211", "type": "BOOL", "unit": "none"}
        ABBitIn212 = {"name": "aBBitIn212", "type": "BOOL", "unit": "none"}
        ABBitIn213 = {"name": "aBBitIn213", "type": "BOOL", "unit": "none"}
        ABBitIn214 = {"name": "aBBitIn214", "type": "BOOL", "unit": "none"}
        ABBitIn215 = {"name": "aBBitIn215", "type": "BOOL", "unit": "none"}
        ABBitIn216 = {"name": "aBBitIn216", "type": "BOOL", "unit": "none"}
        ABBitIn217 = {"name": "aBBitIn217", "type": "BOOL", "unit": "none"}
        ABBitIn218 = {"name": "aBBitIn218", "type": "BOOL", "unit": "none"}
        ABBitIn219 = {"name": "aBBitIn219", "type": "BOOL", "unit": "none"}
        ABBitIn220 = {"name": "aBBitIn220", "type": "BOOL", "unit": "none"}
        ABBitIn221 = {"name": "aBBitIn221", "type": "BOOL", "unit": "none"}
        ABBitIn222 = {"name": "aBBitIn222", "type": "BOOL", "unit": "none"}
        ABBitIn223 = {"name": "aBBitIn223", "type": "BOOL", "unit": "none"}
        ABBitIn224 = {"name": "aBBitIn224", "type": "BOOL", "unit": "none"}
        ABBitIn225 = {"name": "aBBitIn225", "type": "BOOL", "unit": "none"}
        ABBitIn226 = {"name": "aBBitIn226", "type": "BOOL", "unit": "none"}
        ABBitIn227 = {"name": "aBBitIn227", "type": "BOOL", "unit": "none"}
        ABBitIn228 = {"name": "aBBitIn228", "type": "BOOL", "unit": "none"}
        ABBitIn229 = {"name": "aBBitIn229", "type": "BOOL", "unit": "none"}
        ABBitIn230 = {"name": "aBBitIn230", "type": "BOOL", "unit": "none"}
        ABBitIn231 = {"name": "aBBitIn231", "type": "BOOL", "unit": "none"}
        ABBitIn232 = {"name": "aBBitIn232", "type": "BOOL", "unit": "none"}
        ABBitIn233 = {"name": "aBBitIn233", "type": "BOOL", "unit": "none"}
        ABBitIn234 = {"name": "aBBitIn234", "type": "BOOL", "unit": "none"}
        ABBitIn235 = {"name": "aBBitIn235", "type": "BOOL", "unit": "none"}
        ABBitIn236 = {"name": "aBBitIn236", "type": "BOOL", "unit": "none"}
        ABBitIn237 = {"name": "aBBitIn237", "type": "BOOL", "unit": "none"}
        ABBitIn238 = {"name": "aBBitIn238", "type": "BOOL", "unit": "none"}
        ABBitIn239 = {"name": "aBBitIn239", "type": "BOOL", "unit": "none"}
        ABBitIn240 = {"name": "aBBitIn240", "type": "BOOL", "unit": "none"}
        ABBitIn241 = {"name": "aBBitIn241", "type": "BOOL", "unit": "none"}
        ABBitIn242 = {"name": "aBBitIn242", "type": "BOOL", "unit": "none"}
        ABBitIn243 = {"name": "aBBitIn243", "type": "BOOL", "unit": "none"}
        ABBitIn244 = {"name": "aBBitIn244", "type": "BOOL", "unit": "none"}
        ABBitIn245 = {"name": "aBBitIn245", "type": "BOOL", "unit": "none"}
        ABBitIn246 = {"name": "aBBitIn246", "type": "BOOL", "unit": "none"}
        ABBitIn247 = {"name": "aBBitIn247", "type": "BOOL", "unit": "none"}
        ABBitIn248 = {"name": "aBBitIn248", "type": "BOOL", "unit": "none"}
        ABBitIn249 = {"name": "aBBitIn249", "type": "BOOL", "unit": "none"}
        ABBitIn250 = {"name": "aBBitIn250", "type": "BOOL", "unit": "none"}
        ABBitIn251 = {"name": "aBBitIn251", "type": "BOOL", "unit": "none"}
        ABBitIn252 = {"name": "aBBitIn252", "type": "BOOL", "unit": "none"}
        ABBitIn253 = {"name": "aBBitIn253", "type": "BOOL", "unit": "none"}
        ABBitIn254 = {"name": "aBBitIn254", "type": "BOOL", "unit": "none"}
        ABBitIn255 = {"name": "aBBitIn255", "type": "BOOL", "unit": "none"}

        ABIntIn0 = {"name": "aBIntIn0", "type": "BOOL", "unit": "none"}
        ABIntIn1 = {"name": "aBIntIn1", "type": "BOOL", "unit": "none"}
        ABIntIn2 = {"name": "aBIntIn2", "type": "BOOL", "unit": "none"}
        ABIntIn3 = {"name": "aBIntIn3", "type": "BOOL", "unit": "none"}
        ABIntIn4 = {"name": "aBIntIn4", "type": "BOOL", "unit": "none"}
        ABIntIn5 = {"name": "aBIntIn5", "type": "BOOL", "unit": "none"}
        ABIntIn6 = {"name": "aBIntIn6", "type": "BOOL", "unit": "none"}
        ABIntIn7 = {"name": "aBIntIn7", "type": "BOOL", "unit": "none"}
        ABIntIn8 = {"name": "aBIntIn8", "type": "BOOL", "unit": "none"}
        ABIntIn9 = {"name": "aBIntIn9", "type": "BOOL", "unit": "none"}
        ABIntIn10 = {"name": "aBIntIn10", "type": "BOOL", "unit": "none"}
        ABIntIn11 = {"name": "aBIntIn11", "type": "BOOL", "unit": "none"}
        ABIntIn12 = {"name": "aBIntIn12", "type": "BOOL", "unit": "none"}
        ABIntIn13 = {"name": "aBIntIn13", "type": "BOOL", "unit": "none"}
        ABIntIn14 = {"name": "aBIntIn14", "type": "BOOL", "unit": "none"}
        ABIntIn15 = {"name": "aBIntIn15", "type": "BOOL", "unit": "none"}
        ABIntIn16 = {"name": "aBIntIn16", "type": "BOOL", "unit": "none"}
        ABIntIn17 = {"name": "aBIntIn17", "type": "BOOL", "unit": "none"}
        ABIntIn18 = {"name": "aBIntIn18", "type": "BOOL", "unit": "none"}
        ABIntIn19 = {"name": "aBIntIn19", "type": "BOOL", "unit": "none"}
        ABIntIn20 = {"name": "aBIntIn20", "type": "BOOL", "unit": "none"}
        ABIntIn21 = {"name": "aBIntIn21", "type": "BOOL", "unit": "none"}
        ABIntIn22 = {"name": "aBIntIn22", "type": "BOOL", "unit": "none"}
        ABIntIn23 = {"name": "aBIntIn23", "type": "BOOL", "unit": "none"}
        ABIntIn24 = {"name": "aBIntIn24", "type": "BOOL", "unit": "none"}
        ABIntIn25 = {"name": "aBIntIn25", "type": "BOOL", "unit": "none"}
        ABIntIn26 = {"name": "aBIntIn26", "type": "BOOL", "unit": "none"}
        ABIntIn27 = {"name": "aBIntIn27", "type": "BOOL", "unit": "none"}
        ABIntIn28 = {"name": "aBIntIn28", "type": "BOOL", "unit": "none"}
        ABIntIn29 = {"name": "aBIntIn29", "type": "BOOL", "unit": "none"}
        ABIntIn30 = {"name": "aBIntIn30", "type": "BOOL", "unit": "none"}
        ABIntIn31 = {"name": "aBIntIn31", "type": "BOOL", "unit": "none"}

        ABFloatIn0 = {"name": "aBFloatIn0", "type": "BOOL", "unit": "none"}
        ABFloatIn1 = {"name": "aBFloatIn1", "type": "BOOL", "unit": "none"}
        ABFloatIn2 = {"name": "aBFloatIn2", "type": "BOOL", "unit": "none"}
        ABFloatIn3 = {"name": "aBFloatIn3", "type": "BOOL", "unit": "none"}
        ABFloatIn4 = {"name": "aBFloatIn4", "type": "BOOL", "unit": "none"}
        ABFloatIn5 = {"name": "aBFloatIn5", "type": "BOOL", "unit": "none"}
        ABFloatIn6 = {"name": "aBFloatIn6", "type": "BOOL", "unit": "none"}
        ABFloatIn7 = {"name": "aBFloatIn7", "type": "BOOL", "unit": "none"}
        ABFloatIn8 = {"name": "aBFloatIn8", "type": "BOOL", "unit": "none"}
        ABFloatIn9 = {"name": "aBFloatIn9", "type": "BOOL", "unit": "none"}
        ABFloatIn10 = {"name": "aBFloatIn10", "type": "BOOL", "unit": "none"}
        ABFloatIn11 = {"name": "aBFloatIn11", "type": "BOOL", "unit": "none"}
        ABFloatIn12 = {"name": "aBFloatIn12", "type": "BOOL", "unit": "none"}
        ABFloatIn13 = {"name": "aBFloatIn13", "type": "BOOL", "unit": "none"}
        ABFloatIn14 = {"name": "aBFloatIn14", "type": "BOOL", "unit": "none"}
        ABFloatIn15 = {"name": "aBFloatIn15", "type": "BOOL", "unit": "none"}
        ABFloatIn16 = {"name": "aBFloatIn16", "type": "BOOL", "unit": "none"}
        ABFloatIn17 = {"name": "aBFloatIn17", "type": "BOOL", "unit": "none"}
        ABFloatIn18 = {"name": "aBFloatIn18", "type": "BOOL", "unit": "none"}
        ABFloatIn19 = {"name": "aBFloatIn19", "type": "BOOL", "unit": "none"}
        ABFloatIn20 = {"name": "aBFloatIn20", "type": "BOOL", "unit": "none"}
        ABFloatIn21 = {"name": "aBFloatIn21", "type": "BOOL", "unit": "none"}
        ABFloatIn22 = {"name": "aBFloatIn22", "type": "BOOL", "unit": "none"}
        ABFloatIn23 = {"name": "aBFloatIn23", "type": "BOOL", "unit": "none"}
        ABFloatIn24 = {"name": "aBFloatIn24", "type": "BOOL", "unit": "none"}
        ABFloatIn25 = {"name": "aBFloatIn25", "type": "BOOL", "unit": "none"}
        ABFloatIn26 = {"name": "aBFloatIn26", "type": "BOOL", "unit": "none"}
        ABFloatIn27 = {"name": "aBFloatIn27", "type": "BOOL", "unit": "none"}
        ABFloatIn28 = {"name": "aBFloatIn28", "type": "BOOL", "unit": "none"}
        ABFloatIn29 = {"name": "aBFloatIn29", "type": "BOOL", "unit": "none"}
        ABFloatIn30 = {"name": "aBFloatIn30", "type": "BOOL", "unit": "none"}
        ABFloatIn31 = {"name": "aBFloatIn31", "type": "BOOL", "unit": "none"}


class ParameterTypeValueEnum:
    class PrimitiveValue:
        class ForceHybrid:
            class ZoneRadius(Enum):
                ZFine = "ZFine"
                Z1 = "Z1"
                Z5 = "Z5"
                Z10 = "Z10"
                Z15 = "Z15"
                Z20 = "Z20"
                Z30 = "Z30"
                Z40 = "Z40"
                Z50 = "Z50"
                Z60 = "Z60"
                Z80 = "Z80"
                Z100 = "Z100"
                Z150 = "Z150"
                Z200 = "Z200"

        class ForceComp:
            class ZoneRadius(Enum):
                ZFine = "ZFine"
                Z1 = "Z1"
                Z5 = "Z5"
                Z10 = "Z10"
                Z15 = "Z15"
                Z20 = "Z20"
                Z30 = "Z30"
                Z40 = "Z40"
                Z50 = "Z50"
                Z60 = "Z60"
                Z80 = "Z80"
                Z100 = "Z100"
                Z150 = "Z150"
                Z200 = "Z200"

        class Contact:
            class ContactCoord(Enum):
                World = "world"
                TCP = "tcp"

            class ZoneRadius(Enum):
                ZFine = "ZFine"
                Z1 = "Z1"
                Z5 = "Z5"
                Z10 = "Z10"
                Z15 = "Z15"
                Z20 = "Z20"
                Z30 = "Z30"
                Z40 = "Z40"
                Z50 = "Z50"
                Z60 = "Z60"
                Z80 = "Z80"
                Z100 = "Z100"
                Z150 = "Z150"
                Z200 = "Z200"

        class MoveComp:
            class ZoneRadius(Enum):
                ZFine = "ZFine"
                Z1 = "Z1"
                Z5 = "Z5"
                Z10 = "Z10"
                Z15 = "Z15"
                Z20 = "Z20"
                Z30 = "Z30"
                Z40 = "Z40"
                Z50 = "Z50"
                Z60 = "Z60"
                Z80 = "Z80"
                Z100 = "Z100"
                Z150 = "Z150"
                Z200 = "Z200"

        class SearchHole:
            class SearchPattern(Enum):
                Spiral = "SPIRAL"
                Zigzag = "ZIGZAG"

        class InsertComp:
            class InsertAxis(Enum):
                PositiveX = "X"
                NegativeX = "-X"
                PositiveY = "Y"
                NegativeY = "-Y"
                PositiveZ = "Z"
                NegativeZ = "-Z"

        class FastenScrew:
            class InsertDir(Enum):
                PositiveX = "X"
                NegativeX = "-X"
                PositiveY = "Y"
                NegativeY = "-Y"
                PositiveZ = "Z"
                NegativeZ = "-Z"

            class DiScrewInHole(Enum):
                NONE = "NONE"
                GPIOIn0 = "gpioIn0"
                GPIOIn1 = "gpioIn1"
                GPIOIn2 = "gpioIn2"
                GPIOIn3 = "gpioIn3"
                GPIOIn4 = "gpioIn4"
                GPIOIn5 = "gpioIn5"
                GPIOIn6 = "gpioIn6"
                GPIOIn7 = "gpioIn7"
                GPIOIn8 = "gpioIn8"
                GPIOIn9 = "gpioIn9"
                GPIOIn10 = "gpioIn10"
                GPIOIn11 = "gpioIn11"
                GPIOIn12 = "gpioIn12"
                GPIOIn13 = "gpioIn13"
                GPIOIn14 = "gpioIn14"
                GPIOIn15 = "gpioIn15"
                ModbusIn0 = "modbusIn0"
                ModbusIn1 = "modbusIn1"
                ModbusIn2 = "modbusIn2"
                ModbusIn3 = "modbusIn3"
                ModbusIn4 = "modbusIn4"
                ModbusIn5 = "modbusIn5"
                ModbusIn6 = "modbusIn6"
                ModbusIn7 = "modbusIn7"
                ModbusIn8 = "modbusIn8"
                ModbusIn9 = "modbusIn9"
                ModbusIn10 = "modbusIn10"
                ModbusIn11 = "modbusIn11"
                ModbusIn12 = "modbusIn12"
                ModbusIn13 = "modbusIn13"
                ModbusIn14 = "modbusIn14"
                ModbusIn15 = "modbusIn15"

            class DiFastenFinish(Enum):
                NONE = "NONE"
                GPIOIn0 = "gpioIn0"
                GPIOIn1 = "gpioIn1"
                GPIOIn2 = "gpioIn2"
                GPIOIn3 = "gpioIn3"
                GPIOIn4 = "gpioIn4"
                GPIOIn5 = "gpioIn5"
                GPIOIn6 = "gpioIn6"
                GPIOIn7 = "gpioIn7"
                GPIOIn8 = "gpioIn8"
                GPIOIn9 = "gpioIn9"
                GPIOIn10 = "gpioIn10"
                GPIOIn11 = "gpioIn11"
                GPIOIn12 = "gpioIn12"
                GPIOIn13 = "gpioIn13"
                GPIOIn14 = "gpioIn14"
                GPIOIn15 = "gpioIn15"
                ModbusIn0 = "modbusIn0"
                ModbusIn1 = "modbusIn1"
                ModbusIn2 = "modbusIn2"
                ModbusIn3 = "modbusIn3"
                ModbusIn4 = "modbusIn4"
                ModbusIn5 = "modbusIn5"
                ModbusIn6 = "modbusIn6"
                ModbusIn7 = "modbusIn7"
                ModbusIn8 = "modbusIn8"
                ModbusIn9 = "modbusIn9"
                ModbusIn10 = "modbusIn10"
                ModbusIn11 = "modbusIn11"
                ModbusIn12 = "modbusIn12"
                ModbusIn13 = "modbusIn13"
                ModbusIn14 = "modbusIn14"
                ModbusIn15 = "modbusIn15"

            class DiScrewJam(Enum):
                NONE = "NONE"
                GPIOIn0 = "gpioIn0"
                GPIOIn1 = "gpioIn1"
                GPIOIn2 = "gpioIn2"
                GPIOIn3 = "gpioIn3"
                GPIOIn4 = "gpioIn4"
                GPIOIn5 = "gpioIn5"
                GPIOIn6 = "gpioIn6"
                GPIOIn7 = "gpioIn7"
                GPIOIn8 = "gpioIn8"
                GPIOIn9 = "gpioIn9"
                GPIOIn10 = "gpioIn10"
                GPIOIn11 = "gpioIn11"
                GPIOIn12 = "gpioIn12"
                GPIOIn13 = "gpioIn13"
                GPIOIn14 = "gpioIn14"
                GPIOIn15 = "gpioIn15"
                ModbusIn0 = "modbusIn0"
                ModbusIn1 = "modbusIn1"
                ModbusIn2 = "modbusIn2"
                ModbusIn3 = "modbusIn3"
                ModbusIn4 = "modbusIn4"
                ModbusIn5 = "modbusIn5"
                ModbusIn6 = "modbusIn6"
                ModbusIn7 = "modbusIn7"
                ModbusIn8 = "modbusIn8"
                ModbusIn9 = "modbusIn9"
                ModbusIn10 = "modbusIn10"
                ModbusIn11 = "modbusIn11"
                ModbusIn12 = "modbusIn12"
                ModbusIn13 = "modbusIn13"
                ModbusIn14 = "modbusIn14"
                ModbusIn15 = "modbusIn15"

        class MoveJ:
            class ZoneRadius(Enum):
                ZFine = "ZFine"
                Z5 = "Z5"
                Z10 = "Z10"
                Z15 = "Z15"
                Z20 = "Z20"
                Z30 = "Z30"
                Z40 = "Z40"
                Z50 = "Z50"
                Z60 = "Z60"
                Z80 = "Z80"
                Z100 = "Z100"
                Z150 = "Z150"
                Z200 = "Z200"
                ZSpline = "ZSpline"

        class MoveL:
            class ZoneRadius(Enum):
                ZFine = "ZFine"
                Z1 = "Z1"
                Z5 = "Z5"
                Z10 = "Z10"
                Z15 = "Z15"
                Z20 = "Z20"
                Z30 = "Z30"
                Z40 = "Z40"
                Z50 = "Z50"
                Z60 = "Z60"
                Z80 = "Z80"
                Z100 = "Z100"
                Z150 = "Z150"
                Z200 = "Z200"

        class MovePTP:
            class ZoneRadius(Enum):
                ZFine = "ZFine"
                Z5 = "Z5"
                Z10 = "Z10"
                Z15 = "Z15"
                Z20 = "Z20"
                Z30 = "Z30"
                Z40 = "Z40"
                Z50 = "Z50"
                Z60 = "Z60"
                Z80 = "Z80"
                Z100 = "Z100"
                Z150 = "Z150"
                Z200 = "Z200"
                ZSpline = "ZSpline"

        class FloatingCartesian:
            class DiEnableFloating(Enum):
                NONE = "NONE"
                GPIOIn0 = "gpioIn0"
                GPIOIn1 = "gpioIn1"
                GPIOIn2 = "gpioIn2"
                GPIOIn3 = "gpioIn3"
                GPIOIn4 = "gpioIn4"
                GPIOIn5 = "gpioIn5"
                GPIOIn6 = "gpioIn6"
                GPIOIn7 = "gpioIn7"
                GPIOIn8 = "gpioIn8"
                GPIOIn9 = "gpioIn9"
                GPIOIn10 = "gpioIn10"
                GPIOIn11 = "gpioIn11"
                GPIOIn12 = "gpioIn12"
                GPIOIn13 = "gpioIn13"
                GPIOIn14 = "gpioIn14"
                GPIOIn15 = "gpioIn15"
                ModbusIn0 = "modbusIn0"
                ModbusIn1 = "modbusIn1"
                ModbusIn2 = "modbusIn2"
                ModbusIn3 = "modbusIn3"
                ModbusIn4 = "modbusIn4"
                ModbusIn5 = "modbusIn5"
                ModbusIn6 = "modbusIn6"
                ModbusIn7 = "modbusIn7"
                ModbusIn8 = "modbusIn8"
                ModbusIn9 = "modbusIn9"
                ModbusIn10 = "modbusIn10"
                ModbusIn11 = "modbusIn11"
                ModbusIn12 = "modbusIn12"
                ModbusIn13 = "modbusIn13"
                ModbusIn14 = "modbusIn14"
                ModbusIn15 = "modbusIn15"

        class FloatingJoint:
            class DiEnableFloating(Enum):
                NONE = "NONE"
                GPIOIn0 = "gpioIn0"
                GPIOIn1 = "gpioIn1"
                GPIOIn2 = "gpioIn2"
                GPIOIn3 = "gpioIn3"
                GPIOIn4 = "gpioIn4"
                GPIOIn5 = "gpioIn5"
                GPIOIn6 = "gpioIn6"
                GPIOIn7 = "gpioIn7"
                GPIOIn8 = "gpioIn8"
                GPIOIn9 = "gpioIn9"
                GPIOIn10 = "gpioIn10"
                GPIOIn11 = "gpioIn11"
                GPIOIn12 = "gpioIn12"
                GPIOIn13 = "gpioIn13"
                GPIOIn14 = "gpioIn14"
                GPIOIn15 = "gpioIn15"
                ModbusIn0 = "modbusIn0"
                ModbusIn1 = "modbusIn1"
                ModbusIn2 = "modbusIn2"
                ModbusIn3 = "modbusIn3"
                ModbusIn4 = "modbusIn4"
                ModbusIn5 = "modbusIn5"
                ModbusIn6 = "modbusIn6"
                ModbusIn7 = "modbusIn7"
                ModbusIn8 = "modbusIn8"
                ModbusIn9 = "modbusIn9"
                ModbusIn10 = "modbusIn10"
                ModbusIn11 = "modbusIn11"
                ModbusIn12 = "modbusIn12"
                ModbusIn13 = "modbusIn13"
                ModbusIn14 = "modbusIn14"
                ModbusIn15 = "modbusIn15"

        class Polish:
            class ILCEnableType(Enum):
                ILC_Disable = "ILC_Disable"
                ILC_Enable = "ILC_Enable"
                ILC_Training = "ILC_Training"
                ILC_Restart = "ILC_Restart"

        class Grind:
            class ILCEnableType(Enum):
                ILC_Disable = "ILC_Disable"
                ILC_Enable = "ILC_Enable"
                ILC_Training = "ILC_Training"
                ILC_Restart = "ILC_Restart"

        class PolishECP:
            class ILCEnableType(Enum):
                ILC_Disable = "ILC_Disable"
                ILC_Enable = "ILC_Enable"
                ILC_Training = "ILC_Training"
                ILC_Restart = "ILC_Restart"

        class GrindECP:
            class ILCEnableType(Enum):
                ILC_Disable = "ILC_Disable"
                ILC_Enable = "ILC_Enable"
                ILC_Training = "ILC_Training"
                ILC_Restart = "ILC_Restart"

        class LocatePin:
            class InsertDir(Enum):
                PositiveX = "X"
                NegativeX = "-X"
                PositiveY = "Y"
                NegativeY = "-Y"
                PositiveZ = "Z"
                NegativeZ = "-Z"

        class GraspComp:
            class GripperType(Enum):
                GripperDahuan = "GripperDahuan"
                GripperDahuanModbus = "GripperDahuanModbus"
                FlexivGN01 = "Flexiv-GN01"
                GripperFlexivModbus = "GripperFlexivModbus"
                Robotiq2F85 = "Robotiq-2F-85"
                RobotiqHandE = "Robotiq-Hand-E"

        class Massage:
            class ZoneRadisu(Enum):
                ZFine = "ZFine"
                Z1 = "Z1"
                Z5 = "Z5"
                Z10 = "Z10"
                Z15 = "Z15"
                Z20 = "Z20"
                Z30 = "Z30"
                Z40 = "Z40"
                Z50 = "Z50"
                Z60 = "Z60"
                Z80 = "Z80"
                Z100 = "Z100"
                Z150 = "Z150"
                Z200 = "Z200"
                ZSpline = "ZSpline"

        class BalanceBall:
            class PattenType(Enum):
                Circle = "CIRCLE"
                Infshape = "INFSHAPE"

        class SyncStart:
            class SyncDevice(Enum):
                ConveyorModbusTCP1 = "Conveyor-ModbusTCP-1"
                ConveyorModbusTCP2 = "Conveyor-ModbusTCP-2"
                ConveyorModbusTCP3 = "Conveyor-ModbusTCP-3"
                ConveyorSerialPort1 = "Conveyor-SerialPort-1"
                ConveyorSerialPort2 = "Conveyor-SerialPort-2"
                ConveyorSerialPort3 = "Conveyor-SerialPort-3"

        class SyncEnd:
            class SyncDevice(Enum):
                ConveyorModbusTCP1 = "Conveyor-ModbusTCP-1"
                ConveyorModbusTCP2 = "Conveyor-ModbusTCP-2"
                ConveyorModbusTCP3 = "Conveyor-ModbusTCP-3"
                ConveyorSerialPort1 = "Conveyor-SerialPort-1"
                ConveyorSerialPort2 = "Conveyor-SerialPort-2"
                ConveyorSerialPort3 = "Conveyor-SerialPort-3"

    class DeviceStateValue:
        class ConveryCurrentState(Enum):
            TRACK_TRACKING = "TRACK_TRACKING"
            TRACK_SYNCHRONIZED = "TRACK_SYNCHRONIZED"
            TRACK_STOPPING = "TRACK_STOPPING"
            TRACK_STOPPED = "TRACK_STOPPED"

        class GripperStateValueEnum(Enum):
            GRIPPER_UNINIT = "GRIPPER_UNINIT"
            GRIPPER_OK = "GRIPPER_OK"
            GRIPPER_ERROR = "GRIPPER_ERROR"

        class IndustrialCamConnectionStateValueEnum(Enum):
            CONNECTED = "CONNECTED"
            DISCONNECTED = "DISCONNECTED"

        class IndustrialCamDetectStateValueEnum(Enum):
            NO_RESULT = "NO_RESULT"
            NG = "NG"
            OK = "OK"

    class AIStateValueEnum:
        class AIState(Enum):
            ERROR = "ERROR"
            IDLE = "IDLE"
            POS3D = "POS3D"
            POSE6D = "POSE6D"
            GRASP_POSE = "GRASP_POSE"
            KEYPOINT = "KEYPOINT"
            BBOX = "BBOX"
            MULTIVIEW = "MULTIVIEW"
            CLASSIFY = "CLASSIFY"
            SCENE = "SCENE"
            GET_INT_VALUE = "GET_INT_VALUE"
            GET_DOUBLE_VALUE = "GET_DOUBLE_VALUE"
            KEYPOINT3D = "KEYPOINT3D"
            CUSTOM = "CUSTOM"

        class AIStatusCode(Enum):
            DISCONNECTED = "DISCONNECTED"
            UNKNOWN = "UNKNOWN"
            IDLE = "IDLE"
            OK = "OK"
            IMAGING = "IMAGING"
            COMPUTING = "COMPUTING"
            ERROR = "ERROR"


class ToolNameEnum(Enum):
    NO_TOOL = ""
    FLANGE = "Flange"


class SoftwareVersionEnum(IntEnum):
    VER_3_08 = ProtoPlanParams.VER_3_08
    VER_3_09 = ProtoPlanParams.VER_3_09
    VER_3_10 = ProtoPlanParams.VER_3_10


class VariableEnum:
    class VariableCategory(Enum):
        PLAN_VAR = "PLAN_VAR"
        PROJECT_VAR = "PROJ_VAR"
        GLOBAL_VAR = "GLOBAL_VAR"

    class VariableType(Enum):
        INT = "INT"
        DOUBLE = "DOUBLE"
        STRING = "STRING"
        BOOL = "BOOL"

        COORD = "COORD"
        JPOS = "JPOS"
        POSE = "POSE"

        VEC_2D = "VEC_2d"
        VEC_3D = "VEC_3d"
        VEC_4D = "VEC_4d"
        VEC_6D = "VEC_6d"
        VEC_7D = "VEC_7d"
        VEC_2I = "VEC_2i"
        VEC_3I = "VEC_3i"
        VEC_6I = "VEC_6i"

        ARRAY_INT = "ARRAY_INT"
        ARRAY_DOUBLE = "ARRAY_DOUBLE"
        ARRAY_STRING = "ARRAY_STRING"
        ARRAY_COORD = "ARRAY_COORD"
        ARRAY_JPOS = "ARRAY_JPOS"
        ARRAY_POSE = "ARRAY_POSE"
        ARRAY_BOOL = "ARRAY_BOOL"
        ARRAY_VEC_2D = "ARRAY_VEC_2d"
        ARRAY_VEC_3D = "ARRAY_VEC_3d"
        ARRAY_VEC_4D = "ARRAY_VEC_4d"
        ARRAY_VEC_6D = "ARRAY_VEC_6d"
        ARRAY_VEC_7D = "ARRAY_VEC_7d"
        ARRAY_VEC_2I = "ARRAY_VEC_2i"
        ARRAY_VEC_3I = "ARRAY_VEC_3i"
        ARRAY_VEC_6I = "ARRAY_VEC_6i"


class RobotUnit(Enum):
    DEGREE = "m-deg"


class PrimitiveEnum:
    class AdvancedForceControl:
        class ContactAlign:
            pt_name = "AlignContact"
            pt_type = "ALIGNCONTACT"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                AlignContacted = {
                    "name": "alignContacted",
                    "type": "BOOL",
                    "unit": "none",
                }
                ForwardDis = {"name": "insertDis", "type": "DOUBLE", "unit": "m"}

            class InputParams:
                class Basic(Enum):
                    ContactAxis = {"name": "contactDir", "type": "VEC_3i"}
                    ContactVel = {"name": "freeSpaceVel", "type": "DOUBLE"}
                    ContactForce = {"name": "targetForce", "type": "DOUBLE"}
                    AlignAxis = {"name": "alignmentDir", "type": "VEC_6i"}
                    AlignVelScale = {"name": "alignVelScale", "type": "DOUBLE"}

                class Advanced(Enum):
                    DeadbandScale = {"name": "deadbandScale", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class ForceTraj:
            pt_name = "MoveTraj"
            pt_type = "MOVE_TRAJ"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    TrajFileName = {"name": "fileName", "type": "FILE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                    ForceCoord = {"name": "forceCoord", "type": "COORD"}
                    ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}

                class Advanced(Enum):
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_4d",
                    }
                    MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    Jerk = {"name": "maxJerk", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class ForceHybrid:
            pt_name = "MoveHybrid"
            pt_type = "MOVEHYBRID"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    Target = {"name": "target", "type": "COORD"}
                    Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                    Wrench = {"name": "wrench", "type": "ARRAY_VEC_6d"}
                    Vel = {"name": "maxVel", "type": "DOUBLE"}
                    ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                    ForceCoord = {"name": "forceCoord", "type": "COORD"}
                    ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}
                    TargetWrench = {"name": "goalWrench", "type": "VEC_6d"}
                    StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}

                class Advanced(Enum):
                    Acc = {"name": "maxAcc", "type": "DOUBLE"}
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_4d",
                    }
                    EnableMaxWrench = {
                        "name": "enableMaxContactWrench",
                        "type": "VEC_6i",
                    }
                    MaxContactWrench = {"name": "maxContactWrench", "type": "VEC_6d"}
                    MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class ForceComp:
            pt_name = "ForceCompliance"
            pt_type = "MOVE_COMPLIANCE"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    Target = {"name": "target", "type": "COORD"}
                    Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                    Vel = {"name": "maxVel", "type": "DOUBLE"}
                    ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                    CompCoord = {"name": "compCoord", "type": "COORD"}
                    StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}

                class Advanced(Enum):
                    EnableMaxWrench = {
                        "name": "enableMaxContactWrench",
                        "type": "VEC_6i",
                    }
                    MaxContactWrench = {"name": "maxContactWrench", "type": "VEC_6d"}
                    Acc = {"name": "maxAcc", "type": "DOUBLE"}
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_3d",
                    }

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

    class BasicForceControl:
        class ZeroFTSensor:
            pt_name = "CaliForceSensor"
            pt_type = "CALIFORCESENSOR"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}

            class InputParams:
                class Basic(Enum):
                    DataCollectTime = {"name": "dataCollectionTime", "type": "DOUBLE"}
                    EnableStaticCheck = {"name": "enableStaticCheck", "type": "BOOL"}

                class Advanced(Enum):
                    CalibExtraPayload = {"name": "calibrateExtraLoad", "type": "BOOL"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class Contact:
            pt_name = "Contact"
            pt_type = "CONTACT"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                CurContactForce = "curContactForce"
                ForwardDis = "insertDis"

            class InputParams:
                class Basic(Enum):
                    ContactCoord = {"name": "coord", "type": "TYPE"}
                    ContactDir = {"name": "movingDir", "type": "VEC_3d"}
                    ContactVel = {"name": "contactVel", "type": "DOUBLE"}
                    MaxContactForce = {"name": "maxContactForce", "type": "DOUBLE"}
                    EnableFineContact = {"name": "fineContactMode", "type": "BOOL"}

                class Advanced(Enum):
                    Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                    Vel = {"name": "maxVel", "type": "ARRAY_DOUBLE"}
                    Acc = {"name": "maxAcc", "type": "ARRAY_DOUBLE"}
                    ZoneRadius = {"name": "zoneRadius", "type": "ARRAY_TYPE"}
                    Jerk = {"name": "maxJerk", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class ForceHybridLite:
            pt_name = "MoveHybridLite"
            pt_type = "MOVEHYBRID"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    Target = {"name": "target", "type": "COORD"}
                    Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                    Vel = {"name": "maxVel", "type": "DOUBLE"}
                    ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                    ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}
                    TargetWrench = {"name": "goalWrench", "type": "VEC_6d"}
                    StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}

                class Advanced(Enum):
                    Acc = {"name": "maxAcc", "type": "DOUBLE"}
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_3d",
                    }
                    MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class ForceCompLite:
            pt_name = "MoveCompliance"
            pt_type = "MOVE_COMPLIANCE"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    Target = {"name": "target", "type": "COORD"}
                    Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                    Vel = {"name": "maxVel", "type": "DOUBLE"}
                    ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                    CompCoord = {"name": "compCoord", "type": "COORD"}
                    CompAxis = {"name": "compAxis", "type": "VEC_6i"}

                class Advanced(Enum):
                    Acc = {"name": "maxAcc", "type": "DOUBLE"}
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_3d",
                    }

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

    class AdaptiveAssembly:
        class SearchHole:
            pt_name = "SearchHole"
            pt_type = "SEARCH_HOLE"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                SearchResisForce = {
                    "name": "searchResistanceForce",
                    "type": "DOUBLE",
                    "unit": "N",
                }
                PushDis = {"name": "timePeriod", "type": "DOUBLE", "unit": "m"}
                ForceDrop = {"name": "forceDrop", "type": "DOUBLE", "unit": "N"}
                LostContact = {"name": "lostContact", "type": "BOOL", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    ContactAxis = {"name": "contactAxis", "type": "VEC_3d"}
                    ContactForce = {"name": "contactForce", "type": "DOUBLE"}
                    SearchAxis = {"name": "searchAxis", "type": "VEC_3d"}
                    SearchPattern = {"name": "patternType", "type": "TYPE"}
                    SpiralRadius = {"name": "radius", "type": "DOUBLE"}
                    ZigZagLength = {"name": "length", "type": "DOUBLE"}
                    ZigZagWidth = {"name": "height", "type": "DOUBLE"}
                    StartDensity = {"name": "startDensity", "type": "INT"}
                    TimeFactor = {"name": "timeFactor", "type": "INT"}
                    WiggleRange = {"name": "wiggleRange", "type": "DOUBLE"}
                    WigglePeriod = {"name": "wigglePeriod", "type": "DOUBLE"}

                class Advanced(Enum):
                    EnableMaxWrench = {
                        "name": "enableMaxContactWrench",
                        "type": "VEC_6i",
                    }
                    MaxContactWrench = {"name": "maxContactWrench", "type": "VEC_6d"}
                    SearchImmed = {"name": "startSearchImmediately", "type": "BOOL"}
                    SearchStiffRatio = {
                        "name": "searchStiffnessRatio",
                        "type": "DOUBLE",
                    }
                    MaxVelForceDir = {"name": "forceCtrlVelLimit", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class CheckPiH:
            pt_name = "PihCheckTran"
            pt_type = "PIH_CHECK_TRAN"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                CheckComplete = {
                    "name": "checkComplete",
                    "type": "BOOL",
                    "unit": "none",
                }
                PegIsInHole = {"name": "pegIsInHole", "type": "BOOL", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    ContactAxis = {"name": "contactAxis", "type": "VEC_3d"}
                    SearchAxis = {"name": "searchAxis", "type": "VEC_3d"}
                    SearchRange = {"name": "searchRange", "type": "DOUBLE"}
                    SearchForce = {"name": "searchForce", "type": "DOUBLE"}
                    SearchVel = {"name": "searchVelocity", "type": "DOUBLE"}

                class Advanced(Enum):
                    LinearSearchOnly = {"name": "lineSearchOnly", "type": "BOOL"}
                    ReturnToInitPose = {"name": "returnToInitPose", "type": "BOOL"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}
                InitTcpPose = {"name": "initTcpPose", "type": "COORD", "unit": "m-deg"}

        class InsertComp:
            pt_name = "Sleeve"
            pt_type = "SLEEVE"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                IsMoving = {"name": "isMoving", "type": "BOOL", "unit": "none"}
                InsertDis = {"name": "insertDis", "type": "DOUBLE", "unit": "m"}

            class InputParams:
                class Basic(Enum):
                    InsertAxis = {"name": "insertDir", "type": "TYPE"}
                    CompAxis = {"name": "alignmentDir", "type": "VEC_6i"}
                    MaxContactForce = {"name": "maxContactForce", "type": "DOUBLE"}
                    InsertVel = {"name": "insertVel", "type": "DOUBLE"}

                class Advanced(Enum):
                    DeadbandScale = {"name": "deadbandScale", "type": "DOUBLE"}
                    CompVelScale = {"name": "adjustVelScale", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class Mate:
            pt_name = "Mating"
            pt_type = "MATING"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                MatingFinish = {
                    "name": "matingFinished",
                    "type": "BOOL",
                    "unit": "none",
                }

            class InputParams:
                class Basic(Enum):
                    ContactAxis = {"name": "forceDir", "type": "VEC_3i"}
                    StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}
                    ContactForce = {"name": "matingForce", "type": "DOUBLE"}
                    MatingAxis = {"name": "matingDir", "type": "VEC_6i"}
                    SlideMatingRange = {"name": "linearMatingRange", "type": "DOUBLE"}
                    SlideMatingVel = {"name": "maxLinearMatingVel", "type": "DOUBLE"}
                    SlideMatingAcc = {"name": "maxLinearMatingAcc", "type": "DOUBLE"}
                    RotateMatingRange = {"name": "angularMatingRange", "type": "DOUBLE"}
                    RotateMatingVel = {"name": "maxAngularMatingVel", "type": "DOUBLE"}
                    RotateMatingAcc = {"name": "maxAngularMatingAcc", "type": "DOUBLE"}
                    MatingTimes = {"name": "totalMatingTimes", "type": "INT"}
                    MaxContactDis = {"name": "maxMotionDisInForceDir", "type": "DOUBLE"}
                    SafetyForce = {"name": "safetyForce", "type": "DOUBLE"}

                class Advanced(Enum):
                    AddMatingAxis = {"name": "rasterDir", "type": "VEC_6i"}
                    AddSlideMatingRange = {
                        "name": "linearRasterRange",
                        "type": "DOUBLE",
                    }
                    AddSlideMatingVel = {"name": "maxLinearRasterVel", "type": "DOUBLE"}
                    AddSlideMatingAcc = {"name": "maxLinearRasterAcc", "type": "DOUBLE"}
                    AddRotateMatingRange = {
                        "name": "angularRasterRange",
                        "type": "DOUBLE",
                    }
                    AddRotateMatingVel = {
                        "name": "maxAngularRasterVel",
                        "type": "DOUBLE",
                    }
                    AddRotateMatingAcc = {
                        "name": "maxAngularRasterAcc",
                        "type": "DOUBLE",
                    }
                    MaxVelForceDir = {"name": "maxVelInForceDir", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class FastenScrew:
            pt_name = "ScrewFasten"
            pt_type = "SCREWFASTEN"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                InsertDis = {"name": "insertDis", "type": "DOUBLE", "unit": "m"}
                InsertVel = {"name": "insertVel", "type": "DOUBLE", "unit": "m/s"}
                FastenState = {"name": "fastenState", "type": "INT", "unit": "none"}
                ReachedHole = {
                    "name": "reachedScrewHole",
                    "type": "BOOL",
                    "unit": "none",
                }

            class InputParams:
                class Basic(Enum):
                    InsertDir = {"name": "insertDir", "type": "TYPE"}
                    MaxInsertVel = {"name": "insertVel", "type": "DOUBLE"}
                    InsertForce = {"name": "maxContactForce", "type": "DOUBLE"}
                    StiffScale = {"name": "stiffnessScale", "type": "DOUBLE"}

                class Advanced(Enum):
                    DiScrewInHole = {"name": "ioScrewInHole", "type": "TYPE"}
                    DiFastenFinish = {"name": "ioFinish", "type": "TYPE"}
                    DiScrewJam = {"name": "ioScrewJam", "type": "TYPE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

    class Motion:
        class MoveC:
            pt_name = "MoveC"
            pt_type = "MOVEC"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    Target = {"name": "target", "type": "COORD"}
                    MiddlePose = {"name": "middlePose", "type": "COORD"}
                    Vel = {"name": "maxVel", "type": "DOUBLE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}

                class Advanced(Enum):
                    Acc = {"name": "maxAcc", "type": "DOUBLE"}
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_3d",
                    }

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class MoveJ:
            pt_name = "MoveJ"
            pt_type = "MOVEJ"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    Target = {"name": "target", "type": "JPOS"}
                    Waypoints = {"name": "waypoints", "type": "ARRAY_JPOS"}
                    JntVelScale = {"name": "jntVelScale", "type": "INT"}
                    ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}

                class Advanced(Enum):
                    EnableRelativeMove = {"name": "relativeToStart", "type": "BOOL"}
                    JntAccMultiplier = {"name": "jntAccMultiplier", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class MoveL:
            pt_name = "MoveL"
            pt_type = "MOVEL"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    Target = {"name": "target", "type": "COORD"}
                    Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                    Vel = {"name": "maxVel", "type": "DOUBLE"}
                    ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}

                class Advanced(Enum):
                    Acc = {"name": "maxAcc", "type": "DOUBLE"}
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_3d",
                    }
                    EnableSixAxisJntCtrl = {
                        "name": "enableSixJointAxesCtrl",
                        "type": "BOOL",
                    }

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class MovePTP:
            pt_name = "MovePTP"
            pt_type = "MOVEPTP"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    Target = {"name": "target", "type": "COORD"}
                    Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                    JntVelScale = {"name": "jntVelScale", "type": "INT"}
                    ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}

                class Advanced(Enum):
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    JntAccMultiplier = {"name": "jntAccMultiplier", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class MoveJTraj:
            pt_name = "MoveJTraj"
            pt_type = "MOVEJTRAJ"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    TrajFileName = {"name": "fileName", "type": "FILE"}
                    JntVelScale = {"name": "jntVelScale", "type": "INT"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}

                class Advanced(Enum):
                    JntAccMultiplier = {"name": "jntAccMultiplier", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

    class Workflow:
        class Home:
            pt_name = "Home"
            pt_type = "HOME"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }

            class InputParams:
                class Basic(Enum):
                    Target = {"name": "target", "type": "JPOS"}
                    JntVelScale = {"name": "jntVelScale", "type": "INT"}

                class Advanced(Enum):
                    JntAccMultiplier = {"name": "jntAccMultiplier", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class Hold:
            pt_name = "Hold"
            pt_type = "HOLD"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class End:
            pt_name = "End"
            pt_type = "END"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class Stop:
            pt_name = "Stop"
            pt_type = "STOP"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class Fault:
            pt_name = "Fault"
            pt_type = "FAULT"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}

            class InputParams:
                class Basic(Enum):
                    ErrorMessage = {"name": "errorMessage", "type": "MSG"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class Subplan:
            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                LoopCnt = {"name": "loopCounter", "type": "INT", "unit": "none"}

    class ZeroGravityFloating:
        class FloatingCartesian:
            pt_name = "FloatingCartesian"
            pt_type = "CARTIMPEDANCEFLOATING"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                IdleTime = {"name": "idleTime", "type": "DOUBLE", "unit": "s"}

            class InputParams:
                class Basic(Enum):
                    FloatingAxis = {"name": "cartFloatingAxis", "type": "VEC_6i"}
                    EnableElbowMotion = {"name": "enableJointFloating", "type": "BOOL"}
                    FloatingCoord = {"name": "floatingCoord", "type": "COORD"}
                    DampingLevel = {"name": "resistanceLevel", "type": "VEC_6d"}

                class Advanced(Enum):
                    DiEnableFloating = {"name": "diEnableFloating", "type": "TYPE"}
                    ResponseTorque = {"name": "jointTorqueDeadBand", "type": "VEC_7d"}
                    InertiaScale = {"name": "inertiaScale", "type": "VEC_6d"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class FloatingJoint:
            pt_name = "FloatingJoint"
            pt_type = "JNTIMPEDANCEFLOATING"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                IdleTime = {"name": "idleTime", "type": "DOUBLE", "unit": "s"}

            class InputParams:
                class Basic(Enum):
                    FloatingJoint = {"name": "jntFloatingAxis", "type": "VEC_7d"}
                    DampingLevel = {"name": "resistanceLevel", "type": "VEC_7d"}

                class Advanced(Enum):
                    ResponseTorque = {"name": "jointTorqueDeadBand", "type": "VEC_7d"}
                    DiEnableFloating = {"name": "diEnableFloating", "type": "TYPE"}
                    InertiaScale = {"name": "inertiaScale", "type": "VEC_7d"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

    class SurfaceFinishing:
        class Polish:
            pt_name = "Polish"
            pt_type = "POLISH"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    TrajFileName = {"name": "fileName", "type": "FILE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                    ForceCoord = {"name": "forceCoord", "type": "COORD"}
                    ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}

                class Advanced(Enum):
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_4d",
                    }
                    EnableForceAutoRot = {
                        "name": "enableForceAutoRotation",
                        "type": "BOOL",
                    }
                    ForceRotAxis = {"name": "ForceRotationAxis", "type": "VEC_3d"}
                    EnableContactAngle = {"name": "enableContactAngle", "type": "BOOL"}
                    ContactAngle = {"name": "contactAngle", "type": "DOUBLE"}
                    ContactRotAxis = {"name": "rotAxis", "type": "VEC_3d"}
                    ContactRotRadius = {"name": "rotRadius", "type": "DOUBLE"}
                    EnableTrajOverlay = {"name": "enableTrajOverlay", "type": "BOOL"}
                    OverlaidTrajType = {"name": "overlaidTrajType", "type": "INT"}
                    Amplitude = {"name": "amplitude", "type": "DOUBLE"}
                    Pitch = {"name": "pitch", "type": "DOUBLE"}
                    OverlaidRotAngle = {"name": "rotAngle", "type": "DOUBLE"}
                    LineSpace = {"name": "lineSpace", "type": "DOUBLE"}
                    EnableTransLimit = {"name": "enableTransLimit", "type": "BOOL"}
                    MaxTransDisp = {"name": "maxTransDisp", "type": "DOUBLE"}
                    MinTransDisp = {"name": "minTransDisp", "type": "DOUBLE"}
                    EnableOrientLimit = {"name": "enableOrientLimit", "type": "BOOL"}
                    ToolRadius = {"name": "toolRadius", "type": "DOUBLE"}
                    MaxOrientAngle = {"name": "maxOrientAngle", "type": "DOUBLE"}
                    StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}
                    EnableMaxWrench = {
                        "name": "enableMaxContactWrench",
                        "type": "VEC_6i",
                    }
                    MaxContactWrench = {"name": "maxContactWrench", "type": "VEC_6d"}
                    MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class Grind:
            pt_name = "Grind"
            pt_type = "GRIND"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    TrajFileName = {"name": "fileName", "type": "FILE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                    ForceCoord = {"name": "forceCoord", "type": "COORD"}
                    ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}

                class Advanced(Enum):
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_3d",
                    }
                    EnableForceAutoRot = {
                        "name": "enableForceAutoRotation",
                        "type": "BOOL",
                    }
                    ForceRotAxis = {"name": "ForceRotationAxis", "type": "VEC_3d"}
                    EnableContactAngle = {"name": "enableContactAngle", "type": "BOOL"}
                    ContactAngle = {"name": "contactAngle", "type": "DOUBLE"}
                    ContactRotAxis = {"name": "rotAxis", "type": "VEC_3d"}
                    ContactRotRadius = {"name": "rotRadius", "type": "DOUBLE"}
                    EnableTrajOverlay = {"name": "enableTrajOverlay", "type": "BOOL"}
                    OverlaidTrajType = {"name": "overlaidTrajType", "type": "INT"}
                    Amplitude = {"name": "amplitude", "type": "DOUBLE"}
                    Pitch = {"name": "pitch", "type": "DOUBLE"}
                    OverlaidRotAngle = {"name": "rotAngle", "type": "DOUBLE"}
                    LineSpace = {"name": "lineSpace", "type": "DOUBLE"}
                    EnableTransLimit = {"name": "enableTransLimit", "type": "BOOL"}
                    MaxTransDisp = {"name": "maxTransDisp", "type": "DOUBLE"}
                    MinTransDisp = {"name": "minTransDisp", "type": "DOUBLE"}
                    EnableOrientLimit = {"name": "enableOrientLimit", "type": "BOOL"}
                    ToolRadius = {"name": "toolRadius", "type": "DOUBLE"}
                    MaxOrientAngle = {"name": "maxOrientAngle", "type": "DOUBLE"}
                    StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}
                    EnableMaxWrench = {
                        "name": "enableMaxContactWrench",
                        "type": "VEC_6i",
                    }
                    MaxContactWrench = {"name": "maxContactWrench", "type": "VEC_6d"}
                    MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class PolishECP:
            pt_name = "PolishECP"
            pt_type = "POLISHECP"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    TrajFileName = {"name": "fileName", "type": "FILE"}
                    ECPCoord = {"name": "ECPCoord", "type": "COORD"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                    ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}

                class Advanced(Enum):
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_4d",
                    }
                    EnableTrajOverlay = {"name": "enableTrajOverlay", "type": "BOOL"}
                    OverlaidTrajType = {"name": "overlaidTrajType", "type": "INT"}
                    Amplitude = {"name": "amplitude", "type": "DOUBLE"}
                    Pitch = {"name": "pitch", "type": "DOUBLE"}
                    OverlaidRotAngle = {"name": "rotAngle", "type": "DOUBLE"}
                    LineSpace = {"name": "lineSpace", "type": "DOUBLE"}
                    EnableTransLimit = {"name": "enableTransLimit", "type": "BOOL"}
                    MaxTransDisp = {"name": "maxTransDisp", "type": "DOUBLE"}
                    MinTransDisp = {"name": "minTransDisp", "type": "DOUBLE"}
                    StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}
                    EnableMaxWrench = {
                        "name": "enableMaxContactWrench",
                        "type": "VEC_6i",
                    }
                    MaxContactWrench = {"name": "maxContactWrench", "type": "VEC_6d"}
                    MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class GrindECP:
            pt_name = "GrindECP"
            pt_type = "GRINDECP"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    TrajFileName = {"name": "fileName", "type": "FILE"}
                    ECPCoord = {"name": "ECPCoord", "type": "COORD"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                    ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}

                class Advanced(Enum):
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_3d",
                    }
                    EnableTrajOverlay = {"name": "enableTrajOverlay", "type": "BOOL"}
                    OverlaidTrajType = {"name": "overlaidTrajType", "type": "INT"}
                    Amplitude = {"name": "amplitude", "type": "DOUBLE"}
                    Pitch = {"name": "pitch", "type": "DOUBLE"}
                    OverlaidRotAngle = {"name": "rotAngle", "type": "DOUBLE"}
                    LineSpace = {"name": "lineSpace", "type": "DOUBLE"}
                    EnableTransLimit = {"name": "enableTransLimit", "type": "BOOL"}
                    MaxTransDisp = {"name": "maxTransDisp", "type": "DOUBLE"}
                    MinTransDisp = {"name": "minTransDisp", "type": "DOUBLE"}
                    StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}
                    EnableMaxWrench = {
                        "name": "enableMaxContactWrench",
                        "type": "VEC_6i",
                    }
                    MaxContactWrench = {"name": "maxContactWrench", "type": "VEC_6d"}
                    MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

    class AdaptiveGrasping:
        class GraspComp:
            pt_name = "AdaptiveGrip"
            pt_type = "ADAPTIVEGRIP"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                CurGripWidth = {"name": "curWidth", "type": "DOUBLE", "unit": "m"}
                ReachGripForce = {
                    "name": "reachedForce",
                    "type": "BOOL",
                    "unit": "none",
                }
                ReachGripWidth = {
                    "name": "reachedWidth",
                    "type": "BOOL",
                    "unit": "none",
                }
                IsGripMoving = {"name": "isMoving", "type": "BOOL", "unit": "none"}
                GripComplete = {"name": "graspComplete", "type": "BOOL", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    GripperType = {"name": "gripperType", "type": "TYPE"}
                    GripVel = {"name": "gripSpeed", "type": "DOUBLE"}
                    GripWidth = {"name": "gripWidth", "type": "DOUBLE"}
                    GripForce = {"name": "maxGripForce", "type": "DOUBLE"}
                    ContactAxis = {"name": "contactDir", "type": "VEC_3i"}
                    ContactForce = {"name": "contactForce", "type": "VEC_3d"}
                    CompAxis = {"name": "compliantDir", "type": "VEC_3i"}
                    CompForce = {"name": "compliantForce", "type": "VEC_3d"}

                class Advanced(Enum):
                    MaxVelForceDir = {"name": "maxVelInForceDir", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

    class RehabilitationPhysiotherapy:
        class Massage:
            pt_name = "Massage"
            pt_type = "MOVEHYBRID"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    Target = {"name": "target", "type": "COORD"}
                    TargetWrench = {"name": "goalWrench", "type": "VEC_6d"}
                    Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                    Wrench = {"name": "wrench", "type": "ARRAY_VEC_6d"}
                    Vel = {"name": "maxVel", "type": "DOUBLE"}
                    ZoneRadius = {"name": "zoneRadius", "type": "TYPE"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}
                    ForceCoord = {"name": "forceCoord", "type": "COORD"}
                    ForceAxis = {"name": "forceAxis", "type": "VEC_6i"}
                    StiffScale = {"name": "stiffnessScaling", "type": "VEC_6d"}
                    EnableMaxWrench = {
                        "name": "enableMaxContactWrench",
                        "type": "VEC_6i",
                    }
                    MaxContactWrench = {"name": "maxContactWrench", "type": "VEC_6d"}
                    EnableEntryPoint = {"name": "enableEntry", "type": "BOOL"}
                    MaxWrenchPause = {"name": "pauseAtMaxWrench", "type": "BOOL"}
                    MotionForceDecouple = {"name": "decoupleActuation", "type": "BOOL"}
                    WrenchFilterCutoff = {
                        "name": "wrenchFilterCutoff",
                        "type": "DOUBLE",
                    }

                class Advanced(Enum):
                    Acc = {"name": "maxAcc", "type": "DOUBLE"}
                    Jerk = {"name": "maxJerk", "type": "DOUBLE"}
                    AngVel = {"name": "maxW", "type": "DOUBLE"}
                    EnableFixRefJntPos = {"name": "enablePreferJntPos", "type": "BOOL"}
                    RefJntPos = {"name": "preferJntPos", "type": "JPOS"}
                    ConfigOptObj = {
                        "name": "nullspaceGradientScaling",
                        "type": "VEC_4d",
                    }
                    MaxVelForceDir = {"name": "maxVelForceDir", "type": "VEC_3d"}
                    LineSpace = {"name": "lineSpace", "type": "DOUBLE"}
                    Amplitude = {"name": "amplitude", "type": "DOUBLE"}
                    Pitch = {"name": "pitch", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

    class HighPerformanceVisionGuidance:
        class VSTeach:
            pt_name = "VisualServoTeach"
            pt_type = "VISUALSERVOTEACH"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                TeachFinished = {
                    "name": "teachFinished",
                    "type": "BOOL",
                    "unit": "none",
                }

            class InputParams:
                class Basic(Enum):
                    ObjName = {"name": "objName", "type": "OBJNAME"}
                    ObjIndex = {"name": "objIdx", "type": "INT"}
                    CollectTimes = {"name": "sampleNum", "type": "INT"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}
                TaughtFeaturePts2D = {
                    "name": "taughtFeaturePts2D",
                    "type": "ARRAY_VEC_2d",
                    "unit": "none",
                }
                TaughtAlignPts2D = {
                    "name": "taughtMatchPts2D",
                    "type": "ARRAY_VEC_2d",
                    "unit": "none",
                }
                TaughtFeaturePtsNoise = {
                    "name": "taughtFeaturePtsNoise",
                    "type": "ARRAY_VEC_2d",
                    "unit": "none",
                }
                TaughtFeaturePts3D = {
                    "name": "taughtFeaturePts3D",
                    "type": "ARRAY_VEC_3d",
                    "unit": "m",
                }
                TaughtAlignPts3D = {
                    "name": "taughtMatchPts3D",
                    "type": "ARRAY_VEC_3d",
                    "unit": "m",
                }
                TaughtObjPose = {
                    "name": "taughtObjPose",
                    "type": "POSE",
                    "unit": "m-deg",
                }
                TaughtAlignPose = {
                    "name": "taughtMatchPose",
                    "type": "POSE",
                    "unit": "m-deg",
                }

        class HPImageBasedVS:
            pt_name = "IBVS"
            pt_type = "IBVS"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ObjAligned = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }

            class InputParams:
                class Basic(Enum):
                    ObjName = {"name": "objName", "type": "OBJNAME"}
                    ObjIndex = {"name": "objIdx", "type": "INT"}
                    TargetFeaturePts = {
                        "name": "targetFeaturePoints",
                        "type": "ARRAY_VEC_2d",
                    }
                    TargetDepth = {"name": "targetDepth", "type": "ARRAY_DOUBLE"}
                    VsAxis = {"name": "vsAxis", "type": "VEC_6i"}
                    VelScale = {"name": "velScale", "type": "DOUBLE"}
                    MaxVel = {"name": "maxVel", "type": "DOUBLE"}
                    MaxAngVel = {"name": "maxRotVel", "type": "DOUBLE"}
                    ImageConvToler = {"name": "imgConvTol", "type": "DOUBLE"}
                    TargetConvTimes = {"name": "countTol", "type": "INT"}
                    TimeoutTime = {"name": "timeoutTime", "type": "DOUBLE"}

                class Advanced(Enum):
                    EnableObjAlign = {"name": "enableObjAlign", "type": "BOOL"}
                    AlignObjPts = {
                        "name": "targetMatchObjPts",
                        "type": "ARRAY_VEC_2d",
                    }
                    OptVelScale = {"name": "optVelScale", "type": "VEC_2d"}
                    VisualDetectNoise = {
                        "name": "AIDetectNoise",
                        "type": "ARRAY_VEC_2d",
                    }

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class HPPoseBasedVS:
            pt_name = "PBVS"
            pt_type = "PBVS"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ObjAligned = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }

            class InputParams:
                class Basic(Enum):
                    ObjName = {"name": "objName", "type": "OBJNAME"}
                    ObjIndex = {"name": "objIdx", "type": "INT"}
                    DetectObjPose = {"name": "enableObjPose", "type": "BOOL"}
                    TargetObjPose = {
                        "name": "targetObjectPose",
                        "type": "POSE",
                    }
                    VsCoord = {"name": "visualCoord", "type": "COORD"}
                    VsAxis = {"name": "vsAxis", "type": "VEC_6i"}
                    VelScale = {"name": "velScale", "type": "VEC_6d"}
                    MaxVel = {"name": "maxVel", "type": "VEC_6d"}
                    MaxAcc = {"name": "maxAcc", "type": "VEC_6d"}
                    TimeoutTime = {"name": "timeoutTime", "type": "DOUBLE"}
                    VisualDelayTime = {"name": "compensateDelayTime", "type": "DOUBLE"}
                    PosConvToler = {"name": "posTol", "type": "DOUBLE"}
                    RotConvTimes = {"name": "oriTol", "type": "DOUBLE"}
                    TargetConvTimes = {"name": "countTol", "type": "INT"}

                class Advanced(Enum):
                    TargetFeaturePts = {
                        "name": "targetFeaturePoints",
                        "type": "ARRAY_VEC_3d",
                    }
                    EnableObjAlign = {"name": "enableObjAlign", "type": "BOOL"}
                    AlignObjPts = {
                        "name": "targetMatchFeaturePoints",
                        "type": "ARRAY_VEC_3d",
                    }
                    AlignObjPose = {"name": "targetMatchPose", "type": "POSE"}
                    SuppressOvershoot = {"name": "suppressOvershoot", "type": "BOOL"}
                    DynamicObjTrack = {"name": "dynamicObjTrack", "type": "BOOL"}
                    VisDetectNoiseLevel = {
                        "name": "visualDetectNoiseLevel",
                        "type": "INT",
                    }

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class HPOffsetServo:
            pt_name = "OBVS"
            pt_type = "OBVS"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ObjAligned = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }

            class InputParams:
                class Basic(Enum):
                    ObjName = {"name": "objName", "type": "OBJNAME"}
                    ObjIndex = {"name": "objIdx", "type": "INT"}
                    Target = {
                        "name": "target",
                        "type": "COORD",
                    }
                    VsCoord = {"name": "vsCoord", "type": "COORD"}
                    VsAxis = {"name": "vsAxis", "type": "VEC_6i"}
                    VelScale = {"name": "velScale", "type": "VEC_6d"}
                    MaxVel = {"name": "maxVel", "type": "VEC_6d"}
                    MaxAcc = {"name": "maxAcc", "type": "VEC_6d"}
                    TimeoutTime = {"name": "timeoutTime", "type": "DOUBLE"}
                    VisualDelayTime = {"name": "visualDelayTime", "type": "DOUBLE"}
                    PosConvToler = {"name": "posConvToler", "type": "DOUBLE"}
                    RotConvTimes = {"name": "rotConvToler", "type": "DOUBLE"}
                    TargetConvTimes = {"name": "countTol", "type": "INT"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

    class Showcase:
        class BalanceBall:
            pt_name = "BallBalance"
            pt_type = "MPCBALLBALANCING"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}

            class InputParams:
                class Basic(Enum):
                    BallWeight = {"name": "ballWeight", "type": "DOUBLE"}
                    BallFricCoeff = {"name": "ballFrictionCoeff", "type": "DOUBLE"}
                    PattenType = {"name": "trajType", "type": "TYPE"}
                    COPOffsetX = {"name": "COPOffsetX", "type": "DOUBLE"}
                    COPOffsetY = {"name": "COPOffsetY", "type": "DOUBLE"}

                class Advanced(Enum):
                    PattenSizeScale = {"name": "pathScale", "type": "DOUBLE"}
                    FreScale = {"name": "freScale", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class BalanceGlasses:
            pt_name = "BalanceGlasses"
            pt_type = "BALANCEGLASSES"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                ReachedTarget = {
                    "name": "reachedTarget",
                    "type": "BOOL",
                    "unit": "none",
                }
                WaypointIndex = {"name": "waypointIndex", "type": "INT", "unit": "none"}

            class InputParams:
                class Basic(Enum):
                    Target = {"name": "target", "type": "COORD"}
                    Duration = {"name": "duration", "type": "DOUBLE"}
                    Waypoints = {"name": "waypoints", "type": "ARRAY_COORD"}
                    TargetTolerLevel = {"name": "targetTolLevel", "type": "INT"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

    class Synchronization:
        class SyncStart:
            pt_name = "SyncStart"
            pt_type = "SYNCSTART"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
                WorkpieceDetected = {
                    "name": "workpieceDetected",
                    "type": "BOOL",
                    "unit": "none",
                }

            class InputParams:
                class Basic(Enum):
                    SyncDevice = {"name": "syncDevice", "type": "TYPE"}
                    TeachCoord = {"name": "teachCoord", "type": "COORD"}

                class Advanced(Enum):
                    TrackVel = {"name": "maxTrackVel", "type": "DOUBLE"}
                    TrackAcc = {"name": "maxTrackAcc", "type": "DOUBLE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class SyncHold:
            pt_name = "SyncHold"
            pt_type = "SYNCHOLD"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}

        class SyncEnd:
            pt_name = "SyncEnd"
            pt_type = "SYNCEND"

            class State(Enum):
                Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
                TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}

            class InputParams:
                class Basic(Enum):
                    SyncDevice = {"name": "syncDevice", "type": "TYPE"}

            class OutputParams(Enum):
                TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}


class PlanEnum:
    plan_name = "Plan"
    plan_type = "PLAN"

    class State(Enum):
        Terminated = {"name": "terminated", "type": "BOOL", "unit": "none"}
        TimePeriod = {"name": "timePeriod", "type": "DOUBLE", "unit": "s"}
        LoopCnt = {"name": "loopCounter", "type": "INT", "unit": "none"}

    class InputParams:
        class Basic(Enum):
            RepeatTimes = {"name": "repeatTimes", "type": "INT"}

        class Advanced(Enum):
            EnableForceLimit = {"name": "enableForceLimit", "type": "BOOL"}
            TcpForceLimit = {"name": "tcpForceLimit", "type": "DOUBLE"}
            EnableExtJntTrqLimit = {"name": "enableExtJntTrqLimit", "type": "BOOL"}
            ExtJntTrqLimit = {"name": "extJntTrqLimit", "type": "VEC_7d"}

    class OutputParams(Enum):
        TcpPoseOut = {"name": "tcpPoseOut", "type": "COORD", "unit": "m-deg"}
