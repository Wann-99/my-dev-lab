from functools import wraps


def PLAN(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        obj = func(*args, **kwargs)
        if hasattr(obj, "__dict__"):
            obj._type = "Plan"
            obj._created_by = func.__name__
        return obj

    return wrapper


def TRANSIT(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        obj = func(*args, **kwargs)
        if hasattr(obj, "__dict__"):
            obj._type = "Transit"
            obj._created_by = func.__name__
        return obj

    return wrapper
