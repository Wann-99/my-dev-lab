import ast
import astroid
from loguru import logger

from elements.core.enums import TransitEnum


class AssignExpressionSplitter(ast.NodeVisitor):
    def __init__(self):
        self.temp_counter = 0
        self.assignments = []
        self.current_expr = []

    def new_temp(self):
        self.temp_counter += 1
        return f"temp{self.temp_counter}"

    def _get_operator(self, op) -> TransitEnum.OperationType | None:
        if isinstance(op, ast.Add):
            return TransitEnum.OperationType.ADD
        elif isinstance(op, ast.Sub):
            return TransitEnum.OperationType.SUB
        elif isinstance(op, ast.Mult):
            return TransitEnum.OperationType.MUL
        elif isinstance(op, ast.Div):
            return TransitEnum.OperationType.DIV
        elif isinstance(op, ast.Pow):
            return TransitEnum.OperationType.POW
        elif isinstance(op, ast.Mod):
            return TransitEnum.OperationType.MOD
        elif isinstance(op, ast.FloorDiv):
            return TransitEnum.OperationType.FLOOR_DIV
        elif isinstance(op, ast.LShift):
            return TransitEnum.OperationType.LSHIFT
        elif isinstance(op, ast.RShift):
            return TransitEnum.OperationType.RSHIFT
        elif isinstance(op, ast.BitOr):
            return TransitEnum.OperationType.BIT_OR
        elif isinstance(op, ast.BitXor):
            return TransitEnum.OperationType.BIT_XOR
        elif isinstance(op, ast.BitAnd):
            return TransitEnum.OperationType.BIT_AND
        elif isinstance(op, ast.Invert):
            return TransitEnum.OperationType.INVERT
        else:
            logger.error(f"Unsupported operator: {op}")
            return None

    def visit_BinOp(self, node):
        # 递归处理左右操作数
        left = self.visit(node.left)
        right = self.visit(node.right)
        # 生成临时变量名
        temp_var = self.new_temp()
        # 构建当前操作的赋值语句
        op = self._get_operator(node.op)
        self.assignments.append(f"{temp_var} = {left} {op} {right}")
        return temp_var

    def visit_Name(self, node):
        return node.id  # 返回变量名

    def visit_Constant(self, node):
        return str(node.value)  # 返回常量值


class TestExpressionTransformer(ast.NodeTransformer):

    def _get_comparer(self, comp) -> TransitEnum.ConditionType | None:
        if isinstance(comp, ast.Eq):
            return TransitEnum.ConditionType.EQUAL
        elif isinstance(comp, ast.NotEq):
            return TransitEnum.ConditionType.NOT_EQUAL
        elif isinstance(comp, ast.Lt):
            return TransitEnum.ConditionType.LESS
        elif isinstance(comp, ast.LtE):
            return TransitEnum.ConditionType.LESS_EQUAL
        elif isinstance(comp, ast.Gt):
            return TransitEnum.ConditionType.GREATER
        elif isinstance(comp, ast.GtE):
            return TransitEnum.ConditionType.GREATER_EQUAL
        else:
            logger.error(f"Unsupported comparer: {comp}")
            return None

    def visit_Compare(self, node):
        # 拆分类似 a < b < c 的多比较为多个二元比较
        if len(node.ops) > 1:
            comparators = [node.left] + node.comparators
            comparisons = [
                ast.Compare(left=comparators[i], ops=[op], comparators=[comparators[i + 1]])
                for i, op in enumerate(node.ops)
            ]
            return ast.BoolOp(ast.And(), comparisons)
        return node

    def visit_BoolOp(self, node):
        # 拆分多个逻辑操作数为嵌套二元结构
        if len(node.values) > 2:
            new_node = ast.BoolOp(node.op, node.values[:2])
            for val in node.values[2:]:
                new_node = ast.BoolOp(node.op, [new_node, val])
            return ast.copy_location(new_node, node)
        return node


class TestExpressionSplitter(ast.NodeVisitor):
    def __init__(self):
        self.expressions = []

    def visit_BoolOp(self, node):
        self.generic_visit(node)  # 先处理子节点
        self.expressions.append({
            'type': 'BoolOp',
            'op': type(node.op).__name__,
            'left': node.values[0],
            'right': node.values[1]
        })

    def visit_Compare(self, node):
        self.expressions.append({
            'type': 'Compare',
            'op': type(node.ops[0]).__name__,
            'left': node.left,
            'right': node.comparators[0]
        })


class ExpressionUtil:

    @staticmethod
    def split_assign(expression: str, result = "result"):
        # 解析表达式
        expr_ast = ast.parse(f"{result} = {expression}", mode='exec')
        splitter = AssignExpressionSplitter()
        # 提取赋值语句的右值表达式
        for node in ast.walk(expr_ast):
            if isinstance(node, ast.Assign):
                right_value = splitter.visit(node.value)
                # 添加最终赋值
                splitter.assignments.append(f"{node.targets[0].id} = {right_value}")
        return splitter.assignments

    @staticmethod
    def split_test(expression: str):
        # 解析表达式
        expr_ast = ast.parse(f"{expression}", mode='eval')
        expr_astroid = astroid.parse(f"{expression}")
        transformer = TestExpressionTransformer()
        new_expr_ast = transformer.visit(expr_ast)
        splitter = TestExpressionSplitter()
        splitter.visit(new_expr_ast)

        # 打印结果
        for expr in splitter.expressions:
            left = expr['left']
            print(isinstance(left, ast.Name))
            temp = expr_astroid.lookup(left.id)
            assign = expr_astroid.lookup(left.id)[1][0]
            inferred = next(assign.infer())
            print(isinstance(left.ctx, ast.Load))
            right = expr['right']
            if expr['type'] == 'Compare':
                print(f"Compare: {left} {expr['op']} {right}")
            else:
                print(f"BoolOp: {left} {expr['op']} {right}")



if __name__ == '__main__':
    assign_expression1 = "result = a + b * c - d / e"
    assignments1 = ExpressionUtil.split_assign(assign_expression1)
    print(assignments1)
    assign_expression2 = "a = 5;"
    assignments2 = ExpressionUtil.split_assign(assign_expression2)
    print(assignments2)
    test_expression = "a < 10 and b > 0"
    tests = ExpressionUtil.split_test(test_expression)
    print(tests)
    print()