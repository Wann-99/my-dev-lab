import math
from typing import List


class RoboticsUtil:
    @staticmethod
    def quaternion_to_euler(quaternion: List) -> List:
        import scipy.spatial.transform as st

        euler_angles = st.Rotation.from_quat(quaternion).as_euler("xyz", degrees=True)
        return euler_angles.tolist()

    @staticmethod
    def radians_to_degrees(radians: float) -> float:
        return math.degrees(radians)

    @staticmethod
    def degrees_to_radians(degrees: float) -> float:
        return math.radians(degrees)
