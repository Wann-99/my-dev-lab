import os
import time

from colorama import deinit, init

from elements.settings import RobotSetting
from elements.utils.nanomsg_util import NanomsgClient, NanomsgClientUtil
from elements.utils.qnx_util import QnxClientUtil


class MonitorUtil:

    @staticmethod
    def print_runtime(client: NanomsgClient, duration: int = 1, setting: RobotSetting = RobotSetting()):
        """print robot info every duration

        :param client: nanomsg client
        :param duration: unit: second
        :param setting: RobotSetting
        :return:
        """

        robot_raw_data = NanomsgClientUtil.get_data(client)
        qnx_time = NanomsgClientUtil.get_time(client, robot_raw_data)
        qnx_time = qnx_time.get("timestamp").replace("T", " ").replace("Z", "")
        qnx_cpu = QnxClientUtil.get_cpu_info()
        qnx_cpu_runtime = QnxClientUtil.get_cpu_runtime_info()
        qnx_disk = QnxClientUtil.get_disk_info()
        qnx_memory = QnxClientUtil.get_memory_info()
        robot_system_info = NanomsgClientUtil.get_system_info(client, robot_raw_data)
        plan = robot_system_info.get("assigned_plan_name")
        primitive = robot_system_info.get("cur_pt_name")
        velocity_scale = (
            str(robot_system_info.get("assigned_plan_velocity_scale") * 100) + "%"
        )
        mode = robot_system_info.get("robot_mode").title()
        state = robot_system_info.get("robot_state").title()
        servo_on = robot_system_info.get("servoon").title()
        e_stop = robot_system_info.get("estop").title()
        gpio_in = NanomsgClientUtil.get_gpio_in(client, robot_raw_data).get(
            "bub_digital_input"
        )
        gpio_out = NanomsgClientUtil.get_gpio_out(client, robot_raw_data).get(
            "bub_digital_output"
        )
        gpio_state = NanomsgClientUtil.get_gpio_state(client, robot_raw_data).get(
            "gpio_state"
        )
        robot_joints_info = NanomsgClientUtil.get_joints_info(client, robot_raw_data)
        robot_joint_positions_info = [
            f"A{index+1}:" + str(item).rjust(8)
            for index, item in enumerate(robot_joints_info.get("positions"))
        ]
        robot_joint_velocities_info = [
            f"A{index+1}:" + str(item).rjust(8)
            for index, item in enumerate(robot_joints_info.get("velocities"))
        ]
        robot_joint_torques_info = [
            f"A{index+1}:" + str(item).rjust(8)
            for index, item in enumerate(robot_joints_info.get("torques"))
        ]
        robot_joint_currents_info = [
            f"A{index+1}:" + str(item).rjust(8)
            for index, item in enumerate(robot_joints_info.get("currents"))
        ]
        robot_joint_temperatures_info = [
            f"A{index+1}:" + str(item).rjust(8)
            for index, item in enumerate(robot_joints_info.get("temperatures"))
        ]
        robot_cartesian = ["X", "Y", "Z", "Rx", "Ry", "Rz"]
        robot_cartesian_info = NanomsgClientUtil.get_cartesian_info(
            client, robot_raw_data
        )
        robot_cartesian_positions_info = [
            f"{robot_cartesian[index]}:" + str(item).rjust(8)
            for index, item in enumerate(robot_cartesian_info.get("positions"))
        ]
        robot_cartesian_velocities_info = [
            f"{robot_cartesian[index]}:" + str(item).rjust(8)
            for index, item in enumerate(robot_cartesian_info.get("velocities"))
        ]

        init(autoreset=True)
        os.system("clear")
        print("=" * 100)
        print("QNX System Info:")
        print("*" * 50)
        print("QNX time:   " + qnx_time)
        print("CPU usage:  " + qnx_cpu)
        print("RAM usage:  " + qnx_memory)
        print("Disk usage: " + qnx_disk)
        print()

        print("QNX CPU Runtime Info:")
        print("*" * 50)
        print(qnx_cpu_runtime)
        print()

        print("Robot Info:")
        print("*" * 50)
        print("Robot IP.:    " + setting.ip)
        print("Servo On:     " + servo_on)
        print("E-Stop:       " + e_stop)
        print("Mode:         " + mode)
        print("State:        " + state)
        print("Plan:         " + plan)
        print("Primitive:    " + primitive)
        print("Tool:         ")
        print("Velocity Scale: " + velocity_scale)
        print()

        print("Joint Info:")
        print("*" * 50)
        print("Position:     " + "  ".join(robot_joint_positions_info))
        print("Velocity:     " + "  ".join(robot_joint_velocities_info))
        print("Torque:       " + "  ".join(robot_joint_torques_info))
        print("Current:      " + "  ".join(robot_joint_currents_info))
        print("Temperature:  " + "  ".join(robot_joint_temperatures_info))
        print()

        print("Cartesian Info:")
        print("*" * 50)
        print("Position:     " + "  ".join(robot_cartesian_positions_info))
        print("Velocity:     " + "  ".join(robot_cartesian_velocities_info))
        print()

        print("GPIO Info:")
        print("*" * 50)
        print("State:        " + gpio_state)
        print("GPIO IN:      " + " ".join([str(item) for item in gpio_in]))
        print("GPIO OUT:     " + " ".join([str(item) for item in gpio_out]))
        print()

        deinit()
        time.sleep(duration)


if __name__ == "__main__":
    setting = RobotSetting()
    client = NanomsgClient(setting.ip, setting.nanomsg_port)
    while True:
        MonitorUtil.print_runtime(client)
