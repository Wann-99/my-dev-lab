from enum import Enum

from elements.common.enums import (
    PrimitiveInputParameterEnum,
    PrimitiveNameEnum,
    PrimitiveStateEnum,
    PrimitiveTypeEnum,
)
from elements.core.contrib.node import Node
from elements.core.contrib.parameter_values import (
    ParameterValue,
    ParameterValueGlobalVariable,
)
from elements.core.contrib.parameters import Parameter, ParameterPtInput
from elements.core.transit import Transit


class PrimitiveNode(Node):

    def __init__(self, name: str):
        super().__init__(name)
        self.cml_param_assignment = []
        # added primitive params
        self.params = []
        # must-add primitive params
        self.required_params = []
        # each parameter should check type
        self.type_mapping = self._get_type_mapping()

    def _get_type_mapping(self):
        type_mapping = {}
        parent_name = self.__class__.__qualname__
        module_name = getattr(PrimitiveInputParameterEnum, parent_name.split(".")[0])
        enum = getattr(module_name, parent_name.split(".")[1])
        if hasattr(enum, "Basic"):
            type_mapping.update({param: param.value["type"] for param in enum.Basic})
        if hasattr(enum, "Advanced"):
            type_mapping.update({param: param.value["type"] for param in enum.Advanced})
        return type_mapping

    def add_transit(self, transit: Transit):
        assert transit is not None, "transit cannot be None"
        assert hasattr(transit, "_type"), "transit must be defined in function"
        assert transit._type == "Transit", "the transit type must be Transit"
        assert isinstance(transit, Transit), "the transit must be a Transit object"

        self.next_primitives.append(transit.end_node)
        self.transits.append(transit)

    def add_parameter(self, param: Enum, param_value: ParameterValue | Parameter):
        from elements.core.transit import Assignment

        # newer parameter will override old one
        if param in self.params:
            self.params.remove(param)
            # remove old assignment
            self.cml_param_assignment = [
                assignment
                for assignment in self.cml_param_assignment
                if assignment.cm_lhs_param.m_name != param.value["name"]
            ]

        # check parameter type
        if not isinstance(param_value, ParameterValueGlobalVariable):
            if param in self.type_mapping:
                if isinstance(param_value.m_type, Enum):
                    param_type = param_value.m_type.value
                else:
                    param_type = param_value.m_type
                assert (
                    self.type_mapping[param] == param_type
                ), f"{param}'s type must be {self.type_mapping[param]}, but real type is {param_value.m_type.value}"
            else:
                raise KeyError(f"Invalid params:{param}")

        self.cml_param_assignment.append(
            Assignment(
                lhs_param=ParameterPtInput(pt=self, pt_param=param),
                rhs_param=param_value,
            )
        )
        self.params.append(param)

    @property
    def breakpoint(self):
        return self.m_is_breakpoint

    @breakpoint.setter
    def breakpoint(self, value: bool):
        self.m_is_breakpoint = value


class Motion:
    class MoveC(PrimitiveNode):
        def __init__(self, name: str):
            super(Motion.MoveC, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Motion.MOVEC.value
            self.m_pt_type = PrimitiveTypeEnum.Motion.MOVEC.value
            self.pt_state: PrimitiveStateEnum.MoveC = (
                PrimitiveStateEnum.MoveC.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.Motion.MoveC.Basic.Target,
                PrimitiveInputParameterEnum.Motion.MoveC.Basic.MiddlePose,
            ]

    class MoveJ(PrimitiveNode):
        def __init__(self, name):
            super(Motion.MoveJ, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Motion.MOVEJ.value
            self.m_pt_type = PrimitiveTypeEnum.Motion.MOVEJ.value
            self.pt_state: PrimitiveStateEnum.MoveJ = (
                PrimitiveStateEnum.MoveJ.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.Motion.MoveJ.Basic.Target,
            ]

    class MoveL(PrimitiveNode):
        def __init__(self, name):
            super(Motion.MoveL, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Motion.MOVEL.value
            self.m_pt_type = PrimitiveTypeEnum.Motion.MOVEL.value
            self.pt_state: PrimitiveStateEnum.MoveL = (
                PrimitiveStateEnum.MoveL.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.Motion.MoveL.Basic.Target,
            ]

    class MovePTP(PrimitiveNode):
        def __init__(self, name):
            super(Motion.MovePTP, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Motion.MOVEPTP.value
            self.m_pt_type = PrimitiveTypeEnum.Motion.MOVEPTP.value
            self.pt_state: PrimitiveStateEnum.MovePTP = (
                PrimitiveStateEnum.MovePTP.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.Motion.MovePTP.Basic.Target,
            ]


class Workflow:
    class Home(PrimitiveNode):
        def __init__(self, name):
            super(Workflow.Home, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Workflow.HOME.value
            self.m_pt_type = PrimitiveTypeEnum.Workflow.HOME.value
            self.pt_state: PrimitiveStateEnum.Home = (
                PrimitiveStateEnum.Home.ReachedTarget
            )

    class Hold(PrimitiveNode):
        def __init__(self, name):
            super(Workflow.Hold, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Workflow.HOLD.value
            self.m_pt_type = PrimitiveTypeEnum.Workflow.HOLD.value
            self.pt_state: PrimitiveStateEnum.Hold = PrimitiveStateEnum.Hold.TimePeriod

    class Fault(PrimitiveNode):
        def __init__(self, name):
            super(Workflow.Fault, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Workflow.FAULT.value
            self.m_pt_type = PrimitiveTypeEnum.Workflow.FAULT.value

    class Stop(PrimitiveNode):
        def __init__(self, name):
            super(Workflow.Stop, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Workflow.STOP.value
            self.m_pt_type = PrimitiveTypeEnum.Workflow.STOP.value
            self.pt_state: PrimitiveStateEnum.Stop = PrimitiveStateEnum.Stop.Terminated

    class End(PrimitiveNode):
        def __init__(self, name):
            super(Workflow.End, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Workflow.END.value
            self.m_pt_type = PrimitiveTypeEnum.Workflow.END.value
            self.children = None


class BasicForceControl:
    class ZeroFTSensor(PrimitiveNode):
        def __init__(self, name):
            super(BasicForceControl.ZeroFTSensor, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.BasicForceControl.ZEROFTSENSOR.value
            self.m_pt_type = PrimitiveTypeEnum.BasicForceControl.ZEROFTSENSOR.value
            self.pt_state: PrimitiveStateEnum.ZeroFTSensor = (
                PrimitiveStateEnum.ZeroFTSensor.Terminated
            )

    class Contact(PrimitiveNode):
        def __init__(self, name):
            super(BasicForceControl.Contact, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.BasicForceControl.CONTACT.value
            self.m_pt_type = PrimitiveTypeEnum.BasicForceControl.CONTACT.value
            self.pt_state: PrimitiveStateEnum.Contact = (
                PrimitiveStateEnum.Contact.Terminated
            )

    class MoveTraj(PrimitiveNode):
        def __init__(self, name):
            super(BasicForceControl.MoveTraj, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.BasicForceControl.MOVETRAJ.value
            self.m_pt_type = PrimitiveTypeEnum.BasicForceControl.MOVETRAJ.value
            self.pt_state: PrimitiveStateEnum.MoveTraj = (
                PrimitiveStateEnum.MoveTraj.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.BasicForceControl.MoveTraj.Basic.TrajFileName,
            ]

    class MoveComp(PrimitiveNode):
        def __init__(self, name):
            super(BasicForceControl.MoveComp, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.BasicForceControl.MOVECOMP.value
            self.m_pt_type = PrimitiveTypeEnum.BasicForceControl.MOVECOMP.value
            self.pt_state: PrimitiveStateEnum.MoveComp = (
                PrimitiveStateEnum.MoveComp.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.BasicForceControl.MoveComp.Basic.Target,
            ]


class AdvancedForceControl:
    class ContactAlign(PrimitiveNode):
        def __init__(self, name):
            super(AdvancedForceControl.ContactAlign, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.AdvancedForceControl.CONTACTALIGN.value
            self.m_pt_type = PrimitiveTypeEnum.AdvancedForceControl.CONTACTALIGN.value
            self.pt_state: PrimitiveStateEnum.ContactAlign = (
                PrimitiveStateEnum.ContactAlign.AlignContacted
            )

    class ForceHybrid(PrimitiveNode):
        def __init__(self, name):
            super(AdvancedForceControl.ForceHybrid, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.AdvancedForceControl.FORCEHYBRID.value
            self.m_pt_type = PrimitiveTypeEnum.AdvancedForceControl.FORCEHYBRID.value
            self.pt_state: PrimitiveStateEnum.ForceHybrid = (
                PrimitiveStateEnum.ForceHybrid.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.AdvancedForceControl.ForceHybrid.Basic.Target,
                PrimitiveInputParameterEnum.AdvancedForceControl.ForceHybrid.Basic.ForceAxis,
                PrimitiveInputParameterEnum.AdvancedForceControl.ForceHybrid.Basic.TargetWrench,
            ]

    class ForceComp(PrimitiveNode):
        def __init__(self, name):
            super(AdvancedForceControl.ForceComp, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.AdvancedForceControl.FORCECOMP.value
            self.m_pt_type = PrimitiveTypeEnum.AdvancedForceControl.FORCECOMP.value
            self.pt_state: PrimitiveStateEnum.ForceComp = (
                PrimitiveStateEnum.ForceComp.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.AdvancedForceControl.ForceComp.Basic.Target,
            ]


class AdaptiveAssembly:
    class SearchHole(PrimitiveNode):
        def __init__(self, name):
            super(AdaptiveAssembly.SearchHole, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.AdaptiveAssembly.SEARCHHOLE.value
            self.m_pt_type = PrimitiveTypeEnum.AdaptiveAssembly.SEARCHHOLE.value
            self.pt_state: PrimitiveStateEnum.SearchHole = (
                PrimitiveStateEnum.SearchHole.PushDis
            )

    class CheckPiH(PrimitiveNode):
        def __init__(self, name):
            super(AdaptiveAssembly.CheckPiH, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.AdaptiveAssembly.CHECKPIH.value
            self.m_pt_type = PrimitiveTypeEnum.AdaptiveAssembly.CHECKPIH.value
            self.pt_state: PrimitiveStateEnum.CheckPiH = (
                PrimitiveStateEnum.CheckPiH.CheckComplete
            )

    class InsertComp(PrimitiveNode):
        def __init__(self, name):
            super(AdaptiveAssembly.InsertComp, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.AdaptiveAssembly.INSERTCOMP.value
            self.m_pt_type = PrimitiveTypeEnum.AdaptiveAssembly.INSERTCOMP.value
            self.pt_state: PrimitiveStateEnum.InsertComp = (
                PrimitiveStateEnum.InsertComp.IsMoving
            )
            self.required_params = [
                PrimitiveInputParameterEnum.AdaptiveAssembly.InsertComp.Basic.InsertAxis,
            ]

    class Mate(PrimitiveNode):
        def __init__(self, name):
            super(AdaptiveAssembly.Mate, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.AdaptiveAssembly.MATE.value
            self.m_pt_type = PrimitiveTypeEnum.AdaptiveAssembly.MATE.value
            self.pt_state: PrimitiveStateEnum.Mate = (
                PrimitiveStateEnum.Mate.MatingFinish
            )

    class FastenScrew(PrimitiveNode):
        def __init__(self, name):
            super(AdaptiveAssembly.FastenScrew, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.AdaptiveAssembly.FASTENSCREW.value
            self.m_pt_type = PrimitiveTypeEnum.AdaptiveAssembly.FASTENSCREW.value
            self.pt_state: PrimitiveStateEnum.FastenScrew = (
                PrimitiveStateEnum.FastenScrew.FastenState
            )


class SurfaceFinishing:
    class Polish(PrimitiveNode):
        def __init__(self, name):
            super(SurfaceFinishing.Polish, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.SurfaceFinishing.POLISH.value
            self.m_pt_type = PrimitiveTypeEnum.SurfaceFinishing.POLISH.value
            self.pt_state: PrimitiveStateEnum.Polish = (
                PrimitiveStateEnum.Polish.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.SurfaceFinishing.Polish.Basic.TrajFileName,
            ]

    class Grind(PrimitiveNode):
        def __init__(self, name):
            super(SurfaceFinishing.Grind, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.SurfaceFinishing.GRIND.value
            self.m_pt_type = PrimitiveTypeEnum.SurfaceFinishing.GRIND.value
            self.pt_state: PrimitiveStateEnum.Grind = (
                PrimitiveStateEnum.Grind.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.SurfaceFinishing.Grind.Basic.TrajFileName,
            ]

    class PolishECP(PrimitiveNode):
        def __init__(self, name):
            super(SurfaceFinishing.PolishECP, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.SurfaceFinishing.POLISHECP.value
            self.m_pt_type = PrimitiveTypeEnum.SurfaceFinishing.POLISHECP.value
            self.pt_state: PrimitiveStateEnum.PolishECP = (
                PrimitiveStateEnum.PolishECP.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.SurfaceFinishing.PolishECP.Basic.TrajFileName,
                PrimitiveInputParameterEnum.SurfaceFinishing.PolishECP.Basic.ECPCoord,
            ]

    class GrindECP(PrimitiveNode):
        def __init__(self, name):
            super(SurfaceFinishing.GrindECP, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.SurfaceFinishing.GRINDECP.value
            self.m_pt_type = PrimitiveTypeEnum.SurfaceFinishing.GRINDECP.value
            self.pt_state: PrimitiveStateEnum.GrindECP = (
                PrimitiveStateEnum.GrindECP.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.SurfaceFinishing.GrindECP.Basic.TrajFileName,
                PrimitiveInputParameterEnum.SurfaceFinishing.GrindECP.Basic.ECPCoord,
            ]


class AdaptiveGrasping:
    class GraspComp(PrimitiveNode):

        def __init__(self, name):
            super(AdaptiveGrasping.GraspComp, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.AdaptiveGrasping.GRASPCOMP.value
            self.m_pt_type = PrimitiveTypeEnum.AdaptiveGrasping.GRASPCOMP.value
            self.pt_state: PrimitiveStateEnum.GraspComp = (
                PrimitiveStateEnum.GraspComp.GripComplete
            )


class Synchronization:
    class SyncStart(PrimitiveNode):
        def __init__(self, name):
            super(Synchronization.SyncStart, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Synchronization.SYNCSTART.value
            self.m_pt_type = PrimitiveTypeEnum.Synchronization.SYNCSTART.value
            self.pt_state: PrimitiveStateEnum.SyncStart = (
                PrimitiveStateEnum.SyncStart.WorkpieceDetected
            )
            self.required_params = [
                PrimitiveInputParameterEnum.Synchronization.SyncStart.Basic.SyncDevice,
                PrimitiveInputParameterEnum.Synchronization.SyncStart.Basic.TeachCoord,
            ]

    class SyncHold(PrimitiveNode):
        def __init__(self, name):
            super(Synchronization.SyncHold, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Synchronization.SYNCHOLD.value
            self.m_pt_type = PrimitiveTypeEnum.Synchronization.SYNCHOLD.value
            self.pt_state: PrimitiveStateEnum.SyncHold = (
                PrimitiveStateEnum.SyncHold.TimePeriod
            )

    class SyncEnd(PrimitiveNode):
        def __init__(self, name):
            super(Synchronization.SyncEnd, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Synchronization.SYNCEND.value
            self.m_pt_type = PrimitiveTypeEnum.Synchronization.SYNCEND.value
            self.pt_state: PrimitiveStateEnum.SyncEnd = (
                PrimitiveStateEnum.SyncEnd.Terminated
            )
            self.required_params = [
                PrimitiveInputParameterEnum.Synchronization.SyncEnd.Basic.SyncDevice
            ]


class ZeroGravityFloating:
    class FloatingCartesian(PrimitiveNode):
        def __init__(self, name):
            super(ZeroGravityFloating.FloatingCartesian, self).__init__(name)
            self.m_pt_name = (
                PrimitiveNameEnum.ZeroGravityFloating.FLOATINGCARTESIAN.value
            )
            self.m_pt_type = (
                PrimitiveTypeEnum.ZeroGravityFloating.FLOATINGCARTESIAN.value
            )
            self.pt_state: PrimitiveStateEnum.FloatingCartesian = (
                PrimitiveStateEnum.FloatingCartesian.IdleTime
            )

    class FloatingJoint(PrimitiveNode):
        def __init__(self, name):
            super(ZeroGravityFloating.FloatingJoint, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.ZeroGravityFloating.FLOATINGJOINT.value
            self.m_pt_type = PrimitiveTypeEnum.ZeroGravityFloating.FLOATINGJOINT.value
            self.pt_state: PrimitiveStateEnum.FloatingJoint = (
                PrimitiveStateEnum.FloatingJoint.IdleTime
            )


class RehabilitationPhysiotherapy:
    class Massage(PrimitiveNode):
        def __init__(self, name):
            super(RehabilitationPhysiotherapy.Massage, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.RehabilitationPhysiotherapy.MASSAGE.value
            self.m_pt_type = PrimitiveTypeEnum.RehabilitationPhysiotherapy.MASSAGE.value
            self.required_params = [
                PrimitiveInputParameterEnum.RehabilitationPhysiotherapy.Massage.Basic.Target,
                PrimitiveInputParameterEnum.RehabilitationPhysiotherapy.Massage.Basic.TargetWrench,
                PrimitiveInputParameterEnum.RehabilitationPhysiotherapy.Massage.Basic.ForceAxis,
            ]
            self.pt_state: PrimitiveStateEnum.Massage = (
                PrimitiveStateEnum.Massage.ReachedTarget
            )


class VisualServoing:
    class TeachFeature(PrimitiveNode):
        def __init__(self, name):
            super(VisualServoing.TeachFeature, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.VisualServoing.TEACHFEATURE.value
            self.m_pt_type = PrimitiveTypeEnum.VisualServoing.TEACHFEATURE.value
            self.pt_state: PrimitiveStateEnum.TeachFeature = (
                PrimitiveStateEnum.TeachFeature.Terminated
            )
            self.required_params = [
                PrimitiveInputParameterEnum.VisualServoing.TeachFeature.Basic.ObjName,
            ]

    class AlignPoint(PrimitiveNode):
        def __init__(self, name):
            super(VisualServoing.AlignPoint, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.VisualServoing.ALIGNPOINT.value
            self.m_pt_type = PrimitiveTypeEnum.VisualServoing.ALIGNPOINT.value
            self.pt_state: PrimitiveStateEnum.AlignPoint = (
                PrimitiveStateEnum.AlignPoint.FeatureAligned
            )
            self.required_params = [
                PrimitiveInputParameterEnum.VisualServoing.AlignPoint.Basic.TargetFeaturePoint,
                PrimitiveInputParameterEnum.VisualServoing.AlignPoint.Basic.TargetDepth,
                PrimitiveInputParameterEnum.VisualServoing.AlignPoint.Basic.ObjName,
            ]

    class AlignPattern(PrimitiveNode):
        def __init__(self, name):
            super(VisualServoing.AlignPattern, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.VisualServoing.ALIGNPATTERN.value
            self.m_pt_type = PrimitiveTypeEnum.VisualServoing.ALIGNPATTERN.value
            self.pt_state: PrimitiveStateEnum.AlignPattern = (
                PrimitiveStateEnum.AlignPattern.FeatureAligned
            )
            self.required_params = [
                PrimitiveInputParameterEnum.VisualServoing.AlignPattern.Basic.TargetFeaturePattern,
                PrimitiveInputParameterEnum.VisualServoing.AlignPattern.Basic.TargetDepth,
                PrimitiveInputParameterEnum.VisualServoing.AlignPattern.Basic.ObjName,
            ]


class Showcase:
    class BalanceBall(PrimitiveNode):
        def __init__(self, name):
            super(Showcase.BalanceBall, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Showcase.BALANCEBALL.value
            self.m_pt_type = PrimitiveTypeEnum.Showcase.BALANCEBALL.value
            self.pt_state: PrimitiveStateEnum.BalanceBall = (
                PrimitiveStateEnum.BalanceBall.TimePeriod
            )
            self.required_params = [
                PrimitiveInputParameterEnum.Showcase.BalanceBall.Basic.BallWeight,
                PrimitiveInputParameterEnum.Showcase.BalanceBall.Basic.BallFricCoeff,
                PrimitiveInputParameterEnum.Showcase.BalanceBall.Basic.COPOffsetX,
                PrimitiveInputParameterEnum.Showcase.BalanceBall.Basic.COPOffsetY,
            ]

    class BalanceGlasses(PrimitiveNode):
        def __init__(self, name):
            super(Showcase.BalanceGlasses, self).__init__(name)
            self.m_pt_name = PrimitiveNameEnum.Showcase.BALANCEGLASSES.value
            self.m_pt_type = PrimitiveTypeEnum.Showcase.BALANCEGLASSES.value
            self.pt_state: PrimitiveStateEnum.BalanceGlasses = (
                PrimitiveStateEnum.BalanceGlasses.ReachedTarget
            )
            self.required_params = [
                PrimitiveInputParameterEnum.Showcase.BalanceGlasses.Basic.Target
            ]
