from enum import Enum
from typing import List, Union

from elements.common.enums import (
    TransitConditionTypeEnum,
    TransitConditionValueEnum,
    TransitOperationTypeEnum,
    TransitOperationValueEnum,
)
from elements.core import gen_proto_obj
from elements.core.contrib.parameter_values import ParameterValue
from elements.core.contrib.parameters import Parameter
from elements.proto.ProtoPlanParams_pb2 import (
    ProtoExpressionParams,
    ProtoExpressionSetParams,
    ProtoNodeTransitParams,
    ProtoParamsAssignment,
    ProtoParamsOperation,
    ProtoTCParams,
)


class Condition:
    def __init__(
        self,
        condition_type: TransitConditionTypeEnum = TransitConditionTypeEnum.NO_CHECK,
        lhs_param: Parameter = None,
        rhs_param: ParameterValue = None,
        cml_trigger_condition=None,
    ):

        self.m_condition_type = condition_type.value
        self.cm_lhs_param = lhs_param
        self.cm_rhs_param = rhs_param
        if cml_trigger_condition is None:
            cml_trigger_condition = []
        self.cml_trigger_condition = cml_trigger_condition

    @property
    def name(self):
        if self.cm_lhs_param:
            if hasattr(self.cm_lhs_param, "pt"):
                name = self.cm_lhs_param.pt.m_node_name
            else:
                name = self.cm_lhs_param.m_module_name
            return (
                self.cm_lhs_param.m_category
                + "::"
                + name
                + "::"
                + self.cm_lhs_param.m_name
                + " "
                + getattr(TransitConditionValueEnum, self.m_condition_type).value
                + " "
                + self.cm_rhs_param.value
            )
        # NO_CHECK
        return ""

    def from_json(self, condition_json):
        """
        # ToDo: no intelligence prompt
        :param condition_json:
        {
            "operator": "or",
            "conditions": [
                {
                    "operator": "equal",
                    "left": {
                        "type": "PT_STATE",
                        "node_name": "",
                        "value": "Terminated"
                    },
                    "right": {
                        "category": "const",
                        "type": "bool",
                        "value":
                    }
                }
            ]
        }
        :return:
        """

    def to_proto(self) -> ProtoTCParams:
        obj = ProtoTCParams()
        for k, v in self.__dict__.items():
            if k.startswith("m_"):
                if isinstance(v, Enum):
                    setattr(obj, k[2:], v.value)
                else:
                    setattr(obj, k[2:], v)
            elif k.startswith("cm_") and v:
                gen_proto_obj(obj, k[3:], v)
            elif k.startswith("cml_") and v:
                sub_v_objs = []
                for item in v:
                    sub_v_objs.append(item.to_proto())
                getattr(obj, k[4:]).extend(sub_v_objs)
        return obj


class Assignment:
    def __init__(self, lhs_param: Parameter, rhs_param: Parameter | ParameterValue):
        self.cm_lhs_param = lhs_param
        self.cm_rhs_param = rhs_param

    def to_proto(self) -> ProtoParamsAssignment:
        obj = ProtoParamsAssignment()
        for k, v in self.cm_lhs_param.__dict__.items():
            if k.startswith("m_"):
                if isinstance(v, Enum):
                    setattr(obj.lhs_param, k[2:], v.value)
                else:
                    setattr(obj.lhs_param, k[2:], v)
        for k, v in self.cm_rhs_param.__dict__.items():
            if k.startswith("m_"):
                if isinstance(v, Enum):
                    setattr(obj.rhs_param, k[2:], v.value)
                else:
                    setattr(obj.rhs_param, k[2:], v)
            elif k.startswith("ml_") and v:
                getattr(obj.rhs_param, k[3:]).extend(v)

        return obj


class Operation:
    def __init__(
        self,
        out_param: Parameter,
        in_param_a: Parameter | ParameterValue,
        operator: TransitOperationTypeEnum,
        in_param_b: Parameter | ParameterValue | None = None,
    ):
        self.cm_in_param_a = in_param_a
        self.cm_in_param_b = in_param_b
        self.cm_out_param = out_param
        self.m_operator_type = operator

    def to_proto(self) -> ProtoParamsOperation:
        obj = ProtoParamsOperation()
        for k, v in self.__dict__.items():
            if k.startswith("m_"):
                if isinstance(v, Enum):
                    setattr(obj, k[2:], v.value)
                else:
                    setattr(obj, k[2:], v)
            elif k.startswith("cm_") and v:
                gen_proto_obj(obj, k[3:], v)
        return obj


class Expression:
    def __init__(
        self, assignments: List[Assignment] = (), operations: List[Operation] = ()
    ):
        self.cml_param_assignment = assignments
        self.cml_param_operation = operations

    def to_proto(self) -> ProtoExpressionParams:
        obj = ProtoExpressionParams()
        for k, v in self.__dict__.items():
            if k.startswith("cml_") and v:
                sub_v_objs = []
                for item in v:
                    sub_v_objs.append(item.to_proto())
                if sub_v_objs:
                    getattr(obj, k[4:]).extend(sub_v_objs)
        return obj


class ExpressionSet:
    def __init__(
        self,
        start: Union["PrimitiveNode", "Plan"],
        end: Union["PrimitiveNode", "Plan"],
        name: str = "",
    ):
        from elements.core.contrib.node import Node
        from elements.core.plan import Plan

        if isinstance(start, Node):
            self.m_start_node_name = start.m_node_name
        elif isinstance(start, Plan):
            self.m_start_node_name = start.m_plan_name
        if isinstance(end, Node):
            self.m_end_node_name = end.m_node_name
        elif isinstance(end, Plan):
            self.m_end_node_name = end.m_plan_name
        self.m_expression_set_desc = ""
        if name == "":
            name = f"exp_{self.m_start_node_name}_to_{self.m_end_node_name}"
        self.m_expression_set_name = name
        self.cml_param_expression = []

    def add_expression(self, expression: Expression):
        self.cml_param_expression.append(expression)

    def to_proto(self):
        obj = ProtoExpressionSetParams()
        for k, v in self.__dict__.items():
            if k.startswith("m_"):
                setattr(obj, k[2:], v)
            elif k.startswith("cm_") and v:
                gen_proto_obj(obj, k[3:], v)
            elif k.startswith("cml_") and v:
                sub_v_objs = []
                for item in v:
                    sub_v_objs.append(item.to_proto())
                if sub_v_objs:
                    getattr(obj, k[4:]).extend(sub_v_objs)
        return obj


class Transit:
    """
    TransitCondition > TransitCondition
                     >  ExpressionSet -> Expression
                     >  ExpressionSet -> Expression -> Operator
                     >  ExpressionSet -> Expression -> Assignment
    """

    def __init__(
        self, start: Union["Node", "Plan"], end: Union["Node", "Plan"], name: str = ""
    ):
        from elements.core.contrib.node import Node
        from elements.core.plan import Plan

        # 将后面的结点加到上一个结点的next中
        if isinstance(start, Node):
            self.m_start_node_name = start.m_node_name
        elif isinstance(start, Plan):
            self.m_start_node_name = start.m_plan_name
        if isinstance(end, Node):
            self.m_end_node_name = end.m_node_name
            start.next_primitives.append(end)
        elif isinstance(end, Plan):
            self.m_end_node_name = end.m_plan_name
            start.next_subplans.append(end)
        self.start_node = start
        self.end_node = end
        self.end_node.parent = self.start_node
        self.m_transit_period = 0
        self.m_transit_desc = ""
        self.cm_trigger_condition = Condition()
        self.expression_set = ExpressionSet(start, end)
        if name == "":
            self.m_transit_name = f"{self.m_start_node_name}_to_{self.m_end_node_name}"
        else:
            self.m_transit_name = name

    def add_condition(
        self,
        condition_type: TransitConditionTypeEnum = TransitConditionTypeEnum.NO_CHECK,
        lhs_param: Parameter = None,
        rhs_param: ParameterValue = None,
    ):
        self.cm_trigger_condition.m_condition_type = condition_type
        self.cm_trigger_condition.cm_lhs_param = lhs_param
        self.cm_trigger_condition.cm_rhs_param = rhs_param

    def add_expression(
        self, assignments: List[Assignment] = (), operations: List[Operation] = ()
    ):
        self.expression_set.add_expression(Expression(assignments, operations))

    @property
    def name(self):
        tc_names = []
        transit_str = ""
        if self.cm_trigger_condition:
            if self.cm_trigger_condition.cml_trigger_condition:
                tc_value = getattr(
                    TransitConditionValueEnum,
                    self.cm_trigger_condition.m_condition_type.value,
                ).value
                for tc in self.cm_trigger_condition.cml_trigger_condition:
                    tc_names.append(tc.name)
                transit_str = f" {tc_value}\n ".join(tc_names)
            else:
                if self.cm_trigger_condition.cm_lhs_param:
                    if hasattr(self.cm_trigger_condition.cm_lhs_param, "pt"):
                        name = self.cm_trigger_condition.cm_lhs_param.m_module_name
                    else:
                        name = self.cm_trigger_condition.cm_lhs_param.m_module_name
                    transit_str = (
                        self.cm_trigger_condition.cm_lhs_param.m_category
                        + "::"
                        + name
                        + "::"
                        + self.cm_trigger_condition.cm_lhs_param.m_name
                        + " "
                        + getattr(
                            TransitConditionValueEnum,
                            self.cm_trigger_condition.m_condition_type.value,
                        ).value
                        + " "
                    )
                    if hasattr(self.cm_trigger_condition.cm_rhs_param, "m_name"):
                        transit_str += (
                            f"{self.cm_trigger_condition.cm_rhs_param.m_name}\n"
                        )
                    else:
                        transit_str += (
                            f"{self.cm_trigger_condition.cm_rhs_param.value}\n"
                        )
        for expression in self.expression_set.cml_param_expression:
            for assignment in expression.cml_param_assignment:
                transit_str += f" {assignment.cm_lhs_param.m_category}::{assignment.cm_lhs_param.m_name} = "
                if hasattr(assignment.cm_rhs_param, "m_name"):
                    transit_str += f"{assignment.cm_rhs_param.m_name}\n"
                else:
                    transit_str += f"{assignment.cm_rhs_param.value}\n"
            for operation in expression.cml_param_operation:
                transit_str += f" {operation.cm_out_param.m_category}::{operation.cm_out_param.m_name} = "
                if operation.cm_in_param_a.m_category == "CONST":
                    transit_str += f"{operation.cm_in_param_a.value} "
                else:
                    transit_str += f"{operation.cm_in_param_a.m_category}::{operation.cm_in_param_a.m_name} "
                transit_str += f"{getattr(TransitOperationValueEnum, operation.m_operator_type.name).value} "
                if operation.cm_in_param_b:
                    if operation.cm_in_param_b.m_category == "CONST":
                        transit_str += f"{operation.cm_in_param_b.value}"
                    else:
                        transit_str += f"{operation.cm_in_param_b.m_category}::{operation.cm_in_param_b.m_name}"
                transit_str += "\n"
        return transit_str

    def to_proto(self) -> ProtoNodeTransitParams:
        obj = ProtoNodeTransitParams()
        for k, v in self.__dict__.items():
            if k.startswith("m_"):
                setattr(obj, k[2:], v)
            elif k.startswith("cm_") and v:
                gen_proto_obj(obj, k[3:], v)
        return obj
