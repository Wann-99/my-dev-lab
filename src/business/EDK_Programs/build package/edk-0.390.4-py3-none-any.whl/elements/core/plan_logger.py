class PlanLogger:

    def __init__(self, enable: bool = False, interval: int = 5, max_duration: int = 30):
        self.m_enable_log = enable
        self.m_time_interval = interval
        self.m_max_duration = max_duration
