import os
from enum import Enum
from typing import List

import grpc
from google.protobuf.json_format import MessageToJson
from google.protobuf.text_format import MessageToString
from loguru import logger

from elements.common.enums import PlanStateEnum, SoftwareVersionEnum
from elements.core import gen_proto_obj
from elements.core.contrib.node import Node, PlanNode, RootNode
from elements.core.contrib.parameter_values import ParameterValue
from elements.core.plan_logger import PlanLogger
from elements.core.primitives import PrimitiveNode
from elements.core.robot import Robot
from elements.core.transit import Transit
from elements.core.variables import PlanVariable, ProjectVariable
from elements.proto.ProtoPlanParams_pb2 import ProtoPlanParams
from elements.proto.ProtoProjectParams_pb2 import PlanName, ProtoProjectParams
from elements.settings import RobotSetting


class Plan:
    _instance = None
    proto_type = "ProtoPlanParams"
    mapping = {"config": "RootNode", "plan_log": "PlanLogger"}

    # def __new__(cls, *args, **kwargs):
    #     if not cls._instance:
    #         cls._instance = super().__new__(cls)
    #     return cls._instance

    def __init__(self, name: str, setting: RobotSetting = RobotSetting()):
        """
        :param name: plan name
        :param setting: robot setting
        """
        from elements.core.contrib.node import StartNode

        self._robot_ip = setting.ip
        self._robot_dir = setting.root_dir
        self._nanomsg_port = setting.nanomsg_port
        self._grpc_port = setting.grpc_port
        self.m_plan_name = name
        self.cm_config = RootNode()
        self.cm_plan_log = PlanLogger()
        self.m_plan_desc = ""
        self.m_sw_ver = SoftwareVersionEnum.VER_3_09
        self.m_disable_pause_and_resume = False
        self.m_enable_cart_constraint = False
        self.cml_param_assignment = []
        self.plan_variables = []
        self.project_variables = []
        self.parent = None
        self.robot = Robot(
            ip=self._robot_ip,
            grpc_port=self._grpc_port,
            nanomsg_port=self._nanomsg_port,
        )
        self.start_node = StartNode()
        # 当前plan包含primitive
        self.child_primitives: List[Node] = [self.start_node]
        # 当前plan包含subplan
        self.child_subplans: List[Plan] = []
        # 当前plan的相邻primitive
        self.next_primitives: List[Node] = []
        # 当前plan的相邻subplan
        self.next_subplans: List[Plan] = []
        self.loop_count: PlanStateEnum.LoopCnt.value["name"] = -1
        self.transits = []

    @property
    def plan_logger_enabled(self) -> bool:
        return self.cm_plan_log.m_enable_log

    @plan_logger_enabled.setter
    def plan_logger_enabled(self, value: bool):
        self.cm_plan_log.m_enable_log = value

    @property
    def plan_logger_interval(self) -> int:
        return self.cm_plan_log.m_time_interval

    @plan_logger_interval.setter
    def plan_logger_interval(self, value: int):
        assert 1 <= value <= 1000, "Sampling Period should be within [1, 1000]"
        self.cm_plan_log.m_time_interval = value

    @property
    def plan_logger_duration(self) -> int:
        return self.cm_plan_log.m_max_duration

    @plan_logger_duration.setter
    def plan_logger_duration(self, value: int):
        if not self.plan_logger_enabled:
            logger.error("plan logger must be enabled before setting duration")
            return
        assert 1 <= value <= 1000, "Max Logging Duration should be with in [1, 1000]"
        self.cm_plan_log.m_max_duration = value

    @property
    def description(self) -> str:
        return self.m_plan_desc

    @description.setter
    def description(self, value: str):
        self.m_plan_desc = value

    @property
    def sw_ver(self) -> str:
        return self.m_sw_ver.name

    @sw_ver.setter
    def sw_ver(self, value: str):
        self.m_sw_ver = SoftwareVersionEnum[value]

    def to_proto(self) -> ProtoPlanParams:
        """convert python object to ProtoPlanParams
        :return: ProtoPlanParams
        """
        obj = ProtoPlanParams()
        for k, v in self.__dict__.items():
            if k.startswith("m_"):
                setattr(obj, k[2:], v)
            elif k.startswith("cm_") and v:
                gen_proto_obj(obj, k[3:], v)
            elif k.startswith("cml_") and v:
                # when plan is subplan, user could set param_assignment
                if self.parent is not None and k == "cml_param_assignment":
                    sub_v_objs = []
                    for item in v:
                        sub_v_objs.append(item.to_proto())
                    getattr(getattr(obj, "config"), "param_assignment").extend(
                        sub_v_objs
                    )
                else:
                    sub_v_objs = []
                    for item in v:
                        sub_v_objs.append(item.to_proto())
                    getattr(obj, k[4:]).extend(sub_v_objs)
        # node and its transit
        child_nodes_proto = []
        child_transits_proto = []
        child_expression_set_proto = []
        child_plans_proto = []
        # 添加primitive proto
        for node in self.child_primitives:
            # startNode 无需添加到 proto 中
            if node.m_node_name != "startNode":
                child_nodes_proto.append(node.to_proto())
            # 添加primitive的transit
            for transit in node.transits:
                child_transits_proto.append(transit.to_proto())
                child_expression_set_proto.append(transit.expression_set.to_proto())
        # 添加subplan proto
        for plan in self.child_subplans:
            child_plans_proto.append(plan.to_proto())
            for transit in plan.transits:
                child_transits_proto.append(transit.to_proto())
                child_expression_set_proto.append(transit.expression_set.to_proto())
        obj.node_list.extend(child_nodes_proto)
        obj.transit_list.extend(child_transits_proto)
        obj.expression_set_list.extend(child_expression_set_proto)
        obj.child_plans.extend(child_plans_proto)

        # plan variables
        var_protos = []
        for var in self.plan_variables:
            var_protos.append(var.to_proto())
        obj.var_list.extend(var_protos)

        # project variables
        proj_var_protos = []
        for p_var in self.project_variables:
            proj_var_protos.append(p_var.to_proto())
        obj.proj_var_list.extend(proj_var_protos)

        return obj

    def to_json(self) -> str:
        obj = self.to_proto()
        return MessageToJson(obj, preserving_proto_field_name=True)

    def to_str(self) -> str:
        obj = self.to_proto()
        plan_str = MessageToString(obj)
        return plan_str

    def to_file(self):
        """generate a plan file, named by plan name
        :return:
        """
        obj = self.to_proto()
        plan_str = MessageToString(obj)
        with open(self.m_plan_name + ".plan", "w") as f:
            f.write(plan_str)

    def to_project(self):
        """generate a project folder, named by plan name
        :return:
        """
        obj = self.to_proto()
        plan_str = MessageToString(obj)
        os.makedirs(self.m_plan_name, exist_ok=True)
        os.chdir(self.m_plan_name)
        with open(self.m_plan_name + ".plan", "w") as f:
            f.write(plan_str)
        with open(".project", "w") as f:
            f.write("")
        with open(self.m_plan_name + ".proj", "w") as f:
            f.write("")
        os.chdir("..")

    def add_primitive(self, primitive: PrimitiveNode):
        """add primitive to current plan
        :param primitive: primitive node
        :return:
        """
        assert primitive is not None, "cannot add a None child primitive"
        missing_params = set(primitive.required_params) - set(primitive.params)
        missing_param_names = [item.value.get("name") for item in missing_params]
        assert (
            len(missing_params) == 0
        ), f"{primitive.name}'s required params {','.join(missing_param_names)} are not all set"
        for item in self.child_primitives:
            assert (
                primitive.m_node_name != item.m_node_name
            ), f"duplicate primitive name {primitive.m_node_name}"
        self.child_primitives.append(primitive)

    def delete_primitive(self, primitive: PrimitiveNode) -> bool:
        """delete primitive from current plan
        :param primitive: primitive node
        :return:
        """
        assert primitive is not None, "the primitive to delete cannot be None"
        if primitive in self.child_primitives:
            self.child_primitives.remove(primitive)
            return True
        logger.error(
            f"failed to find child primitive {primitive.m_node_name} in current plan"
        )
        return False

    def delete_primitive_by_name(self, primitive_name: str) -> bool:
        """delete child node by name
        :param primitive_name: node name
        :return: True | False
        """
        assert primitive_name != "", "the child node name to delete cannot be empty"
        for node in self.child_primitives:
            if node.m_node_name == primitive_name:
                self.child_primitives.remove(node)
                return True
        logger.error(f"failed to find primitive {primitive_name} in current plan")
        return False

    def add_plan_variable(self, var: PlanVariable):
        """add variable to current plan
        :param var: PlanVariable
        :return:
        """
        assert var is not None, "the variable to add cannot be None"
        self.plan_variables.append(var)

    def add_proj_variable(self, var: ProjectVariable):
        """add variable to current project
        :param var: ProjectVariable
        :return:
        """
        assert var is not None, "the variable to add cannot be None"
        self.project_variables.append(var)

    def delete_plan_variable(self, var: PlanVariable) -> bool:
        """
        delete variable from current plan
        """
        assert var is not None, "the variable to delete cannot be None"
        if var in self.plan_variables:
            self.plan_variables.remove(var)
            return True
        logger.error(f"failed to find variable {var} in current plan")
        return False

    def delete_proj_variable(self, var: ProjectVariable) -> bool:
        """
        delete variable from current project
        """
        assert var is not None, "the variable to delete cannot be None"
        if var in self.project_variables:
            self.project_variables.remove(var)
            return True
        logger.error(f"failed to find variable {var} in current project")
        return False

    def delete_plan_variable_by_name(self, var_name: str) -> bool:
        """
        delete variable by name
        :param var_name: node name
        :return: True | False
        """
        assert var_name != "", "the variable name to delete cannot be empty"
        for var in self.plan_variables:
            if var.name == var_name:
                self.plan_variables.remove(var)
                return True
        logger.error(f"failed to find variable {var_name} in current plan")
        return False

    def delete_proj_variable_by_name(self, var_name: str) -> bool:
        """
        delete variable by name
        :param var_name: node name
        :return: True | False
        """
        assert var_name != "", "the variable name to delete cannot be empty"
        for var in self.project_variables:
            if var.name == var_name:
                self.project_variables.remove(var)
                return True
        logger.error(f"failed to find variable {var_name} in current project")
        return False

    def add_parameter(self, param: Enum, param_value: ParameterValue):
        from elements.core.contrib.parameters import ParameterPtInput
        from elements.core.transit import Assignment

        self.cml_param_assignment.append(
            Assignment(
                lhs_param=ParameterPtInput(pt=self, pt_param=param),
                rhs_param=param_value,
            )
        )

    def add_transit(self, transit: Transit):
        """add transit to current plan
        :param transit: transit
        :return:
        """
        assert transit is not None, "transit cannot be None"
        assert hasattr(transit, "_type"), "transit must be defined in function"
        assert transit._type == "Transit", "the transit type must be Transit"
        assert isinstance(transit, Transit), "the transit must be a Transit object"

        self.transits.append(transit)

    def add_subplan(self, plan: "Plan"):
        """add plan to current plan as sub plan
        :param plan: plan
        :return:
        """
        assert plan is not None, "the plan to add cannot be None"
        assert hasattr(plan, "_type"), "plan must be defined in function"
        assert plan._type == "Plan", "the plan type must be Plan"
        assert isinstance(plan, Plan), "the plan must be a Plan object"
        assert (
            plan.project_variables == []
        ), "Project variables cannot be defined in subplan"

        for item in self.child_subplans:
            assert (
                item.m_plan_name != plan.m_plan_name
            ), f"duplicate plan name {item.m_plan_name}"

        plan.parent = self
        plan.cm_config = PlanNode(plan.m_plan_name)
        self.child_subplans.append(plan)

    def delete_subplan(self, plan: "Plan") -> bool:
        """
        delete subplan from current plan
        """
        assert plan.m_plan_name.startswith("p_"), "subplan name must start with p_"
        if plan in self.child_subplans:
            self.child_subplans.remove(plan)
            return True
        logger.error(f"failed to find subplan {plan} in current plan")
        return False

    def delete_subplan_by_name(self, name: str) -> bool:
        """
        delete subplan by name
        """
        assert name != "", "the subplan name to delete cannot be empty"
        for subplan in self.child_subplans:
            if subplan.name == name:
                self.child_subplans.remove(subplan)
                return True
        logger.error(f"failed to find subplan {name} in current plan")
        return False

    def to_graph(self):
        from transitions.extensions import GraphMachine

        states = []
        states.extend([node.m_node_name for node in self.child_primitives])
        states.extend([plan.m_plan_name for plan in self.child_subplans])
        transitions = []
        for node in self.child_primitives:
            for transit in node.transits:
                transitions.append(
                    {
                        "trigger": transit.name,
                        "source": transit.m_start_node_name,
                        "dest": transit.m_end_node_name,
                    }
                )
        for node in self.child_subplans:
            for transit in node.transits:
                transitions.append(
                    {
                        "trigger": transit.name,
                        "source": transit.m_start_node_name,
                        "dest": transit.m_end_node_name,
                    }
                )
        machine = GraphMachine(
            model=self, states=states, transitions=transitions, initial="startNode"
        )
        graph = machine.get_graph()
        graph.node_attr["fontname"] = "Microsoft Yahei"
        graph.node_attr["fontname"] = "Microsoft Yahei"
        graph.graph_attr["fontname"] = "Microsoft Yahei"
        graph.graph_attr["dpi"] = "300"  # 设置分辨率
        graph.graph_attr.pop("label")  # 删除标题
        for node in self.child_primitives:
            if node.m_node_name == "startNode":
                graph.node(
                    name=node.m_node_name,
                    shape="box",
                    color="yellow",
                    style="filled,rounded",
                    fillcolor="yellow",
                )
            else:
                graph.node(
                    name=node.m_node_name,
                    shape="box",
                    color="#285780",
                    style="filled,rounded",
                    fontcolor="white",
                    fillcolor="#285780",
                )
        for subplan in self.child_subplans:
            graph.node(
                name=subplan.m_plan_name,
                shape="box",
                color="#6DA3D5",
                style="filled,rounded",
                fontcolor="white",
                fillcolor="#6DA3D5",
            )
        graph.draw(f"graph_{self.m_plan_name}.png", prog="dot")

    async def assign(self) -> bool:
        from elements.common.exception import SubPlanAssignmentException
        from elements.proto.ProtoProjectParams_pb2 import WriteProjectRequest
        from elements.proto.ProtoProjectParams_pb2_grpc import ProjectServiceStub

        """ assign plan to RCA

        :return:
        """
        if self.parent is not None:
            raise SubPlanAssignmentException("cannot assign sub plan to RCA")

        _project_stub = ProjectServiceStub(
            grpc.insecure_channel(f"{self._robot_ip}:{self._grpc_port}")
        )
        try:
            result = _project_stub.WriteProject(
                WriteProjectRequest(
                    plan_name=PlanName(plan_name=self.m_plan_name),
                    project_params=ProtoProjectParams(),
                    plan_params=self.to_proto(),
                )
            )
            if result.ret.value != 100000:
                logger.error(
                    f"Write plan {self.m_plan_name} failed, msg: {result.info}"
                )
        except Exception as e:
            logger.error(f"Exception when write plan， message: {e}")

        result = await self.robot.assign_plan(self.m_plan_name)
        return result

    def reset_assign(self) -> bool:
        from elements.common.exception import SubPlanReAssignmentException

        if self.parent is not None:
            raise SubPlanReAssignmentException
        result = self.robot.reset_assigned_plan(self.m_plan_name)
        return result

    def run(self):
        """run plan

        :return:
        """
        raise NotImplementedError
