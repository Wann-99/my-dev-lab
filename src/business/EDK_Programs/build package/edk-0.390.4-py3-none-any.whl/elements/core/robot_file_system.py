from typing import Dict, List

import grpc
from loguru import logger

from elements.proto.RemoteFileSystem_pb2 import FileInfo, FileRequest
from elements.proto.RemoteFileSystem_pb2_grpc import RemoteFileSystemServiceStub


class RobotFileSystem:

    type_mapping = {
        "0": "file",
        "1": "directory",
        "2": "link",
    }

    def __init__(self, ip: str = "192.168.2.20", port: int = 18001):
        self.ip = ip
        self.port = port
        self._conn_str = f"{self.ip}:{self.port}"
        self.channel = grpc.insecure_channel(self._conn_str)
        self.stub = RemoteFileSystemServiceStub(self.channel)

    def info(self, path) -> Dict:
        result = self.stub.info(request=FileRequest(name=[path]))
        if not result:
            logger.error("failed to get file info")
            return {}
        elif result is not None and result.rt.error_code != 100000:
            logger.debug(f"could not get file info {path}, return code is {result.rt}")
            return {}
        else:
            result = {
                "name": result.info._values[0].name,
                "size": result.info._values[0].size,
                "mtime": result.info._values[0].mtime,
                "type": self.type_mapping[str(result.info._values[0].type)],
            }
            return result

    def list(self, path: str) -> List:
        """list file or directory under path

        :param path: path to list
        :return: list of files or directory
        """
        result = self.stub.list(request=FileRequest(name=[path]))
        if not result:
            logger.error("failed to list files")
            return []
        elif result is not None and result.rt.error_code != 100000:
            logger.error(f"failed to list file {path}, return code is {result.rt}")
            return []
        else:
            files = []
            for item in result.info._values:
                files.append(
                    {
                        "name": item.name,
                        "size": item.size,
                        "mtime": item.mtime,
                        "type": self.type_mapping[str(item.type)],
                    }
                )
            return files

    def mkdir(self, path: str) -> bool:
        """create directory

        :param path: path to create
        :return: True or False
        """
        result = self.stub.mkdir(request=FileRequest(name=[path]))
        if result.rt.error_code != 100000:
            logger.error(f"failed to mkdir {path}, msg: {result.rt.error_msg}")
            return False
        return True

    def copy(self, src: str, dst: str) -> bool:
        """copy file from src to dst
        :param src: src file name
        :param dst: dst file name
        :return: True or False
        """
        result = self.stub.copy(request=FileRequest(name=[src, dst]))
        if result.rt.error_code != 100000:
            logger.error(
                f"failed to copy file {src} to {dst}, msg: {result.rt.error_msg}"
            )
            return False
        return True

    def delete(self, path: str) -> bool:
        """delete file or directory

        :param path: file or directory name
        :return: True or False
        """
        result = self.stub.remove(request=FileRequest(name=[path]))
        if result.rt.error_code != 100000:
            logger.error(f"failed to delete file {path}, msg: {result.rt.error_msg}")
            return False
        return True

    def rename(self, src: str, dst: str) -> bool:
        """rename file or directory from src to dst

        :param src: src file or directory name
        :param dst: dst file or directory name
        :return: True or False
        """
        result = self.stub.rename(request=FileRequest(name=[src, dst]))
        if result.rt.error_code != 100000:
            logger.error(f"failed to rename file {src}, msg: {result.rt.error_msg}")
            return False
        return True

    def read(self, path: str) -> str:
        """read file content

        :param path: file name
        :return: file content
        """
        result = self.stub.read(request=FileRequest(name=[path]))
        if result.rt.error_code != 100000:
            logger.error(f"failed to read file {path}, msg: {result.rt.error_msg}")
            return ""
        return result.info._values[0].data.decode("utf-8")

    def write(self, path: str, content: str) -> bool:
        result = self.stub.write(
            request=FileInfo(name=path, size=len(content), data=content.encode("utf-8"))
        )
        if result.rt.error_code != 100000:
            logger.error(f"failed to write file {path}, msg: {result.rt.error_msg}")
            return False
        return True

    def is_file_exists(self, path: str) -> bool:
        try:
            info = self.info(path)
            if info and info.get("type") == "file":
                return True
            return False
        except Exception:
            logger.error("Inactive RPC error")
            return False

    def is_dir_exists(self, path: str) -> bool:
        try:
            info = self.info(path)
            if info and info.get("type") == "directory":
                return True
            return False
        except Exception:
            logger.error("Inactive RPC error")
            return False

    def download(self, path: str, save_file: str) -> bool:
        """download file from robot
        :param path: file name
        :param path: save_file name
        :return: True or False
        """
        try:
            result = self.stub.readStream(request=FileRequest(name=[path]))
            with open(save_file, "wb") as f:
                f.write(list(result)[0].info._values[0].data)
            return True
        except Exception:
            logger.error("Inactive RPC error")
            return False


if __name__ == "__main__":
    rfs = RobotFileSystem()
    # result = rfs.download("/root/mnt/jinwu/hello", save_file="hello.txt")
    dir_info = rfs.info("/root/mnt/jinwu")
    file_info = rfs.info("/root/mnt/jinwu/hello")
    # # files = rfs.list(path="/root/mnt")
    # result = rfs.delete("/root/mnt/jinwu1")
    # result1 = rfs.mkdir(path="/root/mnt/jinwu")
    # result2 = rfs.write(path="/root/mnt/jinwu/hello", content="hello world")
    # result3 = rfs.copy(src="/root/mnt/jinwu/hello", dst="/root/mnt/jinwu/hello2")
    # result = rfs.rename(src="/root/mnt/jinwu", dst="/root/mnt/jinwu1")
    # result41 = rfs.is_dir_exists("/root/mnt/jinwu/")
    # result42 = rfs.is_dir_exists("/root/mnt/jinwu1/")
    # result5 = rfs.is_file_exists("/root/mnt/jinwu/hello")
    # result6 = rfs.is_file_exists("/root/mnt/jinwu/hello1")
    # result7 = rfs.read("/root/mnt/jinwu/hello2")
    print()
