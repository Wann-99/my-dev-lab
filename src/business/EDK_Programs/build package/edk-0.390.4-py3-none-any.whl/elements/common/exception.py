class RobotConnectionException(Exception):
    def __init__(self, msg):
        self.msg = msg

    def __str__(self):
        return "robot connection error: %s" % self.msg


class SubPlanAssignmentException(Exception):
    def __init__(self, msg):
        self.msg = msg

    def __str__(self):
        return "subplan cannot assign: %s" % self.msg


class SubPlanReAssignmentException(Exception):
    def __init__(self, msg):
        self.msg = msg

    def __str__(self):
        return "subplan cannot re-assign: %s" % self.msg
