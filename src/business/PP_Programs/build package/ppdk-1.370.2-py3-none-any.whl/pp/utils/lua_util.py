from lupa.lua52 import LuaRuntime
from loguru import logger


def is_lua_syntax_valid(lua_code: str) -> bool:
    """ 判断lua语法是否正确 """
    lua = LuaRuntime()
    try:
        lua.execute(lua_code)
        return True
    except Exception as e:
        logger.debug(e)
        return False
