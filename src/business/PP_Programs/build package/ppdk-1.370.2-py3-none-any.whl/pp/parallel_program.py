import inspect
import json
import os
import traceback

from loguru import logger

from pp.proto.RobotServicePP_pb2 import PPCmdRequest, RemovePPRequest
from pp.settings import RobotSetting
from pp.utils.lua_util import is_lua_syntax_valid


class ParallelProgram:
    def __init__(
        self,
        setting: RobotSetting = RobotSetting(),
        port: int = 18001,
        auto_booted: bool = False,
        auto_looped: bool = False,
    ):
        self._robot_ip = setting.ip
        self._robot_port = port
        self._auto_booted = auto_booted
        self._auto_looped = auto_looped
        self._base_dir = setting.base_dir
        self._robot_dir = setting.root_dir
        self._init_builtin_funcs()
        self._init_custom_funcs()
        self._init_mock_funcs()
        self._init_service_stub()

    def _init_service_stub(self):
        import grpc

        from pp.proto.RobotServicePP_pb2_grpc import PPServiceStub

        self._channel = grpc.insecure_channel(f"{self._robot_ip}:{self._robot_port}")
        self._stub = PPServiceStub(self._channel)

    def _get_funcs(self, code_str: str) -> tuple:
        """
        获取代码中所有的函数名
        :param code_str:
        :return:
        """
        import ast

        tree = ast.parse(code_str)
        funcs = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if hasattr(node.func, "id"):
                    funcs.append(node.func.id)
                elif hasattr(node.func, "value"):
                    if node.func.value.id == "self":
                        funcs.append(node.func.attr)
                    else:
                        funcs.append(node.func.value.id)
        return set(funcs)

    def _get_builtin(self, builtin_funcs: list):
        """
        获取builtin中所有调用builtin的函数名
        :param builtin_funcs:
        :return:
        """
        code_str = self.builtin_funcs[builtin_funcs[-1]]
        for code in code_str.split("\n"):
            for func in self.builtin_funcs.keys():
                import re

                if re.search(rf"\b{func}\b", code) and func not in builtin_funcs:
                    builtin_funcs.append(func)
                    self._get_builtin(builtin_funcs)
        return builtin_funcs[::-1]

    def _get_assigns(self, code_str: str):
        """
        获取代码中所有的赋值语句
        :param code_str:
        :return: {左值: 右值, }
        """
        import ast

        tree = ast.parse(code_str)
        assigns = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                assigns[node.targets[0].id] = node.value.value
        return assigns

    def _init_builtin_funcs(self):
        # 获取buitins中定义的的lua函数代码
        with open(os.path.join(self._base_dir, "core/builtins.py"), "r") as f:
            builtins_code_str = f.read()
        self.builtin_funcs = self._get_assigns(builtins_code_str)

    def _init_mock_funcs(self):
        # 获取mock中定义的的lua函数代码
        with open(os.path.join(self._base_dir, "core/mock.py"), "r") as f:
            mock_code_str = f.read()
        self.mock_funcs = self._get_assigns(mock_code_str)

    def _init_custom_funcs(self):
        from pp.pythonlua.translator import Translator

        translator = Translator()
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        self.custom_funcs = {}
        for method in methods:
            code = inspect.getsource(method[1])
            signature = inspect.signature(method[1])
            if method[0].startswith("func_"):
                name = method[0][5:]
                func_def = f"local function {name}({', '.join([sign.name for sign in signature.parameters.values()])})"
                # 去除每行的缩进8个空格
                func_lst = code.split("\n")
                for idx, code in enumerate(func_lst):
                    if code.strip().endswith(","):
                        # 函数定义换行
                        continue
                    elif code.strip().endswith(":"):
                        code_lst = func_lst[idx + 1 :]
                        break
                assert code_lst, "func define not found"
                code_str = "\n\n".join(line[8:] for line in code_lst)
                lua_code_str = translator.translate(code_str)
                lua_code_str = "\n".join(
                    ["  " + item for item in lua_code_str.split("\n")]
                )
                self.custom_funcs[name] = {
                    "name": name,
                    "code": func_def + "\n" + lua_code_str + "\nend\n",
                    "builtins": {},
                    "funcs": [],
                }
                # 获取pp func中调用的函数
                called_funcs = self._get_funcs(code_str)
                for func in called_funcs:
                    if (
                        func.startswith("func_")
                        and func[5:] not in self.custom_funcs[name]["funcs"]
                    ):
                        self.custom_funcs[name]["funcs"].append(func[5:])
                    if (
                        func in self.builtin_funcs
                        and func not in self.custom_funcs[name]["builtins"]
                    ):
                        builtin_funcs = self._get_builtin([func])
                        self.custom_funcs[name]["builtins"].update(
                            {f: self.builtin_funcs[f] for f in builtin_funcs}
                        )

    def _get_lua_code(self) -> dict:
        from pp.pythonlua.translator import Translator

        translator = Translator()
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        result = {}

        for method in methods:
            code = inspect.getsource(method[1])
            signature = inspect.signature(method[1])

            # 转换所有pp_开头的python方法为lua方法
            if method[0].startswith("pp_"):
                name = method[0][3:]
                # 定义每个pp的配置, 用户可以通过参数指定
                _auto_booted = self._auto_booted
                _auto_looped = self._auto_looped
                for sign in signature.parameters.values():
                    if sign.name == "auto_booted":
                        _auto_booted = sign.default
                    elif sign.name == "auto_looped":
                        _auto_looped = sign.default
                # 去除第一行def
                # 去除每行的缩进8个空格
                code_str = "\n\n".join(line[8:] for line in code.split("\n")[1:])
                lua_code_str = translator.translate(code_str)
                result[name] = {
                    "name": name,
                    "code": lua_code_str,
                    "config": json.dumps(
                        {
                            "auto_booted": _auto_booted,
                            "auto_looped": _auto_looped,
                            "desc": "",
                            "is_enabled": False,
                        }
                    ),
                    "builtins": [],
                    "funcs": [],
                }
                # 获取pp python中调用的函数
                called_funcs = self._get_funcs(code_str)
                for func in called_funcs:
                    # pp 中调用的自定义func
                    if (
                        func.startswith("func_")
                        and func[5:] not in result[name]["funcs"]
                    ):
                        result[name]["funcs"].append(func[5:])
                    # pp 中的内置函数
                    elif (
                        func in self.builtin_funcs
                        and func not in result[name]["builtins"]
                    ):
                        called_builtin = self._get_builtin([func])
                        for builtin in called_builtin:
                            if builtin not in result[name]["builtins"]:
                                result[name]["builtins"].append(builtin)
        return result

    def to_lua(self, check: bool = False):
        data = self._get_lua_code()
        for pp in data:
            if not os.path.exists(pp):
                os.mkdir(pp)
            else:
                if os.path.isfile(pp):
                    raise Exception(f"{pp} already exists as a file")
            pwd = os.getcwd()
            try:
                os.chdir(pp)
                if os.path.exists(f"{pp}.lua"):
                    os.remove(f"{pp}.lua")
                with open(f"{pp}.lua", "a+") as f:
                    # 添加 builtin
                    for bi in data[pp]["builtins"]:
                        bi_code = self.builtin_funcs[bi]
                        f.write(bi_code + "\n")
                    # 添加 自定义func中的builtin
                    for func in data[pp]["funcs"]:
                        for bi in self.custom_funcs[func]["builtins"]:
                            if bi not in data[pp]["builtins"]:
                                bi_code = self.builtin_funcs[bi]
                                f.write(bi_code + "\n")
                    # 添加 自定义func中的自定义func
                    defined_function = []
                    for func in data[pp]["funcs"]:
                        for custom_func in self.custom_funcs[func]["funcs"]:
                            func_code = self.custom_funcs[custom_func]["code"]
                            if custom_func not in defined_function:
                                defined_function.append(custom_func)
                                f.write(func_code + "\n")
                    # 添加 自定义func
                    for func in data[pp]["funcs"]:
                        func_code = self.custom_funcs[func]["code"]
                        if func not in defined_function:
                            defined_function.append(func)
                            f.write(func_code + "\n")
                    # 添加 pp
                    lua_code_str = data[pp]["code"]
                    f.write(lua_code_str + "\n")
                pp_config = data[pp]["config"]
                # 创建 ppConfig.json
                with open("ppConfig.json", "w") as f:
                    f.write(pp_config)
                # 创建 pp.xml，防止从UI编辑pp时，RCA奔溃
                with open(f"{pp}.xml", "w") as f:
                    f.write("")
                if check:
                    with open(f"{pp}.lua") as f:
                        lua_code = f.read()
                    for mock_f in self.mock_funcs:
                        lua_code = self.mock_funcs[mock_f] + "\n" + lua_code
                    if not is_lua_syntax_valid(lua_code):
                        logger.error(f"lua syntax is invalid in {pp}.lua")
                        logger.debug(lua_code)
            except Exception as e:
                traceback.print_exc()
                logger.error(e)
            finally:
                os.chdir(pwd)

    def assign(self) -> dict:
        from pp.proto.RobotServicePP_pb2 import (
            AddPPRequest,
            UpdatePPContentRequest,
            UpdatePPOptionRequest,
        )

        self.validate()
        data = self._get_lua_code()
        result = {}
        for pp in data:
            ret1 = self._stub.AddPP(AddPPRequest(pp_name=pp))
            # 110000 新的pp，310008 pp已存在
            assert ret1.value in [
                110000,
                310008,
            ], f"failed to add pp, ret code: {ret1.value}, ret info: {ret1.info}"
            content = ""
            # 添加 builtin
            for bi in data[pp]["builtins"]:
                bi_code = self.builtin_funcs[bi]
                content += bi_code + "\n"
            # 添加 自定义func中的builtin
            for func in data[pp]["funcs"]:
                for bi in self.custom_funcs[func]["builtins"]:
                    if bi not in data[pp]["builtins"]:
                        bi_code = self.builtin_funcs[bi]
                        content += bi_code + "\n"
            # 添加 自定义func中的自定义func
            defined_function = []
            for func in data[pp]["funcs"]:
                for custom_func in self.custom_funcs[func]["funcs"]:
                    func_code = self.custom_funcs[custom_func]["code"]
                    if custom_func not in defined_function:
                        defined_function.append(custom_func)
                        content += func_code + "\n"
            # 添加 自定义func
            for func in data[pp]["funcs"]:
                func_code = self.custom_funcs[func]["code"]
                if func not in defined_function:
                    defined_function.append(func)
                    content += func_code + "\n"
            # 添加 pp
            lua_code_str = data[pp]["code"]
            content += lua_code_str + "\n"
            # 更新 pp
            ret2 = self._stub.UpdatePPContent(
                UpdatePPContentRequest(
                    pp_name=pp,
                    script_file_content=content,
                    blocky_file_content="<xml xmlns='https://developers.google.com/blockly/xml'></xml>\n",
                )
            )
            assert ret2.value in [110000], f"failed to update pp content, ret: {ret2}"
            ret3 = self._stub.UpdatePPOption(
                UpdatePPOptionRequest(
                    pp_name=pp,
                    pp_auto_booted=json.loads(data[pp]["config"])["auto_booted"],
                    pp_auto_looped=json.loads(data[pp]["config"])["auto_looped"],
                )
            )
            assert ret3.value in [110000], f"failed to update pp option, ret: {ret3}"
            result[pp] = True
        return result

    def remove(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.RemovePP(RemovePPRequest(pp_name=pp))
        return result

    def enable(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.EnablePP(PPCmdRequest(pp_name=pp))
        return result

    def disable(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.DisablePP(PPCmdRequest(pp_name=pp))
        return result

    def pause(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.pausePP(PPCmdRequest(pp_name=pp))
        return result

    def resume(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.resumePP(PPCmdRequest(pp_name=pp))
        return result

    def start(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.startPP(PPCmdRequest(pp_name=pp))
        return result

    def stop(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.stopPP(PPCmdRequest(pp_name=pp))
        return result

    def clear_fault(self) -> dict:
        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.clearFaultPP(PPCmdRequest(pp_name=pp))
        return result

    def _get_variable_list(self):
        import grpc
        from google.protobuf.json_format import MessageToDict

        from pp.proto.RobotServiceSystem_pb2_grpc import RobotServiceSystemStub

        _channel = grpc.insecure_channel(f"{self._robot_ip}:{self._robot_port}")
        from pp.proto.RobotServiceSystem_pb2 import getVariableListRequest

        _service_stub = RobotServiceSystemStub(_channel)
        ret = _service_stub.getRunTimeVariableList(getVariableListRequest())
        var_dict = MessageToDict(ret)
        return var_dict["dataList"] if var_dict else []

    def _get_called_gv(self):
        from pp.pythonlua.translator import Translator

        translator = Translator()
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        variables = []
        for method in methods:
            code = inspect.getsource(method[1])
            if method[0].startswith("pp_") or method[0].startswith("func_"):
                code_str = "\n\n".join(line[8:] for line in code.split("\n")[1:])
                translator.translate(code_str)
                variables.extend(translator.called_args["variable"])
        return variables

    def _has_global_variable(self, variable_names: list) -> bool:
        _all_exist = True
        var_list = self._get_variable_list()
        for name in variable_names:
            _has_variable = False
            for var in var_list:
                if var["name"] == name and var["category"] == "GLOBAL_VAR":
                    _has_variable = True
                    break
            assert _has_variable, f"Global variable:{name} is not exist,please check."
            _all_exist &= _has_variable
        return _all_exist

    def validate_global_variable(self):
        variables = self._get_called_gv()
        if variables:
            assert self._has_global_variable(
                variables
            ), "Global variable is not exist, please check."

    def validate(self):
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        for method in methods:
            if method[0].startswith("validate_"):
                func = getattr(self, method[0])
                func()
