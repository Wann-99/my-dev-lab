first_index_string = """
function first_index_string(str, substr)
  local i = string.find(str, substr, 1, true)
  if i == nil then
    return -1
  end
  return i - 1
end
"""

last_index_string = """
function last_index_string(str, substr)
  local i = string.find(string.reverse(str), string.reverse(substr), 1, true)
  if i then
    return #str + 2 - i - #substr - 1
  end
  return -1
end
"""

split_string = """
function split_string(input, delim)
  local t = {}
  local pos = 1
  while true do
    next_delim = string.find(input, delim, pos)
    if next_delim == nil then
      table.insert(t, string.sub(input, pos))
      break
    else
      table.insert(t, string.sub(input, pos, next_delim-1))
      pos = next_delim + #delim
    end
  end
  return t
end
"""

concat_string = """
function concat_string(...)
    local args = {...}
    return table.concat(args, "")
end
"""

sub_string = """
function sub_string(str, start_index, end_index)
    local len = #str

    if start_index < 0 then
        start_index = len + start_index
    end
    if end_index < 0 then
        end_index = len + end_index
    end

    assert(start_index >= 0 and start_index <= len, "Start index out of range")
    assert(end_index >= 0 and end_index <= len, "End index out of range")
    assert(start_index <= end_index, "Start index must less equal than end index")

    return string.sub(str, start_index + 1, end_index)
end
"""

join_list = """
function join_list(list, delim)
  local str = table.concat(list, delim)
  return str
end
"""

create_list = """
function create_list(...)
  local list = {}
  for i, value in ipairs({...}) do
        table.insert(list, value)
  end
  return list
end
"""

insert_list = """
function insert_list(list, index, value)
  assert((type(index) == "number"), "index must be a number")
  assert((index >= 0 and index <= #list), "index out of range")
  table.insert(list, index + 1, value)
  return list
end
"""

remove_list = """
function remove_list(list, index)
  assert((#list ~= 0), "empty list")
  assert((type(index) == "number"), "index must be a number")
  assert((index >= 0 and index <= #list-1), "index out of range")
  return table.remove(list, index + 1)
end
"""

get_list = """
function get_list(list, index)
  assert((#list ~= 0), "empty list")
  assert((type(index) == "number"), "index must be a number")
  assert((index >= 0 and index <= #list-1), "index out of range")
  return list[index + 1]
end
"""

set_list = """
function set_list(list, index, value)
  assert((#list ~= 0), "empty list")
  assert((type(index) == "number"), "index must be a number")
  assert((index >= 0 and index <= #list-1), "index out of range")
  list[index + 1] = value
  return list
end
"""

to_string = """
function to_binary(num)
    if num == 0 then
        return "0"
    end
    local binary = ""
    while num > 0 do
        local remainder = num % 2
        binary = remainder .. binary
        num = math.floor(num / 2)
    end
    return binary
end

function to_string(num, base)
    base = base or 10
    if base == 10 then
        return tostring(num)
    elseif base == 2 then
        return to_binary(num)
    elseif base == 8 then
        return string.format("%o", num)
    elseif base == 16 then
        return string.format("%x", num)
    else
        error("Unsupported base: " .. base)
    end
end
"""

to_number = """
function to_number(str, base)
    base = base or 10
    local num = tonumber(str, base)
    if num == nil then
        error("Can not convert to number: " .. str .. " (base: " .. base .. ")")
    end
    return num
end
"""

update_global_var_jpos = """
local function update_global_var_jpos(var_name, new_jpos)
  assert((var_name ~= ""), "var name must be set")
  assert((#new_jpos == 3) or (#new_jpos == 7), "new_jpos must 7 items")
  local new_var_value = get_global_var(var_name)
  local j_length = #new_jpos
  for idx=1,j_length,1 do
      if new_jpos[idx] ~= "" then
          new_var_value[idx] = new_jpos[idx]
      end
  end
  set_global_var(var_name, new_var_value)
end
"""

update_global_var_pose = """
local function update_global_var_pose(var_name, new_tcp_pos, unit)
  assert((var_name ~= ""), "var name must be set")
  assert((#new_tcp_pos == 6), "new_tcp_pos must 6 items")
  local new_var_value = get_global_var(var_name)
  for idx=1,3,1 do
      if (new_tcp_pos[idx] ~= "") and (unit == "millimeter") then
          new_var_value[idx] = (new_tcp_pos[idx] / 1000)
      elseif (new_tcp_pos[idx] ~= "") and (unit == "meter") then
          new_var_value[idx] = new_tcp_pos[idx]
      end
  end
  for idx=4,6,1 do
      if (new_tcp_pos[idx] ~= "") then
          new_var_value[idx] = new_tcp_pos[idx]
      end
  end
  set_global_var(var_name, new_var_value)
end
"""

update_global_var_coord = """
local function update_global_var_coord(var_name, new_tcp_pos, new_coordinate, new_ref_joint_positions, new_ext_axis, unit)
  assert((var_name ~= ""), "var name must be set")
  local new_var_value = get_global_var(var_name)
  if new_tcp_pos then
      assert((#new_tcp_pos == 6), "new_tcp_pos must 6 items")
      for idx=1,3,1 do
          if (new_tcp_pos[idx] ~= "") and (unit == "millimeter") then
              new_var_value[idx] = (new_tcp_pos[idx] / 1000)
          elseif (new_tcp_pos[idx] ~= "") and (unit == "meter") then
              new_var_value[idx] = new_tcp_pos[idx]
          end
      end
      for idx=4,6,1 do
          if (new_tcp_pos[idx] ~= "") then
              new_var_value[idx] = new_tcp_pos[idx]
          end
      end
  end
  if new_coordinate then
      assert((#new_coordinate == 2), "new_coordinate must 2 items")
      for idx=1,2,1 do
          if (new_coordinate[idx] ~= "") then
              new_var_value[(idx + 6)] = new_coordinate[idx]
          end
      end
  end
  if new_ref_joint_positions then
      assert((#new_ref_joint_positions == 7), "new_ref_joint_positions must 7 items")
      for idx=1,7,1 do
          if (new_ref_joint_positions[idx] ~= "") then
              new_var_value[(idx + 8)] = new_ref_joint_positions[idx]
          end
      end
  end
  if new_ext_axis then
      assert((#new_ext_axis == 6), "new_ext_axis must 6 items")
      for idx=1,6,1 do
          if (new_ext_axis[idx] ~= "") then
              new_var_value[(idx + 15)] = new_ext_axis[idx]
          end
      end
  end
  set_global_var(var_name, new_var_value)
end
"""

int32_to_registers = """
function int32_to_registers(value)
    if value < 0 then
        value = 4294967296 + value
    end
    local high = math.floor(value / 65536)
    local low  = value % 65536
    return {high, low}
end
"""

registers_to_int32 = """
function registers_to_int32(high, low)
    local value = high * 65536 + low
    if value >= 2147483648 then
        value = value - 4294967296
    end
    return value
end
"""

float_to_registers = """
function float_to_registers(f)
    local sign = 0
    if f < 0 then
        sign = 1
        f = -f
    end

    local mantissa, exponent = math.frexp(f)
    if f == 0 then
        return {0, 0}
    end

    exponent = exponent + 126
    mantissa = mantissa * 2 - 1
    mantissa = mantissa * (2^23)

    local bits = sign * 0x80000000 + exponent * 0x800000 + math.floor(mantissa + 0.5)
    local high = math.floor(bits / 65536)
    local low = bits % 65536
    return {high, low}
end
"""

registers_to_float = """
function registers_to_float(high, low)
    local bits = high * 65536 + low
    if bits == 0 then return 0.0 end

    local sign = (bits >= 0x80000000) and -1 or 1
    local exponent = math.floor(bits / 0x800000) % 0x100
    local mantissa = bits % 0x800000

    local f = 1 + mantissa / (2^23)
    return sign * f * (2 ^ (exponent - 127))
end
"""

read_flx_modbus_tcp_int = """
function read_flx_modbus_tcp_int(master_id, slave_id, offset, length)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 63), "offset must be between 0 and 63")
  assert((1 <= length and length <= 64), "length must be between 1 and 64")
  local data = modbus_tcp_read(master_id, slave_id, (length * 2), 1, (176 + (offset * 2)))
  local values = {}
  for i=1,(math.floor(#data / 2)),1 do
      local low = data[((2 * i) - 1)]
      local high = data[(2 * i)]
      table.insert(values, (#values + 1), registers_to_int32(high, low))
      ::loop_label_2::
  end
  return values
end
"""

write_flx_modbus_tcp_float = """
function write_flx_modbus_tcp_float(master_id, slave_id, offset, data)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 63), "offset must be between 0 and 63")
  assert((1 <= #data and #data <= 64), "length of data must be between 1 and 64")
  local values = {}
  for _, raw_data in ipairs(data) do
      local register_list = float_to_registers(raw_data)
      table.insert(values, (#values + 1), register_list[2])
      table.insert(values, (#values + 1), register_list[1])
      ::loop_label_3::
  end
  local result = modbus_tcp_write(master_id, slave_id, (#data * 2), 1, (144 + (offset * 2)), values)
  return result
end
"""

read_flx_modbus_tcp_bit = """
function read_flx_modbus_tcp_bit(master_id, slave_id, offset, length)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 255), "offset must be between 0 and 255")
  assert((1 <= length and length <= 256), "length must be between 1 and 256")
  local data = modbus_tcp_read(master_id, slave_id, length, 0, offset)
  return data
end
"""

read_flx_modbus_tcp_float = """
function read_flx_modbus_tcp_float(master_id, slave_id, offset, length)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 63), "offset must be between 0 and 63")
  assert((1 <= length and length <= 64), "length must be between 1 and 64")
  local data = modbus_tcp_read(master_id, slave_id, (length * 2), 1, (304 + (offset * 2)))
  local values = {}
  for i=1,(math.floor(#data / 2)),1 do
      local low = data[((2 * i) - 1)]
      local high = data[(2 * i)]
      table.insert(values, (#values + 1), registers_to_float(high, low))
      ::loop_label_1::
  end
  return values
end
"""

write_flx_modbus_tcp_bit = """
function write_flx_modbus_tcp_bit(master_id, slave_id, offset, data)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 255), "offset must be between 0 and 255")
  assert((1 <= #data and #data <= 256), "length of data must be between 1 and 256")
  local result = modbus_tcp_write(master_id, slave_id, #data, 0, offset, data)
  return result
end
"""

write_flx_modbus_tcp_int = """
function write_flx_modbus_tcp_int(master_id, slave_id, offset, data)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 63), "offset must be between 0 and 63")
  assert((1 <= #data and #data <= 64), "length of data must be between 1 and 64")
  local values = {}
  for _, raw_data in ipairs(data) do
      local register_list = int32_to_registers(raw_data)
      table.insert(values, (#values + 1), register_list[2])
      table.insert(values, (#values + 1), register_list[1])
      ::loop_label_4::
  end
  local result = modbus_tcp_write(master_id, slave_id, (#data * 2), 1, (16 + (offset * 2)), values)
  return result
end
"""

read_modbus_rtu_int32 = """
function read_modbus_rtu_int32(master_id, slave_id, offset, type, length)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 63), "offset must be between 0 and 63")
  assert((1 <= length and length <= 64), "length must be between 1 and 64")
  local data = modbus_rtu_read(master_id, slave_id, (length * 2), type, (offset * 2))
  local values = {}
  for i=1,(math.floor(#data / 2)),1 do
      local low = data[((2 * i) - 1)]
      local high = data[(2 * i)]
      table.insert(values, (#values + 1), registers_to_int32(high, low))
      ::loop_label_2::
  end
  return values
end
"""

write_modbus_rtu_float = """
function write_modbus_rtu_float(master_id, slave_id, offset, data)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 63), "offset must be between 0 and 63")
  assert((1 <= #data and #data <= 64), "length of data must be between 1 and 64")
  local values = {}
  for _, raw_data in ipairs(data) do
      local register_list = float_to_registers(raw_data)
      table.insert(values, (#values + 1), register_list[2])
      table.insert(values, (#values + 1), register_list[1])
      ::loop_label_3::
  end
  local result = modbus_rtu_write(master_id, slave_id, (#data * 2), 1, (offset * 2), values)
  return result
end
"""

read_modbus_rtu_bit = """
function read_modbus_rtu_bit(master_id, slave_id, offset, type, length)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 255), "offset must be between 0 and 255")
  assert((1 <= length and length <= 256), "length must be between 1 and 256")
  local data = modbus_rtu_read(master_id, slave_id, length, type, offset)
  return data
end
"""

read_modbus_rtu_float = """
function read_modbus_rtu_float(master_id, slave_id, offset, type, length)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 63), "offset must be between 0 and 63")
  assert((1 <= length and length <= 64), "length must be between 1 and 64")
  local data = modbus_rtu_read(master_id, slave_id, (length * 2), type, (offset * 2))
  local values = {}
  for i=1,(math.floor(#data / 2)),1 do
      local low = data[((2 * i) - 1)]
      local high = data[(2 * i)]
      table.insert(values, (#values + 1), registers_to_float(high, low))
      ::loop_label_1::
  end
  return values
end
"""

write_modbus_rtu_bit = """
function write_modbus_rtu_bit(master_id, slave_id, offset, data)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 255), "offset must be between 0 and 255")
  assert((1 <= #data and #data <= 256), "length of data must be between 1 and 256")
  local result = modbus_rtu_write(master_id, slave_id, #data, 0, offset, data)
  return result
end
"""

write_modbus_rtu_int32 = """
function write_modbus_rtu_int32(master_id, slave_id, offset, data)
  assert((1 <= master_id and master_id <= 5), "master id must be between 1 and 5")
  assert((1 <= slave_id and slave_id <= 247), "slave id must be between 1 and 247")
  assert((0 <= offset and offset <= 63), "offset must be between 0 and 63")
  assert((1 <= #data and #data <= 64), "length of data must be between 1 and 64")
  local values = {}
  for _, raw_data in ipairs(data) do
      local register_list = int32_to_registers(raw_data)
      table.insert(values, (#values + 1), register_list[2])
      table.insert(values, (#values + 1), register_list[1])
      ::loop_label_4::
  end
  local result = modbus_rtu_write(master_id, slave_id, (#data * 2), 1, (offset * 2), values)
  return result
end
"""

sub_list = """
function sub_list(list, start_index, end_index)
    assert((0 <= start_index), "Start index error: start must greater equal than 0")
    assert((start_index <= end_index), "Index error: end must greater equal than start")
    assert((end_index <= #list), "End index error: end must less equal than length of list")
    local sliced = {}
    for i=start_index+1, end_index, 1 do
        table.insert(sliced, (#sliced+1), list[i])
    end
    return sliced
end
"""

append_list = """
function append_list(list, value)
     table.insert(list, (#list+1), value)
     return list
end
"""

remove_sub_list = """
function remove_sub_list(list, start_index, end_index)
    assert((0 <= start_index), "Start index error: start must greater equal than 0")
    assert((start_index <= end_index), "Index error: end must greater equal than start")
    assert((end_index <= #list), "End index error: end must less equal than length of list")
    for i = end_index, start_index+1, -1 do
        table.remove(list, i)
    end
end
"""

remove_sub_string = """
function remove_sub_string(string, start_index, end_index)
    assert((0 <= start_index), "Start index error: start must greater equal than 0")
    assert((start_index <= end_index), "Index error: end must greater equal than start")
    assert((end_index <= #string), "End index error: end must less equal than length of string")
    return string.sub(string, 1, start_index) .. string.sub(string, end_index + 1, #string)
end
"""

compare_list = """
function compare_list(list1, list2)
    if type(list1) ~= "table" or type(list2) ~= "table" then
        return false
    end

    local len1 = #list1
    local len2 = #list2

    if len1 ~= len2 then
        return false
    end

    for i = 1, len1 do
        local v1 = list1[i]
        local v2 = list2[i]
        if type(v1) == "table" and type(v2) == "table" then
            if not compare_list(v1, v2) then
                return false
            end
        elseif v1 ~= v2 then
            return false
        end
    end

    return true
end
"""

compare_dict = """
function compare_dict(dict1, dict2)
    if type(dict1) ~= type(dict2) then
        return false
    end
    if type(dict1) ~= "table" then
        return dict1 == dict2
    end

    for k, v in pairs(dict1) do
        local v2 = rawget(dict2, k)
        if v2 == nil or not compare_dict(v, v2) then
            return false
        end
    end
    for k in pairs(dict2) do
        if rawget(dict1, k) == nil then
            return false
        end
    end
    return true
end
"""
