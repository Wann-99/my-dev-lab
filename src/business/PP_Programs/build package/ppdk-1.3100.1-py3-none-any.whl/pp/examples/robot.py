from pp.core.robot import (
    clear_fault,
    clear_object_pool,
    fault,
    get_anybus_di,
    get_global_var,
    get_io,
    get_modbustcp_slave_di,
    get_profinet_slave_di,
    get_system_di,
    get_system_state,
    get_tool,
    get_workcoord,
    read_trajectory_file,
    set_anybus_do,
    set_anybus_do_pulse_ms,
    set_global_var,
    set_io,
    set_io_pulse_ms,
    set_modbustcp_slave_do,
    set_modbustcp_slave_do_pulse_ms,
    set_profinet_slave_do,
    set_profinet_slave_do_pulse_ms,
    set_system_do,
    set_system_do_pulse_ms,
    set_system_state,
    set_tool,
    set_workcoord,
    update_global_var_coord,
    update_global_var_jpos,
    update_global_var_pose,
    update_object_pool,
    wait_anybus_di_ms,
    wait_io_ms,
    wait_modbustcp_slave_di_ms,
    wait_profinet_slave_di_ms,
    wait_system_di_ms,
    write_trajectory_file,
)
from pp.enums import (
    AnyBusSlaveInputEnum,
    AnyBusSlaveOutputEnum,
    CoordinateNameEnum,
    CoordinateSystemEnum,
    GPIOEnum,
    GPIOInPortEnum,
    GPIOOutPortEnum,
    MetricSystemEnum,
    ModbusTCPInputEnum,
    ModbusTCPOutputEnum,
    ProfinetSlaveInputEnum,
    ProfinetSlaveOutputEnum,
    SystemStateEnum,
)
from pp.parallel_program import ParallelProgram


class ExampleRobotSignal(ParallelProgram):
    def pp_wait_io_status(self):
        """Monitor whether the value of the specified I/O system port changes to the expected value
        within the set time (When set to 0, keep waiting)"""
        # GPIOSystem [I/O port: "gpioIn0" - "gpioIn17"]
        wait_io_ms(GPIOEnum.SYSTEM, GPIOInPortEnum.GPIO_IN_0, True, 0)
        wait_system_di_ms(GPIOInPortEnum.GPIO_IN_1, False, 1)

        # Profinet [I/O port: "pfBitIn0" - "pfBitIn255", "pfIntIn0" - "pfIntIn7", "pfFloatIn0" - "pfFloatIn7"]
        wait_io_ms(
            GPIOEnum.PROFINET_SLAVE, ProfinetSlaveInputEnum.PF_BIT_IN_0, True, 1000
        )
        wait_profinet_slave_di_ms(ProfinetSlaveInputEnum.PF_INT_IN_0, True, 1000)
        wait_profinet_slave_di_ms(ProfinetSlaveInputEnum.PF_FLOAT_IN_0, True, 1000)

        # Modbus TCP [I/O port: "mTBitIn0" - "mTBitIn255", "mTIntIn0" - "mTIntIn63", "mTFloatIn0" - "mTFloatIn63"]
        wait_io_ms(GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPInputEnum.MT_BIT_IN_0, True, 1000)
        wait_modbustcp_slave_di_ms(ModbusTCPInputEnum.MT_INT_IN_0, True, 1000)
        wait_modbustcp_slave_di_ms(ModbusTCPInputEnum.MT_FLOAT_IN_0, True, 1000)

        # Anybus [I/O port: "aBBitIn0" - "aBBitIn255", "aBIntIn0" - "aBIntIn31", "aBFloatIn0" - "aBFloatIn31"]
        wait_io_ms(GPIOEnum.ANYBUS, AnyBusSlaveInputEnum.AB_BIT_IN_0, True, 1000)
        wait_anybus_di_ms(AnyBusSlaveInputEnum.AB_INT_IN_0, True, 1000)
        wait_anybus_di_ms(AnyBusSlaveInputEnum.AB_FLOAT_IN_0, True, 1000)

    def pp_set_the_value_of_io(self):
        """Set the value of the specified I/O system port"""
        # GPIOSystem [I/O port: "gpioOut0" - "gpioOut17"]
        set_io(GPIOEnum.SYSTEM, GPIOOutPortEnum.GPIO_OUT_0, True)
        set_system_do(GPIOOutPortEnum.GPIO_OUT_1, False)

        # Profinet [I/O port: "pfBitOut0" - "pfBitOut255", "pfIntOut0" - "pfIntOut7", "pfFloatOut0" - "pfFloatOut7"]
        set_io(GPIOEnum.PROFINET_SLAVE, ProfinetSlaveOutputEnum.PF_BIT_OUT_0, True)
        set_profinet_slave_do(ProfinetSlaveOutputEnum.PF_INT_OUT_0, 1)
        set_profinet_slave_do(ProfinetSlaveOutputEnum.PF_FLOAT_OUT_0, 1.2)

        # Modbus TCP [I/O port: "mTBitOut0" - "mTBitOut255", "mTIntOut0" - "mTIntOut63", "mTFloatOut0" - "mTFloatOut63"]
        set_io(GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPOutputEnum.MT_BIT_OUT_0, True)
        set_modbustcp_slave_do(ModbusTCPOutputEnum.MT_INT_OUT_0, 1)
        set_modbustcp_slave_do(ModbusTCPOutputEnum.MT_FLOAT_OUT_0, 1.2)

        # Anybus [I/O port: "aBBitOut0" - "aBBitOut255", "aBIntOut0" - "aBIntOut31", "aBFloatOut0" - "aBFloatOut31"]
        set_io(GPIOEnum.ANYBUS, AnyBusSlaveOutputEnum.AB_BIT_OUT_0, True)
        set_anybus_do(AnyBusSlaveOutputEnum.AB_INT_OUT_0, 1)
        set_anybus_do(AnyBusSlaveOutputEnum.AB_FLOAT_OUT_0, 1.2)

    def pp_send_pulse_on_io(self):
        """Send a pulse signal to the specified I/O system port"""
        # GPIOSystem [I/O port: "gpioOut0" - "gpioOut17"]
        set_io_pulse_ms(GPIOEnum.SYSTEM, GPIOOutPortEnum.GPIO_OUT_0, True, 1000)
        set_system_do_pulse_ms(GPIOOutPortEnum.GPIO_OUT_1, False, 1000)

        # Profinet [I/O port: "pfBitOut0" - "pfBitOut255", "pfIntOut0" - "pfIntOut7", "pfFloatOut0" - "pfFloatOut7"]
        set_io_pulse_ms(
            GPIOEnum.PROFINET_SLAVE, ProfinetSlaveOutputEnum.PF_BIT_OUT_0, True, 1000
        )
        set_profinet_slave_do_pulse_ms(ProfinetSlaveOutputEnum.PF_INT_OUT_0, True, 1000)
        set_profinet_slave_do_pulse_ms(
            ProfinetSlaveOutputEnum.PF_FLOAT_OUT_0, True, 1000
        )

        # Modbus TCP [I/O port: "mTBitOut0" - "mTBitOut255", "mTIntOut0" - "mTIntOut63", "mTFloatOut0" - "mTFloatOut63"]
        set_io_pulse_ms(
            GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPOutputEnum.MT_BIT_OUT_0, True, 1000
        )
        set_modbustcp_slave_do_pulse_ms(ModbusTCPOutputEnum.MT_INT_OUT_0, True, 1000)
        set_modbustcp_slave_do_pulse_ms(ModbusTCPOutputEnum.MT_FLOAT_OUT_0, True, 1000)

        # Anybus [I/O port: "aBBitOut0" - "aBBitOut255", "aBIntOut0" - "aBIntOut31", "aBFloatOut0" - "aBFloatOut31"]
        set_io_pulse_ms(GPIOEnum.ANYBUS, AnyBusSlaveOutputEnum.AB_BIT_OUT_0, True, 1000)
        set_anybus_do_pulse_ms(AnyBusSlaveOutputEnum.AB_INT_OUT_0, True, 1000)
        set_anybus_do_pulse_ms(AnyBusSlaveOutputEnum.AB_FLOAT_OUT_0, True, 1000)

    def pp_get_io_value(self):
        """Gets the value of the specified I/O system port"""
        # GPIOSystem [I/O port: "gpioIn0" - "gpioIn17"]
        print(get_io(GPIOEnum.SYSTEM, GPIOInPortEnum.GPIO_IN_0))
        print(get_system_di(GPIOInPortEnum.GPIO_IN_1))

        # Profinet [I/O port: "pfBitIn0" - "pfBitIn255", "pfIntIn0" - "pfIntIn7", "pfFloatIn0" - "pfFloatIn7"]
        print(get_io(GPIOEnum.PROFINET_SLAVE, ProfinetSlaveInputEnum.PF_BIT_IN_0))
        print(get_profinet_slave_di(ProfinetSlaveInputEnum.PF_INT_IN_0))
        print(get_profinet_slave_di(ProfinetSlaveInputEnum.PF_FLOAT_IN_0))

        # Modbus TCP [I/O port: "mTBitIn0" - "mTBitIn255", "mTIntIn0" - "mTIntIn63", "mTFloatIn0" - "mTFloatIn63"]
        print(get_io(GPIOEnum.MODBUSTCP_SLAVE, ModbusTCPInputEnum.MT_BIT_IN_0))
        print(get_modbustcp_slave_di(ModbusTCPInputEnum.MT_INT_IN_0))
        print(get_modbustcp_slave_di(ModbusTCPInputEnum.MT_FLOAT_IN_0))

        # Anybus [I/O port: "aBBitIn0" - "aBBitIn255", "aBIntIn0" - "aBIntIn31", "aBFloatIn0" - "aBFloatIn31"]
        print(get_io(GPIOEnum.ANYBUS, AnyBusSlaveInputEnum.AB_BIT_IN_0))
        print(get_anybus_di(AnyBusSlaveInputEnum.AB_INT_IN_0))
        print(get_anybus_di(AnyBusSlaveInputEnum.AB_FLOAT_IN_0))


class ExampleRobot(ParallelProgram):
    def pp_prompt_fault(self):
        """Trigger a software fault with fault_message"""
        fault("test_fault")

    def pp_clear_fault(self):
        """Clear software fault"""
        clear_fault()

    def pp_set_global_var(self):
        """Set the value of a global variable"""
        set_global_var("test_int", 7)

    def pp_get_global_var(self):
        """Returns the value of a global variable"""
        print(get_global_var("test_int"))

    def pp_get_system_state(self):
        """Returns the value of a system variable"""
        print(get_system_state(SystemStateEnum.CARTESIAN_POS_X))

    def pp_set_system_state(self):
        """Set the value of the system variable (current version only supports 'speedRatio')"""
        set_system_state(SystemStateEnum.SPEED_RATIO, 55)

    def pp_set_workcoord_or_tool(self):
        """Set the value of WorkCoord or Tool(Flange is not supported when setting tool)"""
        set_workcoord("WorkCoord0", [1, 2, 3, 4, 5, 6])
        set_tool("tool1", [1, 2, 3, 4, 5, 6])

    def pp_get_workcoord_or_tool(self):
        """Returns the value of WorkCoord or Tool(Flange is not supported when getting tool)"""
        print(get_workcoord("WorkCoord0"))
        print(get_tool("tool1"))

    def pp_get_content_of_traj_file(self):
        """Returns the contents of the file_name.traj"""
        print(read_trajectory_file("file_name"))

    def pp_write_content_to_traj_file(self):
        """Write the content to file_name.traj"""
        write_trajectory_file(" ", "file_name")

    def pp_update_object(self):
        """Update the values of the AI object."""
        update_object_pool(
            "obj_name",
            25,
            [1, 2, 3, 4, 5, 6, 7, 8],
            "1378.57 1378.57 1250 1250 2500 2500 1",
            "0 0 0 0 0 0",
            "flange",
        )

    def pp_clear_obj_pool(self):
        """Clear the existing AI objects"""
        clear_object_pool()

    def pp_update_global_variables(self):
        """Update partial or complete values of position type(JPos, Pose or Coord) type"""
        # Update all/partial JPos for Rizon
        update_global_var_jpos("GV_JPos", [1, 2, 3, 4, 5, 6, 7])
        update_global_var_jpos("GV_JPos", [-1, "", "", "", "", "", 100])
        # Update all/partial JPos for Moonlight
        update_global_var_jpos("GV_JPos", [7, 6, 5])
        update_global_var_jpos("GV_JPos", ["", "", -1])
        # Update all/partial Pose in mm/m (x,y,z)
        update_global_var_pose(
            "GV_Pose", [0.1, 0.2, 0.3, 4, 5, 6], MetricSystemEnum.METER
        )
        update_global_var_pose(
            "GV_Pose", [-100, -200, -300, -4, -5, -6], MetricSystemEnum.MILLIMETER
        )
        update_global_var_pose(
            "GV_Pose", [-0.6, "", "", 180, 0, 180], MetricSystemEnum.METER
        )
        # Update all/partial Coord in mm/m(enter "" fot partial update, None for no update)
        update_global_var_coord(
            "GV_Coord",
            [0.1, 0.2, 0.3, 40, 50, 60],
            [CoordinateSystemEnum.WORLD, CoordinateNameEnum.WORLD_ORIGIN],
            [0, -40, 0, 90, 0, 40, 0],
            [1, 2, 3, 4, 5, 6],
            MetricSystemEnum.METER,
        )
        update_global_var_coord(
            "GV_Coord",
            [-100, -200, "", "", "", 180],
            [CoordinateSystemEnum.WORK, "WorkCoord0"],
            None,
            None,
            MetricSystemEnum.MILLIMETER,
        )
