from pp.core.basic import join_list, split_string
from pp.core.communication import (
    socket_connected,
    socket_open,
    socket_recv,
    socket_send,
)
from pp.core.robot import get_system_di, update_object_pool
from pp.enums import GPIOInPortEnum
from pp.parallel_program import ParallelProgram


class TemplateProgram(ParallelProgram):

    def pp_visual_servo_demo(self):
        dis = 280
        imag_width = 2448
        imag_height = 2048
        cx = imag_width / 2
        cy = imag_height / 2
        real_width = 153
        fx = (imag_width * dis) / real_width
        fy = (imag_width * dis) / real_width
        recv_text = ""
        if socket_open(1, "192.168.2.160", 12345):
            while True:
                print(socket_send(1, "Visual servo start..."))
                recv_text = socket_recv(1)
                if recv_text != "":
                    array_v2d_value = split_string(recv_text, ",")
                    cam_intr_params = join_list(
                        [fx, fy, cx, cy, imag_width, imag_height, 1], " "
                    )
                    update_object_pool(
                        "vsObject",
                        25,
                        array_v2d_value,
                        cam_intr_params,
                        "0 0.15 0.035 0 0 180",
                        "flange",
                    )
        else:
            print("TCP/IP disconnected")

    def pp_visual_servo_template(self):
        vs_type = "IBVS"
        cam_intr_params = "919.49866 918.7968 648.15015 375.07938 1280 720 0.001"
        cam_extr_params = "-0.08 0 -0.06 -0.64563863 -0.58365935 -89.25559326"
        obj_name = "vsObject"
        recv_text = ""
        if socket_open(1, "192.168.2.102", 12345):
            while True:
                if not socket_connected(1):
                    print("Loss connection")
                    break
                if not socket_send(1, "Trigger"):
                    print("Send fail")
                    break
                recv_text = socket_recv(1)
                if recv_text != "":
                    obj_param = split_string(recv_text, ";")
                    obj_value = obj_param[4]
                    if vs_type == "IBVS":
                        update_object_pool(
                            obj_name,
                            25,
                            obj_value,
                            cam_intr_params,
                            cam_extr_params,
                            "flange",
                        )
                    elif vs_type == "PBVS":
                        update_object_pool(
                            obj_name,
                            8,
                            obj_value,
                            cam_intr_params,
                            cam_extr_params,
                            "flange",
                        )
                    elif vs_type == "OBVS":
                        update_object_pool(
                            obj_name,
                            3,
                            obj_value,
                            cam_intr_params,
                            cam_extr_params,
                            "flange",
                        )

    def pp_conv_vision_trigger(self):
        cam_intr_params = "919.49866 918.7968 648.15015 375.07938 1280 720 0.001"
        cam_extr_params = "0 0 0 0 0 0"
        obj_name = "Conveyor-SerialPort-1/Vision"
        recv_text = ""
        if socket_open(1, "192.168.2.102", 12345):
            while True:
                if get_system_di(GPIOInPortEnum.GPIO_IN_0) == 1:
                    if not socket_connected(1):
                        print("Loss connection")
                        break
                    if not socket_send(1, "Trigger"):
                        print("Send fail")
                        break
                    recv_text = socket_recv(1)
                    if recv_text != "":
                        obj_param = split_string(recv_text, ";")
                        obj_value = obj_param[4]
                        update_object_pool(
                            obj_name,
                            8,
                            obj_value,
                            cam_intr_params,
                            cam_extr_params,
                            "flange",
                        )
