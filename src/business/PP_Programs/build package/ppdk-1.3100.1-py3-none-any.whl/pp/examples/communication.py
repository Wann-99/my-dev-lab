from pp.core.communication import (
    modbus_rtu_close,
    modbus_rtu_open,
    modbus_rtu_read,
    modbus_rtu_write,
    modbus_tcp_close,
    modbus_tcp_connected,
    modbus_tcp_open,
    modbus_tcp_read,
    modbus_tcp_write,
    read_flx_modbus_tcp_bit,
    read_flx_modbus_tcp_float,
    read_flx_modbus_tcp_int,
    read_modbus_rtu_bit,
    read_modbus_rtu_float,
    read_modbus_rtu_int32,
    serial_port_close,
    serial_port_open,
    serial_port_recv,
    serial_port_send,
    socket_close,
    socket_connected,
    socket_open,
    socket_recv,
    socket_send,
    write_flx_modbus_tcp_bit,
    write_flx_modbus_tcp_float,
    write_flx_modbus_tcp_int,
    write_modbus_rtu_bit,
    write_modbus_rtu_float,
    write_modbus_rtu_int32,
)
from pp.enums import (
    BaudRateEnum,
    DataBitsEnum,
    ModbusReadTypeEnum,
    ModbusWriteTypeEnum,
    PartityEnum,
    StopBitsEnum,
)
from pp.parallel_program import ParallelProgram


class ExampleCommunication(ParallelProgram):
    def pp_socket(self):
        """
        socket_open: Establish communication with TCP server by connecting to the specified IP address and port number,
                     and to manage Socket ID;
        socket_connected: Check if the specified Socket is connected;
        socket_send: Send text to the server via an established Socket communication;
        socket_recv: Receive text from server via an established Socket communication;
        socket_close: Disconnect the specified Socket communication.
        """
        socket_open(1, "127.0.0.1", 8080)
        socket_connected(1)
        socket_send(1, "Hi, flexiv")
        socket_recv(1)
        socket_close(1)

    def pp_modbus_tcp(self):
        """
        modbus_tcp_open: Establish communication with Modbus TCP server by connecting to the specified IP address and
                         port number, and to manage Modbus TCP ID;
        modbus_tcp_connected: Check if the specified Modbus TCP is connected;
        modbus_tcp_write: Write data to the slave register via an established Modbus TCP communication;
        modbus_tcp_read: Read data from the slave register via an established Modbus TCP communication;
        modbus_tcp_close: Disconnect the specified Modbus TCP communication.
        """
        modbus_tcp_open(1, "127.0.0.1", 2000)
        modbus_tcp_connected(1)
        modbus_tcp_write(1, 1, 2, ModbusWriteTypeEnum.COILS, 0, [0, 1])
        modbus_tcp_read(1, 1, 2, ModbusReadTypeEnum.COILS, 0)
        modbus_tcp_close(1)

    def pp_modbus_rtu(self):
        """
        modbus_rtu_open: Establish communication with Modbus RTU master, and to manage Modbus RTU ID;
        modbus_rtu_write: Write data to the slave register via an established Modbus RTU communication;
        modbus_rtu_read: Read data from the slave register via an established Modbus RTU communication;
        modbus_rtu_close: Disconnect the specified Modbus RTU communication.
        """
        modbus_rtu_open(
            1,
            "flexiv_wib",
            BaudRateEnum.BAUD_115200,
            PartityEnum.NONE,
            DataBitsEnum.BIT_8,
            StopBitsEnum.BIT_1,
        )
        modbus_rtu_write(1, 1, 2, ModbusWriteTypeEnum.COILS, 0, [0, 0])
        modbus_rtu_read(1, 1, 2, ModbusReadTypeEnum.COILS, 0)
        modbus_rtu_close(1)

    def pp_serial_port(self):
        """
        serial_port_open: Establish communication with RS485 serial port, and to manage RS485 ID；
        serial_port_send: Send data to the server via an established RS485 communication;
        serial_port_recv: Receive data from server via an established RS485 communication;
        serial_port_close: Disconnect the specified RS485 communication.
        """
        serial_port_open(
            1,
            "flexiv_wib",
            BaudRateEnum.BAUD_115200,
            PartityEnum.NONE,
            DataBitsEnum.BIT_8,
            StopBitsEnum.BIT_1,
        )
        serial_port_send(1, [1, 2, 3])
        serial_port_recv(1, 2)
        serial_port_close(1)

    def pp_flexiv_modbus_tcp(self):
        """Read or Write Flexiv Modbus TCP"""
        while not modbus_tcp_connected(1):
            modbus_tcp_open(1, "127.0.0.1", 502)
        # Read "BitOut 0 ~ BitOut 7"
        print(read_flx_modbus_tcp_bit(1, 1, 0, 8))
        # Read "IntOut 12"
        print(read_flx_modbus_tcp_int(1, 1, 12, 1))
        # Read "FloatOut 1 ~ FloatOut 3"
        print(read_flx_modbus_tcp_float(1, 1, 1, 3))
        # Write "BitIn 5"
        write_flx_modbus_tcp_bit(1, 1, 5, [True])
        # Write "IntIn 3 ~ IntIn 7"
        write_flx_modbus_tcp_int(1, 1, 3, [1, -2, 0, 99999, -99999])
        # Write "FloatIn 0 ~ FloatIn 4"
        write_flx_modbus_tcp_float(1, 1, 0, [12.25, -1.0, 0, 99999.0, -99998.125])

    def pp_modbus_rtu_with_convert(self):
        """Read or Write Modbus RTU with convert between int32/float and registers"""
        ret = False
        while not ret:
            ret = modbus_rtu_open(
                1,
                "flexiv_wib",
                BaudRateEnum.BAUD_115200,
                PartityEnum.NONE,
                DataBitsEnum.BIT_8,
                StopBitsEnum.BIT_1,
            )
        # Write "Coils" from address 3
        write_modbus_rtu_bit(1, 10, 3, [True, False, False])
        # Write 3 int32 from address 2 to "Holding registers"
        write_modbus_rtu_int32(1, 10, 1, [45, 0, -99999])
        # Write 5 float from address 2 to "Holding registers"
        write_modbus_rtu_float(1, 10, 1, [12.25, -1.0, 0, 99999.0, -99998.125])

        # Read "Coils" from address 0
        print(read_modbus_rtu_bit(1, 10, 0, ModbusReadTypeEnum.COILS, 6))
        # Read "Discrete inputs" from address 1
        print(read_modbus_rtu_bit(1, 10, 1, ModbusReadTypeEnum.DISCRETE_INPUTS, 6))
        # Read 6 int32 from address 0 of the "Holding registers"
        print(read_modbus_rtu_int32(1, 10, 0, ModbusReadTypeEnum.HOLDING_REGISTERS, 4))
        # Read 1 int32 from address 6 of the "Input registers"
        print(read_modbus_rtu_int32(1, 10, 3, ModbusReadTypeEnum.INPUT_REGISTERS, 1))
        # Read 6 float from address 0 of the "Holding registers"
        print(read_modbus_rtu_float(1, 10, 0, ModbusReadTypeEnum.HOLDING_REGISTERS, 6))
        # Read 3 float from address 2 of the "Input registers"
        print(read_modbus_rtu_float(1, 10, 1, ModbusReadTypeEnum.INPUT_REGISTERS, 3))
