info = """
function info(str)
end
"""

modbus_tcp_open = """
function modbus_tcp_open(master_id, ip, port)
    return true
end
"""

modbus_tcp_close = """
function modbus_tcp_close(master_id)
end
"""

modbus_tcp_read = """
function modbus_tcp_read(master_id, slave_id, quantity, type, address)
    return {}
end
"""

modbus_tcp_write = """
function modbus_tcp_write(master_id, slave_id, quantity, type, address, value)
end
"""

modbus_tcp_connected = """
function modbus_tcp_connected(master_id)
    return true
end
"""

modbus_rtu_open = """
function modbus_rtu_open(master_id, port, baud_rate, parity, data_bits, stop_bits)
    return true
end
"""

modbus_rtu_close = """
function modbus_rtu_close(master_id)
end
"""

modbus_rtu_read = """
function modbus_rtu_read(master_id, slave_id, quantity, type, address)
    return {}
end
"""

modbus_rtu_write = """
function modbus_rtu_write(master_id, slave_id, quantity, type, address, value)
end
"""

serial_port_open = """
function serial_port_open(master_id, port, baud_rate, parity, data_bits, stop_bits)
end
"""

serial_port_close = """
function serial_port_close(master_id)
end
"""

serial_port_send = """
function serial_port_send(master_id, data)
end
"""

serial_port_recv = """
function serial_port_recv(master_id, length)
end
"""

socket_open = """
function socket_open(client_id, ip, port)
end
"""

socket_close = """
function socket_close(client_id)
end
"""

socket_send = """
function socket_send(client_id, data)
end
"""

socket_recv = """
function socket_recv(client_id)
end
"""

socket_connected = """
function socket_connected(client_id)
end
"""

write_content_to_file = """
function write_content_to_file(content, type, file_name)
end
"""

content_of_file = """
function content_of_file(type, file_name)
end
"""

str_to_number = """
function str_to_number(str, format)
end
"""

number_to_str = """
function number_to_str(number, format)
end
"""

convert_bytes_to_float = """
function convert_bytes_to_float(byte1, byte2, byte3, byte4)
end
"""

convert_float_to_bytes = """
function convert_float_to_bytes(float)
end
"""

clear_fault = """
function clear_fault()
end
"""

fault = """
function fault(msg)
end
"""

get_system_state = """
function get_system_state(state)
end
"""

set_global_var = """
function set_global_var(name, value)
end
"""

get_global_var = """
function get_global_var(name)
    return {}
end
"""

obj_pool_clear = """
function obj_pool_clear()
end
"""

obj_pool_update = """
function obj_pool_update(obj_name, type, data, camera_intrinsics, camera_extrinsics, mounting)
end
"""

set_workcoord_or_tool = """
function set_workcoord_or_tool(type, name, value)
end
"""

get_workcoord_or_tool = """
function get_workcoord_or_tool(type, name)
end
"""

set_io = """
function set_io(type, name, value)
end
"""

get_io = """
function get_io(type, name)
end
"""

set_io_pulse_ms = """
function set_io_pulse_ms(type, name, value, duration)
end
"""

wait_io_ms = """
function wait_io_ms(type, name, value, timeout)
end
"""

get_system_di = """
function get_system_di(name)
end
"""

get_profinet_slave_di = """
function get_profinet_slave_di(name)
end
"""

get_modbustcp_slave_di = """
function get_modbustcp_slave_di(name)
end
"""

get_anybus_di = """
function get_anybus_di(name)
end
"""

set_system_do = """
function set_system_do(name, value)
end
"""

set_profinet_slave_do = """
function set_profinet_slave_do(name, value)
end
"""

set_modbustcp_slave_do = """
function set_modbustcp_slave_do(name, value)
end
"""

set_anybus_do = """
function set_anybus_do(name, value)
end
"""

wait_system_di_ms = """
function wait_system_di_ms(name, value, timeout)
end
"""

wait_profinet_slave_di_ms = """
function wait_profinet_slave_di_ms(name, value, timeout)
end
"""

wait_modbustcp_slave_di_ms = """
function wait_modbustcp_slave_di_ms(name, value, timeout)
end
"""

wait_anybus_di_ms = """
function wait_anybus_di_ms(name, value, timeout)
end
"""

set_system_do_pulse_ms = """
function set_system_do_pulse_ms(name, value, duration)
end
"""

set_profinet_slave_do_pulse_ms = """
function set_profinet_slave_do_pulse_ms(name, value, duration)
end
"""

set_modbustcp_slave_do_pulse_ms = """
function set_modbustcp_slave_do_pulse_ms(name, value, duration)
end
"""

set_anybus_do_pulse_ms = """
function set_anybus_do_pulse_ms(name, value, duration)
end
"""

wait_ms = """
function wait_ms(duration)
end
"""

get_workcoord = """
function get_workcoord(name)
end
"""

get_tool = """
function get_tool(name)
end
"""

set_workcoord = """
function set_workcoord(name, value)
end
"""

set_tool = """
function set_tool(name, value)
end
"""

update_global_var_jpos = """
local function update_global_var_jpos(var_name, new_jpos)
end
"""

update_global_var_pose = """
local function update_global_var_pose(var_name, new_tcp_pos, unit)
end
"""

update_global_var_coord = """
local function update_global_var_coord(var_name, new_tcp_pos, new_coordinate, new_ref_joint_positions, new_ext_axis, unit)
end
"""

int32_to_registers = """
function int32_to_registers(value)
end
"""

registers_to_int32 = """
function registers_to_int32(high, low)
end
"""

float_to_registers = """
function float_to_registers(f)
end
"""

registers_to_float = """
function registers_to_float(high, low)
end
"""

read_flx_modbus_tcp_int = """
function read_flx_modbus_tcp_int(master_id, slave_id, offset, length)
end
"""

write_flx_modbus_tcp_float = """
function write_flx_modbus_tcp_float(master_id, slave_id, offset, data)
end
"""

read_flx_modbus_tcp_bit = """
function read_flx_modbus_tcp_bit(master_id, slave_id, offset, length)
end
"""

read_flx_modbus_tcp_float = """
function read_flx_modbus_tcp_float(master_id, slave_id, offset, length)
end
"""

write_flx_modbus_tcp_bit = """
function write_flx_modbus_tcp_bit(master_id, slave_id, offset, data)
end
"""

write_flx_modbus_tcp_int = """
function write_flx_modbus_tcp_int(master_id, slave_id, offset, data)
end
"""

read_modbus_rtu_int32 = """
function read_modbus_rtu_int32(master_id, slave_id, offset, type, length)

end
"""

write_modbus_rtu_float = """
function write_modbus_rtu_float(master_id, slave_id, offset, data)

end
"""

read_modbus_rtu_bit = """
function read_modbus_rtu_bit(master_id, slave_id, offset, type, length)

end
"""

read_modbus_rtu_float = """
function read_modbus_rtu_float(master_id, slave_id, offset, type, length)

end
"""

write_modbus_rtu_bit = """
function write_modbus_rtu_bit(master_id, slave_id, offset, data)

end
"""

write_modbus_rtu_int32 = """
function write_modbus_rtu_int32(master_id, slave_id, offset, data)

end
"""

sub_list = """
function sub_list(list, start_index, end_index)

end
"""

append_list = """
function append_list(list, value)

end
"""

remove_sub_list = """
function remove_sub_list(list, start_index, end_index)

end
"""

remove_sub_string = """
function remove_sub_string(string, start_index, end_index)

end
"""

compare_list = """
function compare_list(list1, list2)

end
"""

compare_dict = """
function compare_dict(dict1, dict2)

end
"""

coord_inverse = """
function coord_inverse(coord)

end
"""

coord_multiply = """
function coord_multiply(coord1, coord2)

end
"""

set_system_state = """
function set_system_state(state, value)

end
"""
