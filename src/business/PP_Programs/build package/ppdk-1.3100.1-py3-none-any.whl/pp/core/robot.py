from typing import Union

from pp.enums import *


def clear_fault():
    """ clear robot fault

    """
    pass


def fault(msg: str = "Trigger fault by PP"):
    """ trigger fault by PP
    :param msg:

    """
    pass


def set_system_state(state: SystemStateEnum, value):
    """ set system state
    :param state:  [speedRatio]
    :param value: robot system variable value
    """
    pass


def get_system_state(state: SystemStateEnum):
    """ get robot system state
    :param state:  [tcpPose
                    tcpTransVelX
                    tcpTransVelY
                    tcpTransVelZ
                    tcpAngVelX
                    tcpAngVelY
                    tcpAngVelZ
                    tcpTransVelNorm
                    tcpAngVelNorm
                    CartesianPosX
                    CartesianPosY
                    CartesianPosZ
                    EulerAngleRx
                    EulerAngleRy
                    EulerAngleRz
                    CartesianForceX
                    CartesianForceY
                    CartesianForceZ
                    CartesianMomentX
                    CartesianMomentY
                    CartesianMomentZ
                    CartesianForce
                    CartesianMoment
                    totalExtJointTorque
                    collisionFlag
                    jPos
                    axisPos1
                    axisPos2
                    axisPos3
                    axisPos4
                    axisPos5
                    axisPos6
                    axisPos7
                    axisVel1
                    axisVel2
                    axisVel3
                    axisVel4
                    axisVel5
                    axisVel6
                    axisVel7
                    axisTorque1
                    axisTorque2
                    axisTorque3
                    axisTorque4
                    axisTorque5
                    axisTorque6
                    axisTorque7
                    extAxisPos1
                    extAxisPos2
                    extAxisPos3
                    extAxisPos4
                    extAxisPos5
                    extAxisPos6
                    extAxisPos7
                    extAxisVel1
                    extAxisVel2
                    extAxisVel3
                    extAxisVel4
                    extAxisVel5
                    extAxisVel6
                    extAxisVel7
                    jointPos
                    motionbarEnablePressed
                    motionbarEstopPressed
                    isConfirmed
                    isServoOn
                    operationMode
                    isFault
                    remoteActive
                    uiAppConnected
                    robotModelMajorVersion
                    robotModelMinorVersion
                    tcpWrenchLpfFcType
                    currentToolName
                    projectRunning
                    projectPaused
                    speedRatio
                    tcpRelativeTransX
                    tcpRelativeTransY
                    tcpRelativeTransZ
                    tcpRelativeTransNorm
                    tcpRelativeRotX
                    tcpRelativeRotY
                    tcpRelativeRotZ
                    tcpRelativeRotNorm
                    latestErrorCode
                    currentForceCoord
                    plusButtonPressed
                    minusButtonPressed]
    """
    pass


def set_global_var(name: str, value: object):
    """ set global variable
    :param name: global variable name
    :param value: global variable value, support Variable, COORD, JPOS, String, Double, Integer etc
    """
    pass


def get_global_var(name: str):
    """ get global variable
    :param name: global variable name
    """
    pass


def update_global_var_jpos(var_name: str, new_jpos: list):
    """
    update global var of jpos type
    :param var_name:
    :param new_jpos: (a1, a2, a3, a4, a5, a6, a7), set some to "" if partial update
    :return:
    """
    pass


def update_global_var_pose(var_name: str,
                           new_tcp_pos: list,
                           unit: MetricSystemEnum):
    """
    update global var of pose type
    :param var_name: global variable name
    :param new_tcp_pos: (x, y, z, rx, ry, rz), set some to "" if partial update
    :param unit: unit of x, y, z
    :return:
    """
    pass


def update_global_var_coord(
        var_name: str,
        new_tcp_pos: Union[list, None],
        new_coordinate: Union[list, None],
        new_ref_joint_positions: Union[list, None],
        new_ext_axis: Union[list, None],
        unit: MetricSystemEnum
):
    """
    update global var of coordinate type
    :param var_name: global variable name
    :param new_tcp_pos: (x, y, z, rx, ry, rz), set some to "" if partial update, or set new_tcp_pos None if not update
    :param new_coordinate: tuple with 2 items, set some to "" if partial update, or set new_coordinate None if not update
    :param new_ref_joint_positions: tuple with 7 items, set some to "" if partial update, or set new_ref_joint_positions None if not update
    :param new_ext_axis: tuple with 6 items, set some to "" if partial update, or set new_ext_axis None if not update
    :param unit:  unit of x, y, z in new_tcp_pos
    :return:
    """
    pass


def get_io(type: GPIOEnum,
           name: Union[
               GPIOInPortEnum,
               ProfinetSlaveInputEnum,
               ModbusTCPInputEnum,
               AnyBusSlaveInputEnum]):
    """ get robot io
    :param type: [SYSTEM-GPIOSystem,
                  PROFINET_SLAVE-GPIOProfinetSlave,
                  MODBUSTCP_SLAVE-GPIOModbusTCPSlave,
                  ANYBUS-GPIOAnybus]
    :param name:
    """
    pass


def set_io(type: GPIOEnum,
           name: Union[
               GPIOOutPortEnum,
               ProfinetSlaveOutputEnum,
               ModbusTCPOutputEnum,
               AnyBusSlaveOutputEnum],
           value: Union[bool, int, float]):
    """ set robot io
    :param type: [SYSTEM-GPIOSystem,
                  PROFINET_SLAVE-GPIOProfinetSlave,
                  MODBUSTCP_SLAVE-GPIOModbusTCPSlave,
                  ANYBUS-GPIOAnybus]
    :param name:
    :param value:
    """
    pass


def wait_io_ms(type: GPIOEnum,
               name: Union[
                   GPIOInPortEnum,
                   ProfinetSlaveInputEnum,
                   ModbusTCPInputEnum,
                   AnyBusSlaveInputEnum],
               value: bool,
               timeout: int):
    """ wait for given time until given IO port value
    :param type: [SYSTEM-GPIOSystem,
                  PROFINET_SLAVE-GPIOProfinetSlave,
                  MODBUSTCP_SLAVE-GPIOModbusTCPSlave,
                  ANYBUS-GPIOAnybus]
    :param name:
    :param value:
    :param timeout:
    """
    pass


def set_io_pulse_ms(type: GPIOEnum,
                    name: Union[
                        GPIOOutPortEnum,
                        ProfinetSlaveOutputEnum,
                        ModbusTCPOutputEnum,
                        AnyBusSlaveOutputEnum],
                    value: bool,
                    duration: int):
    """ set pulse to DO port in given duration
    :param type: [GPIOSystem,
                  GPIOProfinetSlave,
                  GPIOModbusTCPSlave
                  GPIOAnybus]
    :param name: DO port name
    :param value: [True, False]
    :param duration: unit ms
    """
    pass


def get_system_di(name: GPIOInPortEnum):
    """ get robot system di
    :param name: GPIOInPortEnum
    """
    pass


def get_profinet_slave_di(name: ProfinetSlaveInputEnum):
    """ get robot profinet di
    :param name: ProfinetSlaveInputEnum
    """
    pass


def get_modbustcp_slave_di(name: ModbusTCPInputEnum):
    """ get robot modbustcp di
    :param name: ModbusTCPInputEnum
    """
    pass


def get_anybus_di(name: AnyBusSlaveInputEnum):
    """ get robot anybus di
    :param name: AnyBusSlaveInputEnum
    """
    pass


def set_system_do(name: GPIOOutPortEnum, value: bool):
    """ set robot system do
    :param name: GPIOOutPortEnum
    :param value
    """
    pass


def set_profinet_slave_do(name: ProfinetSlaveOutputEnum, value: Union[bool, int, float]):
    """ set robot profinet do
    :param name: ProfinetSlaveOutputEnum
    :param value
    """
    pass


def set_modbustcp_slave_do(name: ModbusTCPOutputEnum, value: Union[bool, int, float]):
    """ set robot modbustcp do
    :param name: ModbusTCPOutputEnum
    :param value
    """
    pass


def set_anybus_do(name: AnyBusSlaveOutputEnum, value: Union[bool, int, float]):
    """ set robot anybus do
    :param name: AnyBusSlaveOutputEnum
    :param value
    """
    pass


def wait_system_di_ms(name: GPIOInPortEnum, value: bool, timeout: int):
    """ wait for given time until given system di port value
    :param name:
    :param value:
    :param timeout:
    """
    pass


def wait_profinet_slave_di_ms(name: ProfinetSlaveInputEnum, value: bool, timeout: int):
    """ wait for given time until given profinet di port value
    :param name:
    :param value:
    :param timeout:
    """
    pass


def wait_modbustcp_slave_di_ms(name: ModbusTCPInputEnum, value: bool, timeout: int):
    """ wait for given time until given modbustcp di port value
    :param name:
    :param value:
    :param timeout:
    """
    pass


def wait_anybus_di_ms(name: AnyBusSlaveInputEnum, value: bool, timeout: int):
    """ wait for given time until given anybus di port value
    :param name:
    :param value:
    :param timeout:
    """
    pass


def set_system_do_pulse_ms(name: GPIOOutPortEnum, value: bool, duration: int):
    """ set pulse to system do port in given duration
    :param name: DO port name
    :param value: [True, False]
    :param duration: unit ms
    """
    pass


def set_profinet_slave_do_pulse_ms(name: ProfinetSlaveOutputEnum, value: bool, duration: int):
    """ set pulse to profinet do port in given duration
    :param name: DO port name
    :param value: [True, False]
    :param duration: unit ms
    """
    pass


def set_modbustcp_slave_do_pulse_ms(name: ModbusTCPOutputEnum, value: bool, duration: int):
    """ set pulse to modbustcp do port in given duration
    :param name: DO port name
    :param value: [True, False]
    :param duration: unit ms
    """
    pass


def set_anybus_do_pulse_ms(name: AnyBusSlaveOutputEnum, value: bool, duration: int):
    """ set pulse to anybus do port in given duration
    :param name: DO port name
    :param value: [True, False]
    :param duration: unit ms
    """
    pass


def read_trajectory_file(name: str):
    """ read content to trajectory file
    :param name: traj file name
    """
    pass


def write_trajectory_file(content: str, name: str):
    """ write content to trajectory file
    :param content: traj file content
    :param name: traj file name
    """
    pass


def set_workcoord(name: str, value):
    """ set name of type workcoord to value
    :param name: workcoord name
    :param value:
    """
    pass


def set_tool(name: str, value):
    """ set name of tool to value
    :param name: tool name
    :param value:
    """
    pass


def get_workcoord(name: str):
    """ get value of workcoord
    :param name: workcoord name
    """
    pass


def get_tool(name: str):
    """ get value of tool
    :param name: tool name
    """
    pass


def clear_object_pool():
    """ clear object pool
    """
    pass


def update_object_pool(obj_name: str, type: int, data: list, camera_intrinsics: str,
                       camera_extrinsics: str, mounting: str):
    """ update object pool
    :param obj_name: object name
    :param type: object type, 25 - array_vec_2d, 3 - vec-6d, 19 - array_vec_3d, 8 - pose
    :param data:
    :param camera_intrinsics: camera intrinsics
    :param camera_extrinsics: camera extrinsics
    :param mounting: mounting, ["flange", "tcp", "world"]
    """
    pass
