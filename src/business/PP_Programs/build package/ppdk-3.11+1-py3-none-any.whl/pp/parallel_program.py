import inspect
import json
import os
import traceback

import grpc
from loguru import logger
from pp.pythonlua.translator import Translator
from google.protobuf.json_format import MessageToDict

from pp.settings import RobotSetting
from pp.utils.lua_util import is_lua_syntax_valid


class ParallelProgram:
    def __init__(
            self,
            setting: RobotSetting = RobotSetting(),
            port: int = 18001,
            auto_booted: bool = False,
            auto_looped: bool = False,
            force_validate: bool = True,
            auto_restart: bool = False
    ):
        self._robot_ip = setting.ip
        self._robot_port = port
        self._auto_booted = auto_booted
        self._auto_looped = auto_looped
        self._force_validate = force_validate
        self._auto_restart = auto_restart
        self._base_dir = setting.base_dir
        self._robot_dir = setting.root_dir
        self._init_builtin_funcs()
        self._init_custom_funcs()
        self._init_mock_funcs()
        self._init_service_stub()

    def _init_service_stub(self):
        from pp.proto.RobotServicePP_pb2_grpc import PPServiceStub

        self._channel = grpc.insecure_channel(f"{self._robot_ip}:{self._robot_port}")
        self._stub = PPServiceStub(self._channel)

    def _get_funcs(self, code_str: str) -> tuple:
        """
        获取代码中所有的函数名
        :param code_str:
        :return:
        """
        import ast

        tree = ast.parse(code_str)
        funcs = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call):
                if hasattr(node.func, "id"):
                    funcs.append(node.func.id)
                elif hasattr(node.func, "value"):
                    if node.func.value.id == "self":
                        funcs.append(node.func.attr)
                    else:
                        funcs.append(node.func.value.id)
        return tuple(funcs)

    def _get_builtin(self, builtin_funcs: list):
        """
        获取builtin中所有调用builtin的函数名
        :param builtin_funcs:
        :return:
        """
        code_str = self.builtin_funcs[builtin_funcs[-1]]
        for code in code_str.split("\n"):
            for func in self.builtin_funcs.keys():
                import re

                if re.search(rf"\b{func}\b", code) and func not in builtin_funcs:
                    builtin_funcs.append(func)
                    self._get_builtin(builtin_funcs)
        return builtin_funcs[::-1]

    def _get_assigns(self, code_str: str):
        """
        获取代码中所有的赋值语句
        :param code_str:
        :return: {左值: 右值, }
        """
        import ast

        tree = ast.parse(code_str)
        assigns = {}
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                assigns[node.targets[0].id] = node.value.value
        return assigns

    def _init_builtin_funcs(self):
        # 获取buitins中定义的的lua函数代码
        with open(os.path.join(self._base_dir, "core/builtins.py"), "r") as f:
            builtins_code_str = f.read()
        self.builtin_funcs = self._get_assigns(builtins_code_str)

    def _init_mock_funcs(self):
        # 获取mock中定义的的lua函数代码
        with open(os.path.join(self._base_dir, "core/mock.py"), "r") as f:
            mock_code_str = f.read()
        self.mock_funcs = self._get_assigns(mock_code_str)

    def _init_custom_funcs(self):
        # 获取自定义函数
        translator = Translator()
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        self.custom_funcs = {}
        for method in methods:
            code = inspect.getsource(method[1])
            signature = inspect.signature(method[1])
            if method[0].startswith("func_"):
                name = method[0][5:]
                func_def = f"local function {name}({', '.join([sign.name for sign in signature.parameters.values()])})"
                # 去除每行的缩进8个空格
                func_lst = code.split("\n")
                for idx, code in enumerate(func_lst):
                    if code.strip().endswith(","):
                        # 函数定义换行
                        continue
                    elif code.strip().endswith(":"):
                        code_lst = func_lst[idx + 1:]
                        break
                assert code_lst, "func define not found"
                code_str = "\n\n".join(line[8:] for line in code_lst)
                lua_code_str = translator.translate(code_str)
                lua_code_str = "\n".join(
                    ["  " + item for item in lua_code_str.split("\n")]
                )
                self.custom_funcs[name] = {
                    "name": name,
                    "code": func_def + "\n" + lua_code_str + "\nend\n",
                    "builtins": {},
                    "funcs": [],
                }
                # 获取pp func中调用的函数
                called_funcs = self._get_funcs(code_str)
                for func in called_funcs:
                    if (
                            func.startswith("func_")
                            and func[5:] not in self.custom_funcs[name]["funcs"]
                    ):
                        self.custom_funcs[name]["funcs"].append(func[5:])
                    if (
                            func in self.builtin_funcs
                            and func not in self.custom_funcs[name]["builtins"]
                    ):
                        builtin_funcs = self._get_builtin([func])
                        self.custom_funcs[name]["builtins"].update(
                            {f: self.builtin_funcs[f] for f in builtin_funcs}
                        )

    def _get_lua_code(self) -> dict:
        translator = Translator()
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        result = {}

        for method in methods:
            code = inspect.getsource(method[1])
            signature = inspect.signature(method[1])

            # 转换所有pp_开头的python方法为lua方法
            if method[0].startswith("pp_"):
                name = method[0][3:]
                # 定义每个pp的配置, 用户可以通过参数指定
                _auto_booted = self._auto_booted
                _auto_looped = self._auto_looped
                _auto_restart = self._auto_restart
                for sign in signature.parameters.values():
                    if sign.name == "auto_booted":
                        _auto_booted = sign.default
                    elif sign.name == "auto_looped":
                        _auto_looped = sign.default
                    elif sign.name == "auto_restart":
                        _auto_restart = sign.default
                # 去除第一行def
                # 去除每行的缩进8个空格
                code_str = "\n\n".join(line[8:] for line in code.split("\n")[1:])
                lua_code_str = translator.translate(code_str)
                result[name] = {
                    "name": name,
                    "code": lua_code_str,
                    "config": json.dumps(
                        {
                            "auto_booted": _auto_booted,
                            "auto_looped": _auto_looped,
                            "desc": "",
                            "is_enabled": False,
                            "auto_restart_when_fault_cleared": _auto_restart,
                        }
                    ),
                    "builtins": [],
                    "funcs": [],
                }
                # 获取pp python中调用的函数
                called_funcs = self._get_funcs(code_str)
                for func in called_funcs:
                    # pp 中调用的自定义func
                    if (
                            func.startswith("func_")
                            and func[5:] not in result[name]["funcs"]
                    ):
                        result[name]["funcs"].append(func[5:])
                    # pp 中的内置函数
                    elif (
                            func in self.builtin_funcs
                            and func not in result[name]["builtins"]
                    ):
                        called_builtin = self._get_builtin([func])
                        for builtin in called_builtin:
                            if builtin not in result[name]["builtins"]:
                                result[name]["builtins"].append(builtin)
        return result

    def to_lua(self, check: bool = False):
        """
        将python代码转换为lua

        :param check: 是否校验反以后的lua语法
        :return:
        """

        def _get_func_builtins(func):
            if self.custom_funcs[func]["funcs"]:
                for ff in self.custom_funcs[func]["funcs"]:
                    _get_func_builtins(ff)
            for bi in self.custom_funcs[func]["builtins"]:
                if bi not in defined_builtin:
                    bi_code = self.builtin_funcs[bi]
                    defined_builtin.append(bi)
                    f.write(bi_code + "\n")

        def _get_func_funcs(func):
            if self.custom_funcs[func]["funcs"]:
                for ff in self.custom_funcs[func]["funcs"]:
                    _get_func_funcs(ff)
            for func in self.custom_funcs[func]["funcs"]:
                if func not in defined_function:
                    func_code = self.custom_funcs[func]["code"]
                    defined_function.append(func)
                    f.write(func_code + "\n")

        data = self._get_lua_code()
        for pp in data:
            if not os.path.exists(pp):
                os.mkdir(pp)
            else:
                if os.path.isfile(pp):
                    raise Exception(f"{pp} already exists as a file")
            pwd = os.getcwd()
            try:
                os.chdir(pp)
                if os.path.exists(f"{pp}.lua"):
                    os.remove(f"{pp}.lua")
                with open(f"{pp}.lua", "a+") as f:
                    # 添加类变量
                    translator = Translator()
                    for var in self._get_variables():
                        value = self.__dict__["pp_" + var]
                        if isinstance(value, str):
                            f.write(f"{var} = '{value}'\n")
                        else:
                            f.write(f"{var} = {translator.translate(str(value))}\n")
                    defined_builtin = []
                    # 添加 builtin
                    for bi in data[pp]["builtins"]:
                        if bi not in defined_builtin:
                            bi_code = self.builtin_funcs[bi]
                            defined_builtin.append(bi)
                            f.write(bi_code + "\n")

                    # 添加 自定义func中的builtin
                    for func in data[pp]["funcs"]:
                        _get_func_builtins(func)

                    # 添加 自定义func中的自定义func
                    defined_function = []
                    for func in data[pp]["funcs"]:
                        _get_func_funcs(func)

                    # 添加 自定义func
                    for func in data[pp]["funcs"]:
                        func_code = self.custom_funcs[func]["code"]
                        if func not in defined_function:
                            defined_function.append(func)
                            f.write(func_code + "\n")

                    # 添加 pp
                    lua_code_str = data[pp]["code"]
                    pp_config = data[pp]["config"]
                    # 创建 pp.lua
                    f.write(lua_code_str + "\n")

                # 创建 ppConfig.json
                with open("ppConfig.json", "w") as f:
                    f.write(pp_config)

                # 创建 pp.xml，防止从UI编辑pp时，RCA奔溃
                with open(f"{pp}.xml", "w") as f:
                    f.write("""<xml xmlns='https://developers.google.com/blockly/xml'></xml>""")
                if check:
                    with open(f"{pp}.lua") as f:
                        lua_code = f.read()
                    for mock_f in self.mock_funcs:
                        lua_code = self.mock_funcs[mock_f] + "\n" + lua_code
                    if not is_lua_syntax_valid(lua_code):
                        logger.error(f"lua syntax is invalid in {pp}.lua")
                        logger.debug(lua_code)
            except Exception as e:
                traceback.print_exc()
                logger.error(e)
            finally:
                os.chdir(pwd)

    def assign(self) -> dict:
        """
        下发pp到机器人
        """

        def _get_func_builtins(func):
            content = ""
            if self.custom_funcs[func]["funcs"]:
                for ff in self.custom_funcs[func]["funcs"]:
                    content += _get_func_builtins(ff)
            for bi in self.custom_funcs[func]["builtins"]:
                if bi not in defined_builtin:
                    bi_code = self.builtin_funcs[bi]
                    defined_builtin.append(bi)
                    content += bi_code + "\n"
            return content

        def _get_func_funcs(func):
            content = ""
            if self.custom_funcs[func]["funcs"]:
                for ff in self.custom_funcs[func]["funcs"]:
                    content += _get_func_funcs(ff)
            for func in self.custom_funcs[func]["funcs"]:
                if func not in defined_function:
                    func_code = self.custom_funcs[func]["code"]
                    defined_function.append(func)
                    content += func_code + "\n"
            return content

        from pp.proto.RobotServicePP_pb2 import (
            AddPPRequest,
            UpdatePPContentRequest,
            UpdatePPOptionRequest,
        )
        if self._force_validate:
            self.validate()
        data = self._get_lua_code()
        result = {}
        for pp in data:
            ret1 = self._stub.AddPP(AddPPRequest(pp_name=pp))
            # 110000 新的pp，310008 pp已存在
            assert ret1.value in [
                110000,
                310008,
            ], f"failed to add pp, ret code: {ret1.value}, ret info: {ret1.info}"
            content = ""
            # 添加类变量
            translator = Translator()
            for var in self._get_variables():
                value = self.__dict__["pp_" + var]
                if isinstance(value, str):
                    content += f"{var} = '{value}'\n"
                else:
                    content += f"{var} = {translator.translate(str(value))}\n"
            # 添加 builtin
            defined_builtin = []
            for bi in data[pp]["builtins"]:
                if bi not in defined_builtin:
                    bi_code = self.builtin_funcs[bi]
                    content += bi_code + "\n"
            # 添加 自定义func中的builtin
            for func in data[pp]["funcs"]:
                content += _get_func_builtins(func) + "\n"
            # 添加 自定义func中的自定义func
            defined_function = []
            for func in data[pp]["funcs"]:
                content += _get_func_funcs(func) + "\n"
            # 添加 自定义func
            for func in data[pp]["funcs"]:
                func_code = self.custom_funcs[func]["code"]
                if func not in defined_function:
                    defined_function.append(func)
                    content += func_code + "\n"
            # 添加 pp
            lua_code_str = data[pp]["code"]
            content += lua_code_str + "\n"
            # 更新 pp
            ret2 = self._stub.UpdatePPContent(
                UpdatePPContentRequest(
                    pp_name=pp,
                    script_file_content=content,
                    blockly_file_content="<xml xmlns='https://developers.google.com/blockly/xml'></xml>\n",
                )
            )
            assert ret2.value in [110000], f"failed to update pp content, ret: {ret2}"
            ret3 = self._stub.UpdatePPOption(
                UpdatePPOptionRequest(
                    pp_name=pp,
                    pp_auto_booted=json.loads(data[pp]["config"])["auto_booted"],
                    pp_auto_looped=json.loads(data[pp]["config"])["auto_looped"],
                    pp_auto_restart_when_fault_cleared=json.loads(data[pp]["config"])[
                        "auto_restart_when_fault_cleared"],
                )
            )
            assert ret3.value in [110000], f"failed to update pp option, ret: {ret3}"
            result[pp] = True
        return result

    def remove(self) -> dict:
        """
        删除pp程序
        """
        from pp.proto.RobotServicePP_pb2 import RemovePPRequest

        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.RemovePP(RemovePPRequest(pp_name=pp))
        return result

    def enable(self) -> dict:
        """
        enable pp程序
        """
        from pp.proto.RobotServicePP_pb2 import PPCmdRequest

        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.EnablePP(PPCmdRequest(pp_name=pp))
        return result

    def disable(self) -> dict:
        """
        disable pp程序
        """
        from pp.proto.RobotServicePP_pb2 import PPCmdRequest

        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.DisablePP(PPCmdRequest(pp_name=pp))
        return result

    def pause(self) -> dict:
        """
        暂停 pp程序
        """
        from pp.proto.RobotServicePP_pb2 import PPCmdRequest

        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.PausePP(PPCmdRequest(pp_name=pp))
        return result

    def resume(self) -> dict:
        """
        恢复执行 pp程序
        """
        from pp.proto.RobotServicePP_pb2 import PPCmdRequest

        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.ResumePP(PPCmdRequest(pp_name=pp))
        return result

    def start(self) -> dict:
        """
        开始执行 pp程序
        """
        from pp.proto.RobotServicePP_pb2 import PPCmdRequest

        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.StartPP(PPCmdRequest(pp_name=pp))
        return result

    def stop(self) -> dict:
        """
        停止 pp程序
        """
        from pp.proto.RobotServicePP_pb2 import PPCmdRequest

        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.StopPP(PPCmdRequest(pp_name=pp))
        return result

    def clear_fault(self) -> dict:
        """
        清除 fault
        """
        from pp.proto.RobotServicePP_pb2 import PPCmdRequest

        data = self._get_lua_code()
        result = {}
        for pp in data:
            result[pp] = self._stub.ClearFaultPP(PPCmdRequest(pp_name=pp))
        return result

    def _get_variables(self):
        """
        获取类实例变量，以pp_开头的变量为类实例变量
        :return:
        """
        variables = []
        for k, v in self.__dict__.items():
            if k.startswith("pp_"):
                variables.append(k[3:])
        return variables

    def _get_robot_variable_list(self):
        """
        获取机器人全局变量
        """
        from pp.proto.RobotServiceWorkflow_pb2 import GetRunTimeVariableListResponse
        from pp.proto.RobotServiceWorkflow_pb2_grpc import WorkflowServiceStub
        _channel = grpc.insecure_channel(f"{self._robot_ip}:{self._robot_port}")
        _workflow_stub = WorkflowServiceStub(_channel)
        ret = _workflow_stub.GetRunTimeVariableList(GetRunTimeVariableListResponse())
        var_dict = MessageToDict(ret)
        gv_list = []
        var_list = var_dict["varList"]["dataList"] if var_dict else []
        for var in var_list:
            if var["category"] == "GLOBAL_VAR":
                gv_list.append(var["name"])
        return gv_list

    def _get_robot_tool_list(self):
        """
        获取机器人tool
        """
        from pp.proto.RobotServiceToolDevice_pb2 import GetToolListResponse
        from pp.proto.RobotServiceToolDevice_pb2_grpc import ToolDeviceServiceStub
        _channel = grpc.insecure_channel(f"{self._robot_ip}:{self._robot_port}")
        _tool_device_stub = ToolDeviceServiceStub(_channel)
        ret = _tool_device_stub.GetToolList(GetToolListResponse())
        tool_dict = MessageToDict(ret)
        tool_list = tool_dict["toolInfo"] if "toolInfo" in tool_dict else []
        return [tool["toolName"] for tool in tool_list]

    def _get_robot_workcoord_list(self):
        """
        获取机器人workcoord
        """
        from pp.proto.RobotServiceToolDevice_pb2 import GetWorkCoordListResponse
        from pp.proto.RobotServiceToolDevice_pb2_grpc import ToolDeviceServiceStub
        _channel = grpc.insecure_channel(f"{self._robot_ip}:{self._robot_port}")
        _tool_device_stub = ToolDeviceServiceStub(_channel)
        ret = _tool_device_stub.GetWorkCoordList(GetWorkCoordListResponse())
        workcoord_dict = MessageToDict(ret)
        workcoord_list = workcoord_dict["workcoordInfo"] if "workcoordInfo" in workcoord_dict else []
        return [workcoord["workcoordName"] for workcoord in workcoord_list]

    def _get_called_gv(self):
        translator = Translator()
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        variables = []
        for method in methods:
            code = inspect.getsource(method[1])
            if method[0].startswith("pp_") or method[0].startswith("func_"):
                code_str = "\n\n".join(line[8:] for line in code.split("\n")[1:])
                translator.translate(code_str)
                variables.extend(translator.called_args["variable"])
        return variables

    def _get_called_tool(self):
        translator = Translator()
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        tools = []
        for method in methods:
            code = inspect.getsource(method[1])
            if method[0].startswith("pp_") or method[0].startswith("func_"):
                code_str = "\n\n".join(line[8:] for line in code.split("\n")[1:])
                translator.translate(code_str)
                tools.extend(translator.called_args["tool"])
        return tools

    def _get_called_workcoord(self):
        translator = Translator()
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        workcoords = []
        for method in methods:
            code = inspect.getsource(method[1])
            if method[0].startswith("pp_") or method[0].startswith("func_"):
                code_str = "\n\n".join(line[8:] for line in code.split("\n")[1:])
                translator.translate(code_str)
                workcoords.extend(translator.called_args["workcoord"])
        return workcoords

    def validate_global_variable(self):
        """
        验证global variable是否合法
        """
        variables = self._get_called_gv()
        if variables:
            for var in variables:
                if var not in self._get_robot_variable_list():
                    assert False, f"Global variable {var} is not exist, please check."

    def validate_tool(self):
        """
        验证tool是否合法
        """
        tools = self._get_called_tool()
        if tools:
            for tool in tools:
                assert tool != "Flange", "Tool: Flange is not operational"
                if tool not in self._get_robot_tool_list():
                    assert False, f"Tool {tool} is not exist, please check."

    def validate_workcoord(self):
        """
        验证workword是否合法
        """
        workcoords = self._get_called_workcoord()
        if workcoords:
            for workcoord in workcoords:
                if workcoord not in self._get_robot_workcoord_list():
                    assert False, f"Workcoord {workcoord} is not exist, please check."

    def validate(self):
        methods = inspect.getmembers(self, predicate=inspect.ismethod)
        for method in methods:
            if method[0].startswith("validate_"):
                func = getattr(self, method[0])
                func()
